package com.infinity.dragontiger

/** Flag simples em memória: há uma sessão de captura ativa? */
object CaptureOverlayServiceActive {
    @Volatile
    var isActive: Boolean = false
}
