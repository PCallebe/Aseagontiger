package com.infinity.dragontiger

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico de sessões arquivadas — nada é apagado pelo dia a dia. */
class HistoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RoundsStore.init(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(6, 13, 24))
        root.setPadding(24, 40, 24, 40)

        root.addView(title("HISTÓRICO DE SESSÕES", 20f, Color.WHITE))
        root.addView(title("Arquivadas automaticamente ao Zerar — nunca apagadas.", 11f, Color.rgb(143, 166, 194)))

        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val sessions = RoundsStore.sessions()
        if (sessions.length() == 0) {
            list.addView(title("Nenhuma sessão arquivada ainda.", 13f, Color.rgb(143, 166, 194)))
        }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        for (i in 0 until sessions.length()) {
            val o = sessions.optJSONObject(i) ?: continue
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(16, 12, 16, 14)
            card.setBackgroundColor(Color.rgb(11, 22, 38))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 8, 0, 8)
            card.layoutParams = lp
            card.addView(title("#${sessions.length() - i} • ${fmt.format(Date(o.optLong("ts")))}", 14f, Color.WHITE))
            card.addView(title("${o.optInt("n")} rodadas • maior sequência ${o.optInt("maxStreak")}", 11f, Color.rgb(143, 166, 194)))
            card.addView(title("Dragão ${o.optInt("d")} · Empate ${o.optInt("s")} · Tigre ${o.optInt("t")}", 11f, Color.rgb(127, 212, 255)))
            list.addView(card)
        }
        setContentView(root)
    }

    private fun title(s: String, size: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        t.setPadding(0, 6, 0, 6)
        return t
    }
}
