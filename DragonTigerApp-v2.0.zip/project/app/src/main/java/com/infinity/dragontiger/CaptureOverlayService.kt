package com.infinity.dragontiger

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

/**
 * Serviço de captura + overlay flutuante.
 * - Lê a tela do jogo automaticamente (MediaProjection), sem marcação manual
 *   e sem botões manuais: o que muda na fileira de bolinhas é registrado.
 * - O overlay (SYSTEM_ALERT_WINDOW) abre no topo da tela, é arrastável,
 *   sobrepõe o jogo e tem: minimizar (fica só o cabeçalho compacto) e fechar.
 * - Novas rodadas entram automaticamente na sequência (novo à esquerda).
 */
class CaptureOverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "dragon_tiger_capture"
        private const val NOTIF_ID = 917
        private const val FRAME_MIN_MS = 180L      // captura ~5x por seg
        private const val NEW_BEAD_STABLE = 3      // frames iguais para confirmar
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlayRoot: View? = null
    private var webView: WebView? = null
    private var wm: WindowManager? = null

    private val busy = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var lastFrameProcessed = 0L
    private var lastRow: List<String>? = null
    private var rowStreak = 0
    private var lastExclusion = intArrayOf(0, 0, 0, 0)
    private var consecutiveFails = 0
    private var overlayParams: WindowManager.LayoutParams? = null
    private var screenH = 1
    private var lastTouchY = -1f
    private var dragStartY = 0

    private val bridge = Bridge()

    /* ---------------- ciclo de vida ---------------- */

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        RoundsStore.init(this)
        createNotificationChannel()
        startForeground(NOTIF_ID, notification())
        if (projection == null) {
            if (intent == null) { stopSelf(); return START_NOT_STICKY }
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else
                @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            if (data == null || resultCode == 0) { stopSelf(); return START_NOT_STICKY }
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, mainHandler)
            startCapture()
            showOverlay()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        try { projection?.stop() } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { webView?.destroy() } catch (_: Exception) {}
        try { overlayRoot?.let { wm?.removeView(it) } } catch (_: Exception) {}
        projection = null; virtualDisplay = null; reader = null; overlayRoot = null; webView = null
        super.onDestroy()
    }

    /* ---------------- captura ---------------- */

    private fun startCapture() {
        val metrics = DisplayMetrics()
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val w = kotlin.math.max(metrics.widthPixels, 1)
        val h = kotlin.math.max(metrics.heightPixels, 1)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ r ->
            val img: Image? = try { r.acquireLatestImage() } catch (_: Exception) { null }
            if (img != null) processFrame(img)
        }, mainHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "DragonTiger", w, h, metrics.densityDpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, mainHandler
        )
    }

    private fun processFrame(image: Image) {
        val now = System.currentTimeMillis()
        if (now - lastFrameProcessed < FRAME_MIN_MS) { image.close(); return }
        if (!busy.compareAndSet(false, true)) { image.close(); return }
        lastFrameProcessed = now
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            if (bitmap != null) {
                val row = ScreenBeadDetector.detect(
                    bitmap,
                    lastExclusion[0], lastExclusion[1], lastExclusion[2], lastExclusion[3]
                )
                bitmap.recycle()
                if (row != null && row.isNotEmpty()) {
                    consecutiveFails = 0
                    if (row == lastRow) {
                        rowStreak++
                    } else {
                        lastRow = row
                        rowStreak = 1
                    }
                    // fileira estável há alguns frames: confirma diferenças
                    if (rowStreak == NEW_BEAD_STABLE) {
                        onRowConfirmed(row)
                    }
                } else {
                    consecutiveFails++
                    if (consecutiveFails > 25) { lastRow = null; rowStreak = 0 }
                }
            }
        } finally {
            busy.set(false)
        }
    }

    /** Comparado com o estado salvo: tudo que ainda não foi registrado entra. */
    private fun onRowConfirmed(row: List<String>) {
        val current = RoundsStore.getSeq()
        val add = leadingDiff(row, current)
        if (add.isEmpty()) return
        var i = 0
        while (i < add.size) {
            DTEngine.addRound(add[i])   // DTEngine grava no RoundsStore (salva automático)
            i++
        }
    }

    /**
     * A fileira visível (esquerda→direita) mostra as N últimas rodadas.
     * `current` é a sequência acumulada, mais nova no FIM.
     * Devolve as rodadas novas (na ordem antigo→novo) ainda não registradas.
     */
    private fun leadingDiff(visible: List<String>, current: List<String>): List<String> {
        // últimas k rodadas de `current` devem casar com o final de `visible`
        val maxOverlap = min(visible.size, current.size)
        var bestK = 0
        for (k in maxOverlap downTo 1) {
            val curTail = current.subList(current.size - k, current.size)
            var ok = false
            // tenta casar curTail no fim de `visible`
            if (visible.size >= k) {
                val visTail = visible.subList(visible.size - k, visible.size)
                if (curTail == visTail) ok = true
            }
            if (ok) { bestK = k; break }
        }
        // se nada casou, pode ser mesa zerada — semeia a fileira inteira
        if (bestK == 0) {
            val fresh = visible.all { it == "D" || it == "S" || it == "T" }
            if (fresh && current.isEmpty()) {
                RoundsStore.seed(visible.reversed())
                return emptyList()
            }
            return emptyList()
        }
        val newOnLeft = visible.size - bestK
        if (newOnLeft <= 0) return emptyList()
        return visible.subList(0, newOnLeft).reversed() // antigo→novo
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val planes = image.planes
            if (planes.isEmpty()) return null
            val plane = planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - image.width * pixelStride
            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(buffer)
            val result = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            result
        } catch (_: Exception) {
            null
        }
    }

    /* ---------------- overlay ---------------- */

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val density = metrics.density
        val real = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm?.defaultDisplay?.getRealMetrics(real)
        screenH = if (real.heightPixels > 0) real.heightPixels else metrics.heightPixels

        val root = View.inflate(this, R.layout.overlay_root, null) as android.widget.LinearLayout
        overlayRoot = root

        val web = WebView(this)
        webView = web
        web.setBackgroundColor(0x00000000)
        web.settings.javaScriptEnabled = true
        web.settings.allowFileAccess = true
        web.addJavascriptInterface(bridge, "DTBridge")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript("DTsetMini(" + RoundsStore.minimized() + ")", null)
            }
        }
        web.loadUrl("about:blank")
        web.loadDataWithBaseURL(
            "file:///android_asset/www/", WebViewUi.html(), "text/html", "utf-8", null
        )
        root.addView(
            web,
            android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                fullHeightPx()
            )
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.x = 0
        params.y = if (RoundsStore.minimized() && RoundsStore.miniY() > 0) RoundsStore.miniY() else (24 * density).toInt()
        overlayParams = params
        wm?.addView(root, params)
        root.post { refreshExclusion() }
    }

    private fun fullHeightPx(): Int {
        val d = resources.displayMetrics.density
        return (screenH * 0.82f).toInt().coerceAtLeast((320 * d).toInt())
    }

    private fun refreshExclusion() {
        val root = overlayRoot ?: return
        val loc = IntArray(2)
        try { root.getLocationOnScreen(loc) } catch (_: Exception) { return }
        lastExclusion = intArrayOf(
            0,
            (loc[1] - 8).coerceAtLeast(0),
            Int.MAX_VALUE,
            loc[1] + root.height + 8
        )
    }

    /* ---------------- bridge JS ---------------- */

    inner class Bridge {
        @Volatile var dragEnabled: Boolean = false

        @JavascriptInterface
        fun getState(): String {
            return try {
                DTEngine.stateJson(true)
            } catch (e: Exception) {
                "{}"
            }
        }

        @JavascriptInterface
        fun sessions(): String {
            return try {
                RoundsStore.sessions().toString()
            } catch (e: Exception) { "[]" }
        }

        @JavascriptInterface
        fun toggleTie() { RoundsStore.setTieMode(!RoundsStore.tieMode()) }

        @JavascriptInterface
        fun archiveReset() {
            RoundsStore.archiveAndReset()
        }

        @JavascriptInterface
        fun copySeq() {
            val s = RoundsStore.getSeq()
            val text = s.joinToString(" ")
            val cb = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cb.setPrimaryClip(android.content.ClipData.newPlainText("DT", text))
            mainHandler.post {
                android.widget.Toast.makeText(this@CaptureOverlayService, "Sequência copiada (${s.size})", android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun setDrag(on: Boolean) { dragEnabled = on }

        /* ---- arraste do painel (chamado pelo HTML) ---- */

        @JavascriptInterface
        fun dragBegin() {
            lastTouchY = -1f
            mainHandler.post { dragStartY = overlayParams?.y ?: 0 }
        }

        @JavascriptInterface
        fun dragBy(screenY: Int) {
            mainHandler.post {
                val p = overlayParams ?: return@post
                if (lastTouchY < 0) { lastTouchY = screenY.toFloat(); return@post }
                val dy = screenY - lastTouchY
                lastTouchY = screenY.toFloat()
                p.y = (p.y + dy.toInt()).coerceIn(0, (screenH * 0.72f).toInt())
                try { overlayRoot?.let { wm?.updateViewLayout(it, p) } } catch (_: Exception) {}
                refreshExclusion()
            }
        }

        @JavascriptInterface
        fun dragEnd() {
            mainHandler.post {
                overlayParams?.let { RoundsStore.setMiniY(it.y) }
                lastTouchY = -1f
            }
        }

        @JavascriptInterface
        fun setMini(b: Boolean) {
            RoundsStore.setMinimized(b)
            mainHandler.post { applySize(b) }
        }

        @JavascriptInterface
        fun closeOverlay() {
            mainHandler.post { stopSelf() }
        }
    }

    private fun applySize(mini: Boolean) {
        val web = webView ?: return
        val root = overlayRoot ?: return
        val p = overlayParams
        val lp = web.layoutParams
        lp.height = if (mini) miniHeightPx() else fullHeightPx()
        web.layoutParams = lp
        root.requestLayout()
        try { p?.let { wm?.updateViewLayout(root, it) } } catch (_: Exception) {}
        root.post { refreshExclusion() }
    }

    private fun miniHeightPx(): Int {
        val d = resources.displayMetrics.density
        return (352 * d).toInt()
    }

    /* ---------------- notificação ---------------- */

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Leitura Dragon Tiger", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setContentTitle("Dragon Tiger — leitura automática")
            .setContentText("A análise está ativa sobre o jogo.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pi)
            .setOngoing(true)
        return b.build()
    }
}
