package com.infinity.dragontiger

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Motor de análise — porta fiel do motor v1.0 (app.js).
 * 5 sinais: Frequência, Markov 1, Markov 2, Sequência, Empate.
 * Os pesos aprendem por Hedge (log-loss) a cada rodada confirmada.
 * Estado único do processo: o serviço de captura grava as rodadas e
 * a Activity/overlay apenas leem [stateJson].
 */
object DTEngine {

    private const val SIG_N = 5
    private const val F_FREQ = 0
    private const val F_MK1 = 1
    private const val F_MK2 = 2
    private const val F_STREAK = 3
    private const val F_EMP = 4
    private val SIG_NAMES = arrayOf("Frequência", "Markov 1", "Markov 2", "Sequência", "Empate")

    private val w = DoubleArray(SIG_N) { 1.0 }
    private val seq = ArrayList<String>()
    private val hits = ArrayList<Int>()
    private var loaded = false
    private var lastVersion = -1

    class Pat(val name: String, val desc: String, val seq: List<String>)

    @Synchronized
    fun ensureLoaded() {
        if (loaded) {
            if (RoundsStore.version != lastVersion) reloadReplay()
            return
        }
        reloadReplay()
        loaded = true
    }

    @Synchronized
    fun reload() {
        loaded = false
        ensureLoaded()
    }

    /** usado após pop()/seed(): recalcula pesos e acertos do zero */
    @Synchronized
    fun undoLast() {
        if (RoundsStore.pop()) reload()
    }

    private fun reloadReplay() {
        seq.clear()
        seq.addAll(RoundsStore.getSeq())
        hits.clear()
        java.util.Arrays.fill(w, 1.0)
        val hist = ArrayList<String>(seq.size)
        for (actual in seq) {
            val pre = combine(hist)
            val winner = best(pre.first)
            hits.add(if (winner == actual) 1 else 0)
            if (hits.size > 400) hits.removeAt(0)
            learn(pre.second, actual)
            hist.add(actual)
        }
        lastVersion = RoundsStore.version
    }

    @Synchronized
    fun addRound(ch: String) {
        ensureLoaded()
        val pre = combine(seq)
        val winner = best(pre.first)
        learn(pre.second, ch)
        seq.add(ch)
        if (seq.size > 1200) seq.removeAt(0)
        hits.add(if (winner == ch) 1 else 0)
        if (hits.size > 400) hits.removeAt(0)
        RoundsStore.append(ch)
        RoundsStore.setLastRoundTs(System.currentTimeMillis())
        lastVersion = RoundsStore.version
    }

    /* ---------------- util ---------------- */

    private fun idxOf(ch: String): Int = when (ch) {
        "D" -> 0
        "S" -> 1
        else -> 2
    }

    private fun eq(): DoubleArray = doubleArrayOf(1.0 / 3, 1.0 / 3, 1.0 / 3)

    private fun norm(a: DoubleArray): DoubleArray {
        val t = a[0] + a[1] + a[2]
        if (!(t > 0)) return eq()
        return doubleArrayOf(a[0] / t, a[1] / t, a[2] / t)
    }

    private fun best(p: DoubleArray): String {
        return if (p[0] >= p[1] && p[0] >= p[2]) "D" else if (p[2] >= p[1]) "T" else "S"
    }

    private fun tailOf(h: List<String>): Pair<Int, String> {
        if (h.isEmpty()) return Pair(0, "")
        val s = h[h.size - 1]
        var n = 0
        var i = h.size - 1
        while (i >= 0 && h[i] == s) {
            n++
            i--
        }
        return Pair(n, s)
    }

    /* ---------------- sinais ---------------- */

    private fun sFreq(h: List<String>): DoubleArray {
        if (h.isEmpty()) return eq()
        val from = max(0, h.size - 12)
        val c = DoubleArray(3)
        for (i in from until h.size) c[idxOf(h[i])]++
        return norm(doubleArrayOf(c[0] + 0.6, c[1] + 0.6, c[2] + 0.6))
    }

    private fun sMk1(h: List<String>): DoubleArray {
        if (h.size < 3) return eq()
        val last = h[h.size - 1]
        val c = DoubleArray(3)
        for (i in 0 until h.size - 1) if (h[i] == last) c[idxOf(h[i + 1])]++
        return norm(doubleArrayOf(c[0] + 0.8, c[1] + 0.4, c[2] + 0.8))
    }

    private fun sMk2(h: List<String>): DoubleArray {
        if (h.size < 6) return sMk1(h)
        val base = sMk1(h)
        val k1 = h[h.size - 2]
        val k2 = h[h.size - 1]
        val c = DoubleArray(3)
        var n = 0
        for (i in 0 until h.size - 2) {
            if (h[i] == k1 && h[i + 1] == k2) {
                c[idxOf(h[i + 2])]++
                n++
            }
        }
        if (n < 3) {
            val q = 0.45
            val out = DoubleArray(3)
            for (i in 0..2) out[i] = (c[i] / max(n, 1)) * q + base[i] * (1 - q)
            return norm(out)
        }
        return norm(doubleArrayOf(c[0] + 0.7, c[1] + 0.3, c[2] + 0.7))
    }

    private fun sStreak(h: List<String>): DoubleArray {
        if (h.isEmpty()) return doubleArrayOf(0.46, 0.10, 0.44)
        val t = tailOf(h)
        if (t.second == "S") return doubleArrayOf(0.46, 0.10, 0.44)
        val keep = min(0.30 + t.first * 0.08, 0.78)
        return if (t.second == "D") doubleArrayOf(keep, (1 - keep) * 0.18, (1 - keep) * 0.82)
        else doubleArrayOf((1 - keep) * 0.82, (1 - keep) * 0.18, keep)
    }

    private fun sEmp(h: List<String>): DoubleArray {
        if (h.size < 8) return doubleArrayOf(0.46, 0.10, 0.44)
        var ties = 0
        var nonN = 0
        var nonD = 0
        for (ch in h) {
            if (ch == "S") ties++ else {
                nonN++
                if (ch == "D") nonD++
            }
        }
        val tiesRatio = ties.toDouble() / h.size
        val last = h[h.size - 1]
        val pt = min(0.34, tiesRatio * 1.15 + (if (last == "S") 0.10 else 0.0) + 0.03)
        val rest = 1 - pt
        val dr = if (nonN > 0) nonD.toDouble() / nonN else 0.5
        return doubleArrayOf(rest * dr, pt, rest * (1 - dr))
    }

    private fun combine(h: List<String>): Pair<DoubleArray, Array<DoubleArray>> {
        val parts = Array(SIG_N) { DoubleArray(3) }
        val out = DoubleArray(3)
        var tot = 0.0
        for (i in 0 until SIG_N) tot += w[i]
        if (!(tot > 0)) tot = 1.0
        for (i in 0 until SIG_N) {
            val p: DoubleArray = when (i) {
                F_FREQ -> sFreq(h)
                F_MK1 -> sMk1(h)
                F_MK2 -> sMk2(h)
                F_STREAK -> sStreak(h)
                else -> sEmp(h)
            }
            parts[i] = p
            val share = w[i] / tot
            for (j in 0..2) out[j] += p[j] * share
        }
        return Pair(norm(out), parts)
    }

    private fun learn(parts: Array<DoubleArray>, real: String) {
        val idx = idxOf(real)
        for (i in 0 until SIG_N) {
            val hit = max(parts[i][idx], 0.004)
            val loss = min(3.2, -ln(hit))
            w[i] = min(6.0, max(0.2, w[i] * exp(-0.55 * (loss - 1.05))))
        }
        var sum = 0.0
        for (i in 0 until SIG_N) sum += w[i]
        if (sum > 0) for (i in 0 until SIG_N) w[i] = w[i] * 5.0 / sum
    }

    /* ---------------- padrões (v1 + novos) ---------------- */

    private fun lbl(side: String) = if (side == "D") "DRAGÃO" else "TIGRE"

    fun patterns(h: List<String>): List<Pat> {
        if (h.isEmpty()) return listOf(Pat("SEM DADOS", "Aguardando a leitura da tela.", emptyList()))
        val out = ArrayList<Pat>()
        val t = tailOf(h)
        val side = t.second
        val n = t.first
        if (side != "S" && n >= 5) out.add(Pat("SURFE FORTE", "$n× ${lbl(side)} seguidos", h.takeLast(n)))
        if (side != "S" && n == 4) out.add(Pat("SURFE (4+)", "Sequência de 4 ${lbl(side)}", h.takeLast(4)))
        val l6 = h.takeLast(6)
        if (l6.size == 6 && !l6.contains("S")) {
            val tripla = l6[0] == l6[1] && l6[1] == l6[2] && l6[3] == l6[4] && l6[4] == l6[5] && l6[2] != l6[3]
            if (tripla) out.add(Pat("TRIPLAS", "Blocos de 3 por lado", l6))
        }
        if (side != "S" && n == 3) out.add(Pat("SEQUÊNCIA 3", "3× ${lbl(side)} seguidos", h.takeLast(3)))
        var alt = 0
        var i = h.size - 1
        while (i > 0) {
            if (h[i] == "S" || h[i - 1] == "S" || h[i] == h[i - 1]) break
            alt++
            i--
        }
        if (alt >= 4) out.add(Pat("ZIGUE-ZAGUE", "${alt + 1} alternâncias", h.takeLast(alt + 1)))
        val l4 = h.takeLast(4).joinToString("")
        if (l4 == "DDTT" || l4 == "TTDD") out.add(Pat("DUPLAS", "Blocos de 2 por lado", h.takeLast(4)))
        val last12 = h.takeLast(12).filter { it != "S" }
        if (last12.size >= 8) {
            val d = last12.count { it == "D" }
            val tt = last12.size - d
            if (d * 100 >= last12.size * 70) out.add(Pat("DOMINÂNCIA AZUL", "$d de ${last12.size} para o DRAGÃO", h.takeLast(12)))
            else if (tt * 100 >= last12.size * 70) out.add(Pat("DOMINÂNCIA VERMELHA", "$tt de ${last12.size} para o TIGRE", h.takeLast(12)))
        }
        if (h.isNotEmpty() && h[h.size - 1] == "S") out.add(Pat("PÓS-EMPATE", "Rodada logo após empate", h.takeLast(3)))
        if (l6.contains("S")) out.add(Pat("EMPATE NO RADAR", "Empate nas últimas 6", l6))
        if (out.isEmpty()) out.add(Pat("SEM PADRÃO CLARO", "Histórico misto", l6))
        return out
    }

    /* ---------------- formatação ---------------- */

    private fun pct(x: Double): String {
        return String.format(Locale.US, "%.1f", x * 100).replace('.', ',') + "%"
    }

    private fun fmt2(x: Double): String = String.format(Locale.US, "%.2f", x)

    private fun qualityTxt(n: Int): String = when {
        n >= 20 -> "ALTA"
        n >= 8 -> "MÉDIA"
        n == 0 -> "SEM DADOS"
        else -> "BAIXA"
    }

    private fun tieSignalTxt(p1: Double): String {
        val nivel = when {
            p1 >= 0.15 -> "médio"
            p1 >= 0.10 -> "baixo"
            else -> "raro"
        }
        return "Sinal de empate: $nivel (${pct(p1)})"
    }

    /* ---------------- estado p/ UI ---------------- */

    @Synchronized
    fun stateJson(captureActive: Boolean): String {
        ensureLoaded()
        val n = seq.size
        val c = combine(seq)
        val p = c.first
        val pats = patterns(seq)
        val main = pats.first()

        val o = JSONObject()
        o.put("v", RoundsStore.version)
        o.put("capture", captureActive)
        o.put("tieMode", RoundsStore.tieMode())
        o.put("n", n)
        o.put("pD", p[0])
        o.put("pS", p[1])
        o.put("pT", p[2])
        o.put("last10", JSONArray(seq.takeLast(10).reversed()))

        val pm = JSONObject()
        pm.put("name", main.name)
        pm.put("desc", main.desc)
        pm.put("seq", JSONArray(main.seq.reversed()))
        o.put("pattern", pm)

        val arr = JSONArray()
        for (pt in pats) {
            val x = JSONObject()
            x.put("name", pt.name)
            x.put("desc", pt.desc)
            x.put("seq", JSONArray(pt.seq.reversed()))
            arr.put(x)
        }
        o.put("patterns", arr)

        val tr = JSONObject()
        tr.put("dir", if (abs(p[0] - p[2]) < 0.03) "EQUILIBRADO" else if (p[0] > p[2]) "AZUL" else "VERMELHO")
        tr.put("up", p[0] >= p[2])
        tr.put("tieSignal", tieSignalTxt(p[1]))
        o.put("trend", tr)

        val win = best(p)
        val winIdx = idxOf(win)
        val orc = JSONObject()
        if (n == 0) {
            orc.put("text", "AGUARDE")
            orc.put("conf", "aguardando a leitura…")
            orc.put("kind", "wait")
        } else if (RoundsStore.tieMode()) {
            if (win == "S") {
                orc.put("text", "ENTRE NO EMPATE")
                orc.put("kind", "S")
            } else {
                orc.put("text", "AGUARDE EMPATE")
                orc.put("kind", "wait")
            }
            orc.put("conf", "confiança " + pct(p[1]))
        } else if (p[winIdx] >= 0.44) {
            orc.put("text", "ENTRE NO " + when (win) {
                "D" -> "DRAGÃO"
                "T" -> "TIGRE"
                else -> "EMPATE"
            })
            orc.put("kind", win)
            orc.put("conf", "confiança " + pct(p[winIdx]))
        } else {
            orc.put("text", "SEM VANTAGEM")
            orc.put("kind", "wait")
            orc.put("conf", "confiança baixa · " + pct(p[winIdx]))
        }
        o.put("orient", orc)

        o.put("quality", qualityTxt(n))
        val ts = RoundsStore.lastRoundTs()
        o.put("ageMs", if (ts > 0) System.currentTimeMillis() - ts else -1L)

        o.put("road", JSONArray(seq.takeLast(84).reversed()))
        o.put("roadCount", n)

        val h40 = hits.takeLast(40)
        o.put("hit40", if (h40.isEmpty()) -1.0 else h40.average())
        o.put("hitAll", if (hits.isEmpty()) -1.0 else hits.average())
        o.put("nHits", hits.size)

        var dC = 0
        var sC = 0
        var tC = 0
        for (ch in seq) when (ch) {
            "D" -> dC++
            "S" -> sC++
            else -> tC++
        }
        o.put("dC", dC)
        o.put("sC", sC)
        o.put("tC", tC)
        o.put("maxStreak", RoundsStore.maxStreakOf(seq))
        val tl = tailOf(seq)
        val cs = JSONObject()
        cs.put("side", tl.second)
        cs.put("n", tl.first)
        o.put("curStreak", cs)

        val dist = JSONObject()
        dist.put("d", if (n == 0) 0.0 else dC.toDouble() / n)
        dist.put("s", if (n == 0) 0.0 else sC.toDouble() / n)
        dist.put("t", if (n == 0) 0.0 else tC.toDouble() / n)
        o.put("dist", dist)

        var dev = 0.0
        for (i in 0 until SIG_N) dev += abs(w[i] - 1.0)
        o.put("learnPct", min(100.0, dev / 5.0 * 100.0).toInt())

        val sortedIdx = (0 until SIG_N).sortedByDescending { w[it] }
        val lead = sortedIdx[0]
        val weak = sortedIdx[SIG_N - 1]
        val ins = StringBuilder()
        ins.append("<b>Melhor indicador agora: ").append(SIG_NAMES[lead]).append("</b> (peso ").append(fmt2(w[lead])).append(").<br>")
        ins.append("Menos confiável: ").append(SIG_NAMES[weak]).append(" (peso ").append(fmt2(w[weak])).append(").<br>")
        ins.append("Pesos: ")
            .append((0 until SIG_N).joinToString(" · ") { SIG_NAMES[it] + " " + fmt2(w[it]) })
            .append("<br>")
        ins.append(
            if (n < 20) "Amostra pequena: os pesos estabilizam a partir de ~20 rodadas."
            else "$n rodadas registradas — calibração razoável do seu histórico."
        )
        o.put("insights", ins.toString())
        o.put("seqPreview", JSONArray(seq.takeLast(60).reversed()))
        return o.toString()
    }
}
