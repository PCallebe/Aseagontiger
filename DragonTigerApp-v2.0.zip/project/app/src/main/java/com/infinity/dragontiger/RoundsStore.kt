package com.infinity.dragontiger

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Armazenamento único do processo: sequência atual + sessões arquivadas.
 * Salva automaticamente a cada rodada. O Zerar ARQUIVA a sessão —
 * nunca apaga o histórico.
 */
object RoundsStore {

    private const val PREFS = "dt_store"
    private const val KEY_SEQ = "seq"
    private const val KEY_SESSIONS = "sessions"
    private const val KEY_TIE = "tie_mode"
    private const val KEY_LAST_TS = "last_round_ts"
    private const val KEY_MINI = "mini"
    private const val KEY_MINI_Y = "mini_y"
    private const val MAX_SEQ = 1200
    private const val MAX_SESSIONS = 60

    private lateinit var prefs: SharedPreferences

    @Volatile
    var version: Int = 0
        private set

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) {
            prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            version = 1
        }
    }

    private fun ready(): Boolean = ::prefs.isInitialized

    fun getSeq(): List<String> {
        if (!ready()) return emptyList()
        return try {
            val a = JSONArray(prefs.getString(KEY_SEQ, "[]") ?: "[]")
            val out = ArrayList<String>(a.length())
            for (i in 0 until a.length()) {
                val v = a.optString(i)
                if (v == "D" || v == "S" || v == "T") out.add(v)
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun append(ch: String) {
        val s = getSeq().toMutableList()
        s.add(ch)
        if (s.size > MAX_SEQ) s.subList(0, s.size - MAX_SEQ).clear()
        saveSeq(s)
    }

    @Synchronized
    fun pop(): Boolean {
        val s = getSeq().toMutableList()
        if (s.isEmpty()) return false
        s.removeAt(s.size - 1)
        saveSeq(s)
        return true
    }

    @Synchronized
    fun seed(row: List<String>) {
        val s = row.filter { it == "D" || it == "S" || it == "T" }.takeLast(MAX_SEQ)
        saveSeq(s)
    }

    @Synchronized
    fun archiveAndReset(): Int {
        val s = getSeq()
        val n = s.size
        if (n > 0 && ready()) {
            var dC = 0
            var sC = 0
            var tC = 0
            for (ch in s) when (ch) {
                "D" -> dC++
                "S" -> sC++
                else -> tC++
            }
            val o = JSONObject()
            o.put("ts", System.currentTimeMillis())
            o.put("n", n)
            o.put("d", dC)
            o.put("s", sC)
            o.put("t", tC)
            o.put("maxStreak", maxStreakOf(s))
            val arr = try {
                JSONArray(prefs.getString(KEY_SESSIONS, "[]") ?: "[]")
            } catch (e: Exception) {
                JSONArray()
            }
            val out = JSONArray()
            out.put(o)
            for (i in 0 until arr.length()) {
                if (out.length() >= MAX_SESSIONS) break
                out.put(arr.get(i))
            }
            prefs.edit().putString(KEY_SESSIONS, out.toString()).apply()
        }
        saveSeq(emptyList())
        return n
    }

    fun sessions(): JSONArray {
        if (!ready()) return JSONArray()
        return try {
            JSONArray(prefs.getString(KEY_SESSIONS, "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
    }

    @Synchronized
    fun clearSessions() {
        if (!ready()) return
        prefs.edit().putString(KEY_SESSIONS, "[]").apply()
        version++
    }

    fun tieMode(): Boolean = ready() && prefs.getBoolean(KEY_TIE, false)

    @Synchronized
    fun setTieMode(b: Boolean) {
        if (!ready()) return
        prefs.edit().putBoolean(KEY_TIE, b).apply()
        version++
    }

    fun lastRoundTs(): Long = if (ready()) prefs.getLong(KEY_LAST_TS, 0L) else 0L

    @Synchronized
    fun setLastRoundTs(ts: Long) {
        if (!ready()) return
        prefs.edit().putLong(KEY_LAST_TS, ts).apply()
    }

    fun minimized(): Boolean = ready() && prefs.getBoolean(KEY_MINI, false)

    @Synchronized
    fun setMinimized(b: Boolean) {
        if (!ready()) return
        prefs.edit().putBoolean(KEY_MINI, b).apply()
    }

    fun introShown(): Boolean = ready() && prefs.getBoolean("intro_shown", false)

    fun setIntroShown() {
        if (!ready()) return
        prefs.edit().putBoolean("intro_shown", true).apply()
    }

    fun miniY(): Int = if (ready()) prefs.getInt(KEY_MINI_Y, 0) else 0

    @Synchronized
    fun setMiniY(y: Int) {
        if (!ready()) return
        prefs.edit().putInt(KEY_MINI_Y, y).apply()
    }

    private fun saveSeq(s: List<String>) {
        if (!ready()) return
        val a = JSONArray()
        for (ch in s) a.put(ch)
        prefs.edit().putString(KEY_SEQ, a.toString()).apply()
        version++
    }

    fun maxStreakOf(s: List<String>): Int {
        var maxRun = 0
        var run = 0
        var prev: String? = null
        for (ch in s) {
            if (ch == "S") {
                prev = null
                run = 0
                continue
            }
            if (ch == prev) run++ else {
                run = 1
                prev = ch
            }
            if (run > maxRun) maxRun = run
        }
        return maxRun
    }
}
