package com.infinity.dragontiger

/**
 * UI do painel flutuante (WebView) — fiel ao layout v1.0 dos anexos.
 * Botões menores, resultados com o mais novo à ESQUERDA, seções:
 * Padrões, Histórico, Método Empate. Sem botões manuais de marcação.
 */
object WebViewUi {

    fun html(): String = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1, user-scalable=no">
<meta name="theme-color" content="#05090f">
<title>Dragon Tiger</title>
<style>
:root{--blue:#2ea8ff;--red:#ff3b4e;--gold:#ffd23f;--ink:#eaf4ff;--muted:#8fa6c2;}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html,body{margin:0;padding:0;}
body{
  font-family:-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
  background:transparent;color:var(--ink);min-height:0;overflow:hidden;
  padding:0 0 8px;
}
.wrap{max-width:560px;margin:0 auto;}
.panel{border-radius:16px;overflow:hidden;margin-bottom:8px;
  background:linear-gradient(180deg,rgba(14,29,49,.97),rgba(6,14,25,.99));
  border:1px solid rgba(64,146,255,.35);
  box-shadow:0 10px 30px rgba(0,0,0,.65),0 0 22px rgba(30,120,255,.18);}
.head{position:relative;display:flex;align-items:center;justify-content:center;padding:10px 8px 7px;
  background:radial-gradient(60% 120% at 12% 50%,rgba(46,168,255,.30),transparent 65%),
             radial-gradient(60% 120% at 88% 50%,rgba(255,59,78,.28),transparent 65%),
             linear-gradient(180deg,#0b1a2d,#081120);
  border-bottom:1px solid rgba(80,150,255,.22);}
.beast{position:absolute;top:1px;width:58px;height:42px;object-fit:contain;}
.beast.l{left:0}.beast.r{right:0}
.title{font-weight:900;font-size:18px;letter-spacing:2px;line-height:1;padding-left:6px;
  background:linear-gradient(92deg,#7fd4ff 0%,#eaf6ff 42%,#ffb0a8 68%,#ff5c6c 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;}
.pillbar{position:absolute;right:6px;top:4px;display:flex;gap:4px;align-items:center;}
.hud{display:flex;gap:4px;}
.hbtn2{width:20px;height:20px;border-radius:6px;background:rgba(255,255,255,.10);
  border:1px solid rgba(255,255,255,.25);color:#fff;font-size:11px;font-weight:900;
  display:flex;align-items:center;justify-content:center;}
.pill{font-size:8px;font-weight:800;letter-spacing:.4px;padding:3px 6px;border-radius:20px;
  background:rgba(20,60,40,.92);color:#8ff0b6;border:1px solid rgba(60,220,130,.55);
  display:flex;align-items:center;gap:4px;white-space:nowrap;}
.pill.off{background:rgba(60,40,20,.92);color:#ffd8a6;border-color:rgba(255,180,80,.5);}
.dot{width:6px;height:6px;border-radius:50%;background:#39e08a;box-shadow:0 0 8px #39e08a;animation:blip 1.6s infinite;}
.pill.off .dot{background:#ffb35c;box-shadow:0 0 8px #ffb35c;}
@keyframes blip{0%,100%{opacity:1}50%{opacity:.25}}

.probs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;padding:8px 8px 2px;}
.pbox{border-radius:10px;padding:5px 3px 6px;text-align:center;
  background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(0,0,0,.25));
  border:1px solid rgba(255,255,255,.10);}
.pbox.d{border-color:rgba(64,180,255,.75);box-shadow:0 0 12px rgba(46,168,255,.30) inset;}
.pbox.s{border-color:rgba(60,230,140,.7);box-shadow:0 0 12px rgba(60,230,140,.25) inset;}
.pbox.t{border-color:rgba(255,80,95,.75);box-shadow:0 0 12px rgba(255,59,78,.30) inset;}
.pbox .lbl{font-size:8.5px;letter-spacing:.9px;font-weight:800;color:var(--muted);}
.pbox.d .lbl{color:#8fd4ff}.pbox.s .lbl{color:#8ff0b6}.pbox.t .lbl{color:#ffb0b8}
.pbox .val{font-size:17px;font-weight:900;margin-top:1px;}
.pbox.d .val{color:#cfeaff}.pbox.s .val{color:#b6ffd4}.pbox.t .val{color:#ffd0d5}

.sect{padding:6px 8px 2px;}
.sect h3{margin:0 0 5px;font-size:9.5px;letter-spacing:1.5px;color:#9fb6d0;font-weight:900;text-align:center;}
.beads{display:flex;gap:4px;justify-content:center;flex-wrap:nowrap;}
.bead{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:900;color:#fff;flex:0 0 auto;border:1.5px solid rgba(255,255,255,.25);
  box-shadow:0 2px 6px rgba(0,0,0,.5);}
.bead.D{background:radial-gradient(circle at 32% 28%,#7fd0ff,#1673c9 60%,#0a3f78);
  border-color:rgba(120,200,255,.85);box-shadow:0 0 9px rgba(46,168,255,.55);}
.bead.T{background:radial-gradient(circle at 32% 28%,#ff8a92,#d21f31 60%,#7d0d18);
  border-color:rgba(255,120,130,.8);box-shadow:0 0 9px rgba(255,59,78,.5);}
.bead.S{background:radial-gradient(circle at 32% 28%,#b6ffd0,#1aa860 60%,#0a6437);
  border-color:rgba(90,240,150,.85);box-shadow:0 0 9px rgba(37,208,122,.45);}
.bead.ghost{background:rgba(255,255,255,.05);border:1px dashed rgba(255,255,255,.16);color:#33455c;box-shadow:none;}
.bead.mini{width:17px;height:17px;font-size:8.5px;}
.newtag{font-size:7.5px;color:#39e08a;font-weight:900;text-align:center;margin-top:3px;letter-spacing:1px;}

.card{margin:6px 8px;border-radius:11px;padding:7px 9px;
  background:linear-gradient(180deg,rgba(255,255,255,.045),rgba(0,0,0,.22));
  border:1px solid rgba(255,255,255,.10);}
.pat{display:flex;align-items:center;gap:7px;border-color:rgba(60,230,140,.55);
  box-shadow:0 0 14px rgba(60,230,140,.14) inset;}
.chk{width:24px;height:24px;border-radius:50%;border:2px solid #39e08a;display:flex;
  align-items:center;justify-content:center;flex:0 0 auto;box-shadow:0 0 10px rgba(57,224,138,.5);}
.ck{color:#39e08a;font-weight:900;font-size:14px;}
.pat .txt{flex:1;min-width:0;}
.kicker{font-size:8px;letter-spacing:1px;font-weight:800;color:#8ff0b6;}
.sub{font-size:9px;color:#8fa6bd;margin-top:1px;}
.kk{font-size:8.5px;color:#9fb6d0;letter-spacing:1px;font-weight:800;}
.big{font-size:14.5px;font-weight:800;color:#fff;margin-top:1px;}
.small{font-size:9px;color:#8fa6bd;margin-top:2px;}
.seq{display:flex;gap:3px;}

.row{display:grid;grid-template-columns:1fr 1px 1fr;gap:7px;align-items:center;}
.vline{height:40px;background:linear-gradient(180deg,transparent,rgba(120,170,230,.45),transparent);}
.arrow{font-size:14px;line-height:1;}
.trend{font-weight:800;font-size:12px;letter-spacing:.2px;}
.orient{display:flex;gap:6px;align-items:center;}
.warn{width:20px;height:20px;border-radius:50%;border:2px solid #ffd23f;color:#ffd23f;
  display:flex;align-items:center;justify-content:center;font-weight:900;font-size:12px;flex:0 0 auto;
  box-shadow:0 0 10px rgba(255,210,63,.45);}
.goto{font-size:12px;font-weight:800;line-height:1.15;letter-spacing:.2px;}
.conf{font-size:8px;color:#8fa6bd;margin-top:2px;}

.foot{display:flex;justify-content:space-between;align-items:center;padding:6px 8px 8px;
  border-top:1px solid rgba(80,150,255,.18);margin-top:5px;}
.foot div{font-size:8.5px;color:#9fb6d0;display:flex;align-items:center;gap:5px;font-weight:700;}

.rowbtn{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin:0 0 8px;}
.rbtn{border-radius:11px;padding:8px 2px;background:rgba(255,255,255,.06);color:#cfe0f2;
  border:1px solid rgba(255,255,255,.14);font-size:9.5px;font-weight:800;text-align:center;letter-spacing:.3px;}
.rbtn:active{background:rgba(255,255,255,.16);}
.rbtn.on{background:rgba(46,168,255,.22);border-color:rgba(64,180,255,.55);color:#bfe2ff;}

.list{margin:0 8px 8px;display:none;}
.list.open{display:block;}
.pitem{display:flex;align-items:center;gap:7px;border-radius:10px;padding:6px 8px;margin-bottom:5px;
  background:linear-gradient(180deg,rgba(255,255,255,.045),rgba(0,0,0,.22));
  border:1px solid rgba(60,230,140,.30);}
.pitem .nm{font-weight:800;font-size:11px;color:#eaf6ff;}
.pitem .ds{font-size:8.5px;color:#8fa6bd;}
.hitem{border-radius:10px;padding:6px 8px;margin-bottom:5px;
  background:linear-gradient(180deg,rgba(255,255,255,.045),rgba(0,0,0,.22));
  border:1px solid rgba(64,180,255,.30);font-size:9.5px;color:#cfe0f2;}
.hitem b{color:#fff;}
.hbtns{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:6px 8px 10px;}
.hbtn{border-radius:10px;padding:8px 2px;background:rgba(255,210,63,.10);color:#ffe08a;
  border:1px solid rgba(255,210,63,.35);font-size:9.5px;font-weight:800;text-align:center;}
.hbtn.blue{background:rgba(46,168,255,.12);color:#bfe2ff;border-color:rgba(64,180,255,.4);}

.sec-head{display:flex;align-items:center;justify-content:space-between;margin:10px 2px 6px;}
.sec-head h2{margin:0;font-size:10px;letter-spacing:1.5px;color:#a9c2dd;font-weight:900;}
.badge{font-size:8.5px;padding:3px 7px;border-radius:20px;background:rgba(46,168,255,.15);
  color:#8fd4ff;border:1px solid rgba(64,180,255,.4);font-weight:800;}
.road{display:grid;grid-auto-flow:column;grid-template-rows:repeat(6,1fr);gap:3px;
  overflow-x:auto;padding:2px 0 4px;}
.road .bead{width:21px;height:21px;font-size:9px;}
.road::-webkit-scrollbar{height:0;}

.stats{display:grid;grid-template-columns:1fr 1fr;gap:7px;}
.stat{border-radius:11px;padding:7px 9px;border:1px solid rgba(255,255,255,.1);
  background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(0,0,0,.2));}
.stat .k{font-size:8px;letter-spacing:.7px;color:#8fa6bd;font-weight:800;}
.stat .v{font-size:15px;font-weight:900;margin-top:2px;}
.stat .v small{font-size:8.5px;color:#8fa6bd;font-weight:700;}
.bar{height:7px;border-radius:6px;background:rgba(255,255,255,.09);overflow:hidden;margin-top:6px;display:flex;}
.bar i{display:block;height:100%;}

.ins{font-size:9.5px;line-height:1.55;color:#c6d6e8;}
.alert{border-radius:11px;padding:8px 10px;font-size:9px;line-height:1.45;color:#c6d6e8;
  background:rgba(255,210,63,.07);border:1px solid rgba(255,210,63,.28);margin-top:9px;}
.alert b{color:#ffe08a;}
.tap-note{font-size:8px;color:#546b85;text-align:center;margin-top:6px;}
.tieon{color:#8ff0b6;}
</style>
</head>
<body>
<div class="wrap">

  <div class="panel">
    <div class="head">
      <img class="beast l" src="dragon_neon.png" alt="">
      <div class="title">DRAGON TIGER</div>
      <img class="beast r" src="tiger_neon.png" alt="">
      <div class="pillbar"><div class="pill" id="pill"><span class="dot"></span><span id="pillTxt">ANÁLISE ATIVA</span></div>
        <div class="hud"><div class="hbtn2" id="btnMini">▾</div><div class="hbtn2" id="btnClose">✕</div></div>
      </div>
    </div>

    <div class="probs">
      <div class="pbox d"><div class="lbl">DRAGÃO</div><div class="val" id="pD">—</div></div>
      <div class="pbox s"><div class="lbl">EMPATE</div><div class="val" id="pS">—</div></div>
      <div class="pbox t"><div class="lbl">TIGRE</div><div class="val" id="pT">—</div></div>
    </div>

    <div class="sect">
      <h3>ÚLTIMAS 10 RODADAS</h3>
      <div class="beads" id="last10"></div>
      <div class="newtag">◀ NOVO NA ESQUERDA</div>
    </div>

    <div class="card pat">
      <div class="chk"><span class="ck">✓</span></div>
      <div class="txt">
        <div class="kicker">PADRÃO IDENTIFICADO</div>
        <div class="big" id="patName">—</div>
        <div class="small" id="patDesc">—</div>
      </div>
      <div class="seq" id="patSeq"></div>
    </div>

    <div class="card">
      <div class="kk">LEITURA PARA PRÓXIMA RODADA</div>
      <div class="row" style="margin-top:6px">
        <div>
          <div class="arrow" id="trendIcon">📊</div>
          <div class="trend" id="trendTxt">TENDÊNCIA: —</div>
          <div class="small" id="tieSignal">Sinal de empate: —</div>
        </div>
        <div class="vline"></div>
        <div class="orient">
          <div class="warn">!</div>
          <div>
            <div class="goto" id="orient">AGUARDE</div>
            <div class="conf" id="confTxt">sem dados</div>
          </div>
        </div>
      </div>
    </div>

    <div class="foot">
      <div><span id="qIcon" style="color:#39e08a">●</span> Qualidade: <b id="quality">SEM DADOS</b></div>
      <div id="ageTxt">⏱ —</div>
    </div>
  </div>

  <div class="rowbtn">
    <div class="rbtn" id="btnPatterns" onclick="toggleSec('secPatterns',this)">🧩 PADRÕES</div>
    <div class="rbtn" id="btnHist" onclick="toggleSec('secHist',this)">🕓 HISTÓRICO</div>
    <div class="rbtn" id="btnTie" onclick="doTie()">🟢 MÉTODO EMPATE</div>
  </div>

  <div class="list" id="secPatterns">
    <div class="panel" style="padding:8px 8px 4px">
      <div class="kk" style="padding:2px 4px 6px">TODOS OS PADRÕES ATIVOS AGORA</div>
      <div id="patList"></div>
    </div>
  </div>

  <div class="list" id="secHist">
    <div class="panel" style="padding:8px 8px 4px">
      <div class="kk" style="padding:2px 4px 6px">SESSÕES SALVAS (arquivadas ao Zerar — nunca apagadas)</div>
      <div id="histList"></div>
    </div>
    <div class="hbtns">
      <div class="hbtn" onclick="doArchive()">📦 ARQUIVAR E ZERAR</div>
      <div class="hbtn blue" onclick="doCopy()">⧉ COPIAR SEQUÊNCIA</div>
    </div>
  </div>

  <div class="sec-head"><h2>CAMINHO DAS BOLINHAS</h2><div class="badge" id="roadCount">0 rodadas</div></div>
  <div class="panel" style="padding:7px 7px 2px;margin-bottom:8px">
    <div class="road" id="road"></div>
  </div>

  <div class="sec-head"><h2>DESEMPENHO DO MOTOR</h2><div class="badge" id="learnBadge">aprendizado 0%</div></div>
  <div class="stats">
    <div class="stat"><div class="k">ACERTO (ÚLTIMAS 40)</div><div class="v" id="hit40">—</div></div>
    <div class="stat"><div class="k">ACERTO TOTAL</div><div class="v" id="hitAll">—</div></div>
    <div class="stat"><div class="k">DRAGÃO × TIGRE</div><div class="v" id="dt">—</div></div>
    <div class="stat"><div class="k">EMPATES</div><div class="v" id="tieStat">—</div></div>
    <div class="stat"><div class="k">MAIOR SEQUÊNCIA</div><div class="v" id="maxStreak">—</div></div>
    <div class="stat"><div class="k">SEQUÊNCIA ATUAL</div><div class="v" id="curStreak">—</div></div>
    <div class="stat" style="grid-column:1/-1">
      <div class="k">DISTRIBUIÇÃO (AMOSTRA TOTAL)</div>
      <div class="v" id="distTxt" style="font-size:11px">—</div>
      <div class="bar" id="distBar"></div>
    </div>
  </div>

  <div class="sec-head"><h2>O QUE O MOTOR ESTÁ LENDO</h2></div>
  <div class="panel" style="padding:9px">
    <div id="insights" class="ins">Aguardando a leitura automática…</div>
  </div>

  <div class="alert">
    <b>Transparência:</b> cada rodada é aleatória e independente — nenhum padrão garante a próxima.
    O app mede o seu histórico real e mostra a tendência observada, junto com a taxa de acerto medida
    do próprio motor. Quanto mais rodadas você registra, mais calibrado ele fica. Não é promessa de ganho.
  </div>
  <div class="tap-note">Leitura automática da tela • v2.0 • offline • arraste pelo cabeçalho</div>
</div>

<script>
var MINI = false;
function bead(ch, extra){
  var cls = ch === "." ? "ghost" : ch;
  var txt = ch === "." ? "·" : ch;
  return '<div class="bead ' + cls + (extra ? " " + extra : "") + '">' + txt + '</div>';
}
function pct(x){ return (x*100).toFixed(1).replace(".", ",") + "%"; }
function bp(ch){ return ch === "D" ? "#8fd4ff" : ch === "T" ? "#ffb0b8" : "#8ff0b6"; }
function toggleSec(id, btn){
  var el = document.getElementById(id);
  var open = el.className.indexOf("open") >= 0;
  if (open){ el.className = "list"; btn.className = "rbtn"; }
  else {
    el.className = "list open"; btn.className = "rbtn on";
    if (id === "secHist") fillHist();
  }
}
function doTie(){
  try { window.DTBridge.toggleTie(); } catch(e){}
}
document.getElementById("btnMini").addEventListener("click", function(){
  try { window.DTBridge.setMini(!MINI); } catch(e){ DTsetMini(!MINI); }
});
document.getElementById("btnClose").addEventListener("click", function(){
  try { window.DTBridge.closeOverlay(); } catch(e){}
});
/* arraste do painel minimizado (dedo em qualquer lugar do painel) */
document.addEventListener("touchstart", function(e){
  if (!MINI) return;
  try { window.DTBridge.dragBegin(); } catch(err){}
}, {passive:true});
document.addEventListener("touchmove", function(e){
  if (!MINI) return;
  var t = e.touches[0];
  if (!t) return;
  try { window.DTBridge.dragBy(Math.round(t.clientY)); } catch(err){}
}, {passive:true});
document.addEventListener("touchend", function(e){
  if (!MINI) return;
  try { window.DTBridge.dragEnd(); } catch(err){}
}, {passive:true});
function doArchive(){
  if (confirm("Arquivar a sessão atual no histórico e zerar a sequência?")){
    try { window.DTBridge.archiveReset(); } catch(e){}
    fillHist();
  }
}
function doCopy(){
  try { window.DTBridge.copySeq(); } catch(e){}
}
function fillHist(){
  var host = document.getElementById("histList");
  var html = "";
  try {
    var s = JSON.parse(window.DTBridge.sessions());
    if (!s.length) html = '<div class="hitem">Nenhuma sessão arquivada ainda. Use ARQUIVAR E ZERAR ao fim de uma mesa.</div>';
    for (var i = 0; i < s.length; i++){
      var o = s[i];
      var d = new Date(o.ts);
      var dt = ("0"+d.getDate()).slice(-2) + "/" + ("0"+(d.getMonth()+1)).slice(-2) + " " + ("0"+d.getHours()).slice(-2) + ":" + ("0"+d.getMinutes()).slice(-2);
      html += '<div class="hitem"><b>#' + (s.length - i) + '</b> • ' + dt + ' — <b>' + o.n + '</b> rodadas • ' +
        '<span style="color:#8fd4ff">D ' + o.d + '</span> · <span style="color:#8ff0b6">S ' + o.s + '</span> · <span style="color:#ffb0b8">T ' + o.t + '</span>' +
        ' • máx ' + o.maxStreak + '</div>';
    }
  } catch(e){ html = '<div class="hitem">—</div>'; }
  host.innerHTML = html;
}

function DTsetMini(m){
  MINI = m;
  var hide = MINI ? "none" : "";
  var secs = document.querySelectorAll(".sec-head, .stats, .alert, .tap-note, .rowbtn, .list");
  for (var i = 0; i < secs.length; i++) secs[i].style.display = hide;
  var roadPanel = document.getElementById("road") ? document.getElementById("road").parentNode : null;
  if (roadPanel) roadPanel.style.display = hide;
  document.getElementById("btnMini").textContent = MINI ? "▴" : "▾";
  document.body.style.overflow = MINI ? "hidden" : "auto";
  try { window.DTBridge.setDrag(MINI); } catch(e){}
}

function render(st){
  var n = st.n;
  document.getElementById("pD").textContent = n ? pct(st.pD) : "—";
  document.getElementById("pS").textContent = n ? pct(st.pS) : "—";
  document.getElementById("pT").textContent = n ? pct(st.pT) : "—";

  var h10 = "";
  var l10 = st.last10;
  for (var i = 0; i < l10.length; i++) h10 += bead(l10[i]);
  for (var g = l10.length; g < 10; g++) h10 += bead(".");
  document.getElementById("last10").innerHTML = h10;

  var pm = st.pattern;
  document.getElementById("patName").textContent = pm.name;
  document.getElementById("patDesc").textContent = pm.desc;
  var ps = "";
  for (var q = 0; q < pm.seq.length && q < 5; q++) ps += bead(pm.seq[q], "mini");
  document.getElementById("patSeq").innerHTML = ps;

  var tr = st.trend;
  document.getElementById("trendIcon").textContent = n ? (tr.up ? "📈" : "📉") : "📊";
  var tcol = tr.dir === "AZUL" ? "#7fd3ff" : tr.dir === "VERMELHO" ? "#ff8e99" : "#cfe0f2";
  document.getElementById("trendTxt").innerHTML = 'TENDÊNCIA: <span style="color:' + tcol + '">' + tr.dir + (tr.dir === "EQUILIBRADO" ? "" : (tr.up ? " ↑" : " ↑")) + '</span>';
  document.getElementById("tieSignal").textContent = tr.tieSignal;

  var orc = st.orient;
  var og = document.getElementById("orient");
  og.textContent = orc.text;
  og.style.color = orc.kind === "D" ? "#7fd4ff" : orc.kind === "T" ? "#ff9aa4" : orc.kind === "S" ? "#8ff0b6" : "#ffd23f";
  document.getElementById("confTxt").textContent = orc.conf;

  var q = st.quality;
  document.getElementById("quality").textContent = q;
  document.getElementById("quality").style.color = q === "ALTA" ? "#7dffb4" : q === "MÉDIA" ? "#ffd866" : q === "SEM DADOS" ? "#8b9bb0" : "#ff9d7a";
  document.getElementById("qIcon").style.color = q === "ALTA" ? "#39e08a" : q === "MÉDIA" ? "#ffd23f" : "#ff6b7a";

  var age = st.ageMs;
  document.getElementById("ageTxt").innerHTML = age >= 0 ? ("⏱ " + (age/1000).toFixed(0) + "s") : "⏱ —";
  if (st.capture){
    document.getElementById("pill").className = "pill";
    document.getElementById("pillTxt").textContent = "ANÁLISE ATIVA";
  } else {
    document.getElementById("pill").className = "pill off";
    document.getElementById("pillTxt").textContent = "CAPTURA PAUSADA";
  }

  var ptl = document.getElementById("patList");
  var ph = "";
  var all = st.patterns;
  for (var p = 0; p < all.length; p++){
    var it = all[p];
    var s2 = "";
    for (var r = 0; r < it.seq.length && r < 6; r++) s2 += bead(it.seq[r], "mini");
    ph += '<div class="pitem"><div style="flex:1;min-width:0"><div class="nm">' + it.name + '</div><div class="ds">' + it.desc + '</div></div><div class="seq">' + s2 + '</div></div>';
  }
  ptl.innerHTML = ph;

  var rd = "";
  var road = st.road;
  for (var x = 0; x < road.length; x++) rd += bead(road[x]);
  document.getElementById("road").innerHTML = rd;
  document.getElementById("roadCount").textContent = n + (n === 1 ? " rodada" : " rodadas");

  document.getElementById("hit40").textContent = st.hit40 < 0 ? "—" : pct(st.hit40);
  document.getElementById("hitAll").innerHTML = st.hitAll < 0 ? "—" : pct(st.hitAll) + ' <small>(' + st.nHits + ')</small>';
  document.getElementById("dt").innerHTML = n ? (st.dC + " × " + st.tC) : "—";
  document.getElementById("tieStat").innerHTML = n ? (st.sC + ' <small>(' + pct(st.sC/n) + ')</small>') : "—";
  document.getElementById("maxStreak").textContent = st.maxStreak > 0 ? st.maxStreak : "—";
  var cs = st.curStreak;
  document.getElementById("curStreak").innerHTML = (cs.side && cs.side !== "S") ? (cs.n + " " + (cs.side === "D" ? "🐉" : "🐯")) : "—";

  document.getElementById("distTxt").textContent = n ?
    ("Dragão " + pct(st.dist.d) + " · Empate " + pct(st.dist.s) + " · Tigre " + pct(st.dist.t)) : "—";
  document.getElementById("distBar").innerHTML = n ?
    ('<i style="width:' + (st.dist.d*100) + '%;background:linear-gradient(90deg,#7fd0ff,#1a70c8)"></i>' +
     '<i style="width:' + (st.dist.s*100) + '%;background:linear-gradient(90deg,#8ff0b6,#16a35c)"></i>' +
     '<i style="width:' + (st.dist.t*100) + '%;background:linear-gradient(90deg,#ff8a92,#c01326)"></i>') : "";
  document.getElementById("learnBadge").textContent = "aprendizado " + st.learnPct + "%";
  document.getElementById("insights").className = "ins";
  document.getElementById("insights").innerHTML = st.insights;

  var tie = document.getElementById("btnTie");
  if (st.tieMode){ tie.className = "rbtn on tieon"; tie.textContent = "🟢 EMPATE: LIGADO"; }
  else { tie.className = "rbtn"; tie.textContent = "🟢 MÉTODO EMPATE"; }
}

window.DTpush = function(json){ try { render(JSON.parse(json)); } catch(e){} };

setInterval(function(){
  try { window.DTpush(window.DTBridge.getState()); } catch(e){}
}, 400);
</script>
</body>
</html>"""
}
