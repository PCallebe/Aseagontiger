package com.infinity.dragontiger

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Detector automático da fileira de bolinhas na tela do jogo.
 * Sem marcação manual: localiza a "ÚLTIMAS 10 RODADAS" (fileira horizontal
 * de círculos azuis/vermelhos/verdes) varrendo a tela, e devolve as cores
 * da ESQUERDA para a DIREITA (o mais novo fica na esquerda — anexo 3).
 */
object ScreenBeadDetector {

    /**
     * Varre linhas horizontais procurando a fileira de bolinhas e classifica cada centro.
     */
    fun detect(src: Bitmap, exclLeft: Int, exclTop: Int, exclRight: Int, exclBottom: Int): List<String>? {
        val w = src.width
        val h = src.height
        if (w < 300 || h < 400) return null

        val sw = max(1, w / 2)
        val sh = max(1, h / 2)
        val bmp = if (src.width == sw && src.height == sh) src else Bitmap.createScaledBitmap(src, sw, sh, true)
        val exL = exclLeft / 2
        val exT = exclTop / 2
        val exR = if (exclRight == Int.MAX_VALUE) sw else exclRight / 2
        val exB = exclBottom / 2

        val row = IntArray(sw)
        var best: List<String>? = null
        var bestScore = 0

        val yStart = (sh * 0.03).toInt()
        val yEnd = min((sh * 0.62).toInt(), sh - 2)

        var y = yStart
        while (y < yEnd) {
            val insideExclusion = y in exT until exB
            if (!insideExclusion) {
                bmp.getPixels(row, 0, sw, 0, y, sw, 1)
                val runs = spansOf(row, sw)
                if (runs.size in 6..14) {
                    val centers = splitCenters(runs, sw)
                    if (centers != null && centers.size in 6..14 && centers.size > bestScore) {
                        var ok = true
                        val chars = ArrayList<String>(centers.size)
                        for (c in centers) {
                            val ch = classifyCenter(bmp, c, y)
                            if (ch == null) { ok = false; break }
                            chars.add(ch)
                        }
                        if (ok) {
                            best = chars
                            bestScore = centers.size
                        }
                    }
                }
            }
            y += 4
        }
        if (bmp !== src) bmp.recycle()
        return best
    }

    /** sequências contíguas de pixels coloridos (start,end inclusivos) */
    private fun spansOf(row: IntArray, sw: Int): List<Pair<Int, Int>> {
        val out = ArrayList<Pair<Int, Int>>()
        var start = -1
        for (x in 0 until sw) {
            val cls = classifyFast(row[x])
            if (cls != null) {
                if (start < 0) start = x
            } else {
                if (start >= 0) {
                    if (x - start >= 8) out.add(Pair(start, x - 1))
                    start = -1
                }
            }
        }
        if (start >= 0 && sw - start >= 8) out.add(Pair(start, sw - 1))
        return out
    }

    /**
     * Converte os spans em centros de bolinhas. Bolinhas grandes demais
     * (glow colado) são divididas em partes iguais.
     */
    private fun splitCenters(runs: List<Pair<Int, Int>>, sw: Int): List<Int>? {
        if (runs.isEmpty()) return null
        val centers = ArrayList<Int>()
        for ((s, e) in runs) {
            val width = e - s + 1
            if (width <= 70) {
                centers.add((s + e) / 2)
                continue
            }
            val parts = splitWideSpan(s, e) ?: return null
            centers.addAll(parts)
        }
        if (centers.size !in 6..14) return null
        centers.sort()
        val gaps = ArrayList<Int>()
        for (i in 1 until centers.size) gaps.add(centers[i] - centers[i - 1])
        val avg = gaps.average()
        if (avg < 10 || avg > 90) return null
        for (g in gaps) if (abs(g - avg) > avg * 0.55) return null
        return centers
    }

    private fun splitWideSpan(s: Int, e: Int): List<Int>? {
        // dividir em N partes iguais: N estimado por largura típica de bolinha (35–60px em meia-res)
        val width = e - s + 1
        for (n in 14 downTo 6) {
            val part = width.toDouble() / n
            if (part in 24.0..64.0) {
                val out = ArrayList<Int>(n)
                for (i in 0 until n) out.add((s + part * (i + 0.5)).roundToInt())
                return out
            }
        }
        return null
    }

    /** classificação pontual rápida para montar spans */
    private fun classifyFast(c: Int): String? {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val mx = max(r, max(g, b))
        if (mx < 70) return null
        return if (b > r + 20 && b > g + 8) "D"
        else if (r > g + 25 && r > b + 25) "T"
        else if (g > r + 18 && g > b + 18) "S"
        else null
    }

    /** classifica o centro da bolinha votando em 6 pontos ao redor (evita a letra branca) */
    private fun classifyCenter(bmp: Bitmap, cx: Int, cy: Int): String? {
        var dVotes = 0; var tVotes = 0; var sVotes = 0
        val offs = intArrayOf(0, 0, 6, 0, -6, 0, 0, 6, 0, -6, 5, 5, -5, -5, 5, -5, -5, 5)
        var i = 0
        while (i < offs.size) {
            val x = cx + offs[i]
            val y2 = cy + offs[i + 1]
            i += 2
            if (x < 0 || y2 < 0 || x >= bmp.width || y2 >= bmp.height) continue
            val c = bmp.getPixel(x, y2)
            when (classifyFast(c)) {
                "D" -> dVotes++
                "T" -> tVotes++
                "S" -> sVotes++
            }
        }
        val mx = max(dVotes, max(tVotes, sVotes))
        if (mx < 3) return null
        return when (mx) {
            dVotes -> if (dVotes >= tVotes && dVotes >= sVotes) "D" else if (tVotes >= sVotes) "T" else "S"
            tVotes -> if (tVotes >= sVotes) "T" else "S"
            else -> "S"
        }
    }
}
