package com.infinity.dragontiger

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Tela cheia do app — fiel ao painel v1.0 (anexos 1 e 2), mas:
 * - SEM botões manuais de marcação (leitura 100% automática);
 * - botões menores;
 * - resultados com o mais novo à ESQUERDA;
 * - botões: PADRÕES (todos os padrões identificados), HISTÓRICO (sessões salvas)
 *   e MÉTODO EMPATE (só entra no empate);
 * - iniciar/parar a leitura automática sobre o jogo.
 */
class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var last10Host: LinearLayout
    private lateinit var patName: TextView
    private lateinit var patDesc: TextView
    private lateinit var patSeqHost: LinearLayout
    private lateinit var pD: TextView
    private lateinit var pS: TextView
    private lateinit var pT: TextView
    private lateinit var orient: TextView
    private lateinit var confTxt: TextView
    private lateinit var trendTxt: TextView
    private lateinit var tieSignal: TextView
    private lateinit var quality: TextView
    private lateinit var roadHost: LinearLayout
    private lateinit var roadCount: TextView
    private lateinit var hit40: TextView
    private lateinit var hitAll: TextView
    private lateinit var dt: TextView
    private lateinit var tieStat: TextView
    private lateinit var maxStreak: TextView
    private lateinit var curStreak: TextView
    private lateinit var distTxt: TextView
    private lateinit var distBar: LinearLayout
    private lateinit var learnBadge: TextView
    private lateinit var insights: TextView
    private lateinit var btnTie: Button
    private lateinit var btnStart: Button
    private lateinit var btnPatterns: Button
    private lateinit var btnHist: Button
    private lateinit var patListHost: LinearLayout
    private lateinit var histListHost: LinearLayout
    private lateinit var histPanel: LinearLayout
    private lateinit var patPanel: LinearLayout

    private val uiHandler = Handler(Looper.getMainLooper())
    private var awaitingOverlay = false

    private val bg = Color.rgb(6, 13, 24)
    private val cardBg = Color.rgb(11, 22, 38)
    private val cyan = Color.rgb(127, 212, 255)
    private val blue = Color.rgb(46, 168, 255)
    private val red = Color.rgb(255, 90, 104)
    private val green = Color.rgb(57, 224, 138)
    private val muted = Color.rgb(143, 166, 194)

    private val refresh = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                render()
                uiHandler.postDelayed(this, 600)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RoundsStore.init(this)
        buildUi()
        setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (!RoundsStore.introShown()) {
            RoundsStore.setIntroShown()
            Toast.makeText(this, "Toque em INICIAR LEITURA e mantenha o jogo aberto — a marcação é automática.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        uiHandler.removeCallbacks(refresh)
        uiHandler.post(refresh)
        if (awaitingOverlay && Settings.canDrawOverlays(this)) {
            awaitingOverlay = false
            launchCaptureConsent()
        }
    }

    override fun onPause() {
        uiHandler.removeCallbacks(refresh)
        super.onPause()
    }

    /* ---------------- UI ---------------- */

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        t.setPadding(0, 4, 0, 4)
        return t
    }

    private fun card(accent: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(14, 10, 14, 12)
        c.setBackgroundColor(cardBg)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 6, 0, 6)
        c.layoutParams = lp
        return c
    }

    private fun metricCard(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(10, 9, 8, 10)
        c.setBackgroundColor(cardBg)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(3, 4, 3, 4)
        c.layoutParams = lp
        c.addView(label(title, 9f, muted, true))
        val v = TextView(this)
        v.tag = "value"
        v.text = "—"
        v.textSize = 15f
        v.setTextColor(Color.WHITE)
        v.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        c.addView(v)
        return c
    }

    private fun beadView(ch: String, sizeDp: Int, mini: Boolean): TextView {
        val d = resources.displayMetrics.density
        val t = TextView(this)
        t.text = if (ch.isEmpty()) "·" else ch
        t.gravity = Gravity.CENTER
        t.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        t.textSize = if (mini) 8.5f else 11f
        val s = (sizeDp * d).toInt()
        val lp = LinearLayout.LayoutParams(s, s)
        lp.setMargins((if (mini) 1.5f else 2.5f * 1).toInt(), 0, (if (mini) 1.5f else 2.5f).toInt(), 0)
        t.layoutParams = lp
        when (ch) {
            "D" -> { t.setTextColor(Color.WHITE); t.background = circleDrawable(Color.rgb(22, 115, 201)) }
            "T" -> { t.setTextColor(Color.WHITE); t.background = circleDrawable(Color.rgb(210, 31, 49)) }
            "S" -> { t.setTextColor(Color.WHITE); t.background = circleDrawable(Color.rgb(26, 168, 96)) }
            else -> { t.setTextColor(Color.rgb(51, 69, 92)); t.background = null }
        }
        return t
    }

    private fun circleDrawable(color: Int): android.graphics.drawable.Drawable {
        val gd = android.graphics.drawable.GradientDrawable()
        gd.shape = android.graphics.drawable.GradientDrawable.OVAL
        gd.setColor(color)
        return gd
    }

    private fun smallButton(text: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 10.5f
        b.setTextColor(Color.rgb(207, 224, 242))
        b.isAllCaps = false
        b.setPadding(10, 8, 10, 8)
        b.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 26f
            setColor(Color.argb(255, 22, 38, 58))
            setStroke(1, Color.argb(255, 60, 90, 120))
        }
        b.setOnClickListener { action() }
        return b
    }

    private fun buildUi() {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(20, 28, 20, 40)

        val scroll = ScrollView(this)
        scroll.viewTreeObserver.addOnScrollChangedListener { }
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        scroll.addView(inner)

        // cabeçalho
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.gravity = Gravity.CENTER
        head.setPadding(0, 8, 0, 8)
        head.addView(label("DRAGON TIGER", 24f, Color.WHITE, true))
        head.addView(label("LEITURA AUTOMÁTICA • v2.0", 10f, muted, true))
        inner.addView(head)

        // probabilidades
        val probs = LinearLayout(this)
        probs.orientation = LinearLayout.HORIZONTAL
        val c1 = card(blue); pD = valueInside(c1, "DRAGÃO", cyan)
        val c2 = card(green); pS = valueInside(c2, "EMPATE", green)
        val c3 = card(red); pT = valueInside(c3, "TIGRE", red)
        for (c in arrayOf(c1, c2, c3)) {
            val lp = c.layoutParams as LinearLayout.LayoutParams
            lp.weight = 1f
            lp.width = 0
            probs.addView(c)
        }
        inner.addView(probs)

        // últimas 10 — novo à esquerda
        inner.addView(label("ÚLTIMAS 10 RODADAS  (NOVO À ESQUERDA ◀)", 10f, muted, true).apply { gravity = Gravity.CENTER })
        last10Host = LinearLayout(this)
        last10Host.orientation = LinearLayout.HORIZONTAL
        last10Host.gravity = Gravity.CENTER
        last10Host.setPadding(0, 6, 0, 6)
        inner.addView(last10Host)

        // padrão identificado
        val patCard = card(green)
        patCard.addView(label("PADRÃO IDENTIFICADO", 9f, green, true))
        patName = label("—", 17f, Color.WHITE, true)
        patCard.addView(patName)
        patDesc = label("—", 10f, muted, false)
        patCard.addView(patDesc)
        patSeqHost = LinearLayout(this)
        patSeqHost.orientation = LinearLayout.HORIZONTAL
        patSeqHost.setPadding(0, 6, 0, 0)
        patCard.addView(patSeqHost)
        inner.addView(patCard)

        // botões: padrões / histórico / empate
        val rowBtns = LinearLayout(this)
        rowBtns.orientation = LinearLayout.HORIZONTAL
        btnPatterns = smallButton("🧩 PADRÕES") {
            patPanel.visibility = if (patPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            render()
        }
        btnHist = smallButton("🕓 HISTÓRICO") {
            histPanel.visibility = if (histPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            render()
        }
        btnTie = smallButton("🟢 MÉTODO EMPATE") {
            RoundsStore.setTieMode(!RoundsStore.tieMode())
            render()
        }
        for (b in arrayOf(btnPatterns, btnHist, btnTie)) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(4, 6, 4, 6)
            rowBtns.addView(b, lp)
        }
        inner.addView(rowBtns)

        // painel de todos os padrões
        patPanel = card(blue)
        patPanel.addView(label("TODOS OS PADRÕES ATIVOS AGORA", 9f, cyan, true))
        patListHost = LinearLayout(this)
        patPanel.addView(patListHost)
        patPanel.visibility = View.GONE
        inner.addView(patPanel)

        // painel de histórico
        histPanel = card(blue)
        histPanel.addView(label("SESSÕES SALVAS — o Zerar arquivA, nunca apaga", 9f, cyan, true))
        histListHost = LinearLayout(this)
        histPanel.addView(histListHost)
        histPanel.addView(smallButton("📦 ARQUIVAR SESSÃO ATUAL E ZERAR") {
            val n = RoundsStore.archiveAndReset()
            Toast.makeText(this, "Sessão arquivada ($n rodadas). O histórico continua salvo.", Toast.LENGTH_SHORT).show()
            render()
        })
        histPanel.addView(smallButton("⧉ COPIAR SEQUÊNCIA ATUAL") {
            val text = RoundsStore.getSeq().joinToString(" ")
            val cb = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cb.setPrimaryClip(android.content.ClipData.newPlainText("DT", text))
            Toast.makeText(this, "Sequência copiada (${RoundsStore.getSeq().size})", Toast.LENGTH_SHORT).show()
        })
        histPanel.visibility = View.GONE
        inner.addView(histPanel)

        // leitura
        val readCard = card(blue)
        readCard.addView(label("LEITURA PARA PRÓXIMA RODADA", 9f, muted, true))
        trendTxt = label("TENDÊNCIA: —", 13f, Color.WHITE, true)
        readCard.addView(trendTxt)
        tieSignal = label("Sinal de empate: —", 10f, muted, false)
        readCard.addView(tieSignal)
        orient = label("AGUARDE", 15f, Color.rgb(255, 210, 63), true)
        readCard.addView(orient)
        confTxt = label("sem dados", 10f, muted, false)
        readCard.addView(confTxt)
        inner.addView(readCard)

        // iniciar / parar leitura
        btnStart = Button(this)
        btnStart.text = "▶ INICIAR LEITURA AUTOMÁTICA"
        btnStart.textSize = 13f
        btnStart.setTextColor(Color.WHITE)
        btnStart.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        btnStart.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 30f
            setColor(Color.rgb(16, 84, 150))
        }
        btnStart.setPadding(14, 14, 14, 14)
        btnStart.setOnClickListener {
            if (CaptureOverlayServiceActive.isActive) {
                stopService(Intent(this, CaptureOverlayService::class.java))
                CaptureOverlayServiceActive.isActive = false
                status.text = "Leitura encerrada."
            } else {
                requestCapturePermissions()
            }
        }
        val lpStart = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpStart.setMargins(0, 10, 0, 4)
        inner.addView(btnStart, lpStart)

        status = label("Leitura automática da tela — sem marcação manual.", 11f, muted, false)
        inner.addView(status)

        // caminho das bolinhas
        val roadHead = LinearLayout(this)
        roadHead.orientation = LinearLayout.HORIZONTAL
        roadHead.gravity = Gravity.CENTER_VERTICAL
        val rh = label("CAMINHO DAS BOLINHAS", 11f, Color.rgb(169, 194, 221), true)
        rh.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        roadHead.addView(rh)
        roadCount = label("0 rodadas", 10f, cyan, true)
        roadHead.addView(roadCount)
        inner.addView(roadHead)
        roadHost = LinearLayout(this)
        roadHost.orientation = LinearLayout.VERTICAL
        roadHost.setPadding(0, 6, 0, 6)
        inner.addView(roadHost)

        // desempenho do motor
        inner.addView(label("DESEMPENHO DO MOTOR", 11f, Color.rgb(169, 194, 221), true))
        learnBadge = label("aprendizado 0%", 10f, cyan, true)
        inner.addView(learnBadge)
        val g1 = LinearLayout(this); g1.orientation = LinearLayout.HORIZONTAL
        val m1 = metricCard("ACERTO (ÚLTIMAS 40)"); hit40 = valueOf(m1)
        val m2 = metricCard("ACERTO TOTAL"); hitAll = valueOf(m2)
        g1.addView(m1); g1.addView(m2); inner.addView(g1)
        val g2 = LinearLayout(this); g2.orientation = LinearLayout.HORIZONTAL
        val m3 = metricCard("DRAGÃO × TIGRE"); dt = valueOf(m3)
        val m4 = metricCard("EMPATES"); tieStat = valueOf(m4)
        g2.addView(m3); g2.addView(m4); inner.addView(g2)
        val g3 = LinearLayout(this); g3.orientation = LinearLayout.HORIZONTAL
        val m5 = metricCard("MAIOR SEQUÊNCIA"); maxStreak = valueOf(m5)
        val m6 = metricCard("SEQUÊNCIA ATUAL"); curStreak = valueOf(m6)
        g3.addView(m5); g3.addView(m6); inner.addView(g3)
        val distCard = card(blue)
        distCard.addView(label("DISTRIBUIÇÃO (AMOSTRA TOTAL)", 9f, muted, true))
        distTxt = label("—", 12f, Color.WHITE, true)
        distCard.addView(distTxt)
        distBar = LinearLayout(this)
        distBar.orientation = LinearLayout.HORIZONTAL
        distBar.setPadding(0, 8, 0, 4)
        distCard.addView(distBar)
        inner.addView(distCard)

        // insights
        inner.addView(label("O QUE O MOTOR ESTÁ LENDO", 11f, Color.rgb(169, 194, 221), true))
        val insCard = card(blue)
        insights = TextView(this)
        insights.text = "Aguardando a leitura automática…"
        insights.textSize = 11f
        insights.setLineSpacing(0f, 1.3f)
        insights.setTextColor(Color.rgb(198, 214, 232))
        insCard.addView(insights)
        inner.addView(insCard)

        inner.addView(label(
            "Transparência: cada rodada é aleatória e independente — nenhum padrão garante a próxima. " +
                "O app mede o seu histórico real e mostra a tendência observada. Não é promessa de ganho.",
            10f, Color.rgb(255, 224, 138), false
        ))

        root.addView(scroll)
    }

    private fun valueInside(card: LinearLayout, title: String, color: Int): TextView {
        card.addView(label(title, 9f, color, true))
        val v = TextView(this)
        v.text = "—"
        v.textSize = 19f
        v.setTextColor(Color.WHITE)
        v.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        card.addView(v)
        return v
    }

    private fun valueOf(card: LinearLayout): TextView {
        return card.findViewWithTag<TextView>("value") ?: TextView(this)
    }

    /* ---------------- render ---------------- */

    private fun pct(x: Double): String =
        String.format(java.util.Locale.US, "%.1f", x * 100).replace('.', ',') + "%"

    private fun render() {
        DTEngine.ensureLoaded()
        val st = try {
            org.json.JSONObject(DTEngine.stateJson(CaptureOverlayServiceActive.isActive))
        } catch (e: Exception) {
            return
        }
        val n = st.optInt("n", 0)

        pD.text = if (n > 0) pct(st.optDouble("pD", 0.0)) else "—"
        pS.text = if (n > 0) pct(st.optDouble("pS", 0.0)) else "—"
        pT.text = if (n > 0) pct(st.optDouble("pT", 0.0)) else "—"

        last10Host.removeAllViews()
        val l10 = st.optJSONArray("last10") ?: org.json.JSONArray()
        for (i in 0 until l10.length()) last10Host.addView(beadView(l10.optString(i), 26, false))
        if (n == 0) last10Host.addView(label("aguardando a leitura…", 11f, muted, false))

        val pm = st.optJSONObject("pattern")
        if (pm != null) {
            patName.text = pm.optString("name")
            patDesc.text = pm.optString("desc")
            patSeqHost.removeAllViews()
            val sq = pm.optJSONArray("seq") ?: org.json.JSONArray()
            for (i in 0 until sq.length()) patSeqHost.addView(beadView(sq.optString(i), 18, true))
        }

        btnTie.text = if (RoundsStore.tieMode()) "🟢 EMPATE: LIGADO" else "🟢 MÉTODO EMPATE"

        patListHost.removeAllViews()
        val pats = st.optJSONArray("patterns") ?: org.json.JSONArray()
        for (i in 0 until pats.length()) {
            val o = pats.optJSONObject(i) ?: continue
            val line = LinearLayout(this)
            line.orientation = LinearLayout.VERTICAL
            line.setPadding(0, 6, 0, 2)
            line.addView(label(o.optString("name"), 13f, Color.WHITE, true))
            line.addView(label(o.optString("desc"), 10f, muted, false))
            val sqh = LinearLayout(this)
            sqh.orientation = LinearLayout.HORIZONTAL
            val sq = o.optJSONArray("seq") ?: org.json.JSONArray()
            for (j in 0 until sq.length()) sqh.addView(beadView(sq.optString(j), 18, true))
            line.addView(sqh)
            patListHost.addView(line)
        }

        histListHost.removeAllViews()
        val sessions = RoundsStore.sessions()
        if (sessions.length() == 0) {
            histListHost.addView(label("Nenhuma sessão arquivada ainda.", 11f, muted, false))
        }
        for (i in 0 until sessions.length()) {
            val o = sessions.optJSONObject(i) ?: continue
            val d = java.util.Date(o.optLong("ts"))
            val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault())
            histListHost.addView(label(
                "#${sessions.length() - i} • ${fmt.format(d)} — ${o.optInt("n")} rodadas • D ${o.optInt("d")} · S ${o.optInt("s")} · T ${o.optInt("t")} • máx ${o.optInt("maxStreak")}",
                11f, Color.rgb(207, 224, 242), false
            ))
        }

        val tr = st.optJSONObject("trend")
        if (tr != null) {
            val dir = tr.optString("dir")
            val col = when (dir) {
                "AZUL" -> cyan
                "VERMELHO" -> red
                else -> Color.rgb(207, 224, 242)
            }
            trendTxt.text = "TENDÊNCIA: $dir"
            trendTxt.setTextColor(col)
            tieSignal.text = tr.optString("tieSignal")
        }

        val orc = st.optJSONObject("orient")
        if (orc != null) {
            orient.text = orc.optString("text")
            orient.setTextColor(
                when (orc.optString("kind")) {
                    "D" -> cyan
                    "T" -> red
                    "S" -> green
                    else -> Color.rgb(255, 210, 63)
                }
            )
            confTxt.text = orc.optString("conf")
        }

        val q = st.optString("quality")
        quality2(q)
        roadCount.text = "$n rodadas"
        roadHost.removeAllViews()
        val road = st.optJSONArray("road") ?: org.json.JSONArray()
        val perRow = 14
        var row: LinearLayout? = null
        for (i in 0 until road.length()) {
            if (i % perRow == 0) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                roadHost.addView(row)
            }
            row?.addView(beadView(road.optString(i), 22, false))
        }

        val h40 = st.optDouble("hit40", -1.0)
        hit40.text = if (h40 < 0) "—" else pct(h40)
        val hAll = st.optDouble("hitAll", -1.0)
        hitAll.text = if (hAll < 0) "—" else pct(hAll) + " (${st.optInt("nHits")})"
        dt.text = if (n > 0) "${st.optInt("dC")} × ${st.optInt("tC")}" else "—"
        tieStat.text = if (n > 0) "${st.optInt("sC")} (${pct(st.optDouble("sC", 0.0) / n)})" else "—"
        maxStreak.text = if (st.optInt("maxStreak") > 0) st.optInt("maxStreak").toString() else "—"
        val cs = st.optJSONObject("curStreak")
        curStreak.text = if (cs != null && cs.optString("side") != "S" && cs.optString("side").isNotEmpty())
            "${cs.optInt("n")} ${if (cs.optString("side") == "D") "🐉" else "🐯"}" else "—"

        val dist = st.optJSONObject("dist")
        if (dist != null && n > 0) {
            distTxt.text = "Dragão ${pct(dist.optDouble("d"))} · Empate ${pct(dist.optDouble("s"))} · Tigre ${pct(dist.optDouble("t"))}"
            distBar.removeAllViews()
            distBar.addView(barPiece(dist.optDouble("d"), Color.rgb(26, 112, 200)))
            distBar.addView(barPiece(dist.optDouble("s"), Color.rgb(22, 163, 92)))
            distBar.addView(barPiece(dist.optDouble("t"), Color.rgb(192, 19, 38)))
        } else {
            distTxt.text = "—"
            distBar.removeAllViews()
        }

        learnBadge.text = "aprendizado ${st.optInt("learnPct")}%"
        insights.text = if (n > 0) {
            val html = st.optString("insights")
            if (android.os.Build.VERSION.SDK_INT >= 24)
                android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY)
            else @Suppress("DEPRECATION") android.text.Html.fromHtml(html)
        } else "Aguardando a leitura automática…"

        status.text = if (CaptureOverlayServiceActive.isActive)
            "● LEITURA ATIVA — novas rodadas entram sozinhas (salvas automaticamente)."
        else "Leitura parada. Toque em INICIAR LEITURA AUTOMÁTICA."
        btnStart.text = if (CaptureOverlayServiceActive.isActive) "⏸ PARAR LEITURA" else "▶ INICIAR LEITURA AUTOMÁTICA"
    }

    private fun quality2(q: String) {
        // qualidade exibida junto ao status
    }

    private fun barPiece(frac: Double, color: Int): View {
        val v = View(this)
        v.setBackgroundColor(color)
        v.layoutParams = LinearLayout.LayoutParams(0, 18, frac.coerceAtLeast(0.001).toFloat())
        return v
    }

    /* ---------------- permissões ---------------- */

    private fun requestCapturePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            awaitingOverlay = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Ative a sobreposição para o painel flutuar sobre o jogo.", Toast.LENGTH_LONG).show()
            return
        }
        launchCaptureConsent()
    }

    private fun launchCaptureConsent() {
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(m.createScreenCaptureIntent(), 4107)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4107 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureOverlayService::class.java)
            i.putExtra(CaptureOverlayService.EXTRA_RESULT_CODE, resultCode)
            i.putExtra(CaptureOverlayService.EXTRA_RESULT_DATA, data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            CaptureOverlayServiceActive.isActive = true
            Toast.makeText(this, "Leitura ativa! O painel aparece no topo e pode ser arrastado.", Toast.LENGTH_LONG).show()
        }
    }
}
