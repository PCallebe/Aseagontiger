plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.infinity.dragontiger"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.infinity.dragontiger"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}


dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
