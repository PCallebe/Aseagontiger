package com.infinity.dragontiger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max

class CaptureOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_MODE = "analysis_mode"
        const val ACTION_SHOW_OVERLAY = "com.infinity.dragontiger.SHOW_OVERLAY"
        const val ACTION_SET_OVERLAY_MODE = "com.infinity.dragontiger.SET_OVERLAY_MODE"
        const val EXTRA_OVERLAY_MODE = "overlay_mode"
        private const val CHANNEL = "dragon_tiger_capture"
        private const val NOTIFICATION_ID = 917
    }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlay: View? = null
    private var overlayText: TextView? = null
    private var sequenceHost: LinearLayout? = null
    private var lastDetected: List<String> = emptyList()
    private var observationStartedAt = 0L
    private var analysisMode = "database"
    private val calibrationDurationMs = 3 * 60 * 1000L
    private var lastFrameProcessed = 0L
    private var overlayExpanded = false
    private var lastOcrAt = 0L
    private var lastSequenceChangedAt = 0L
    private var lastDetectedAt = 0L
    private var lastRoundCandidate: String? = null
    private var roundCandidateStreak = 0
    private var lastBankCandidate: Double? = null
    private var bankCandidateStreak = 0
    private var lastCardCandidate: Pair<String, String>? = null
    private var cardCandidateStreak = 0
    private val ocrBusy = AtomicBoolean(false)
    private val busy = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable { override fun run() { updateOverlay(lastDetected); mainHandler.postDelayed(this, 500L) } }
    private lateinit var wm: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
        if (intent?.action == ACTION_SHOW_OVERLAY) {
            SequenceStore.putSetting(this, "overlay_mode", "full")
            if (overlay == null) showOverlay()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SET_OVERLAY_MODE) {
            val selected = intent.getStringExtra(EXTRA_OVERLAY_MODE) ?: "full"
            SequenceStore.putSetting(this, "overlay_mode", selected)
            runCatching { overlay?.let { wm.removeView(it) } }
            overlay = null; overlayText = null; sequenceHost = null
            if (selected != "hidden") showOverlay()
            return START_NOT_STICKY
        }
        if (projection == null) {
            analysisMode = intent?.getStringExtra(EXTRA_MODE) ?: "database"
            if (analysisMode == "calibration") observationStartedAt = System.currentTimeMillis()
            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            val data = getProjectionIntent(intent)
            if (data == null || resultCode == 0) { stopSelf(); return START_NOT_STICKY }
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            CaptureOverlayServiceActive.isActive = true
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, mainHandler)
            startCapture()
            if (SequenceStore.setting(this, "overlay_mode", "full") != "hidden") showOverlay()
            mainHandler.postDelayed(uiTicker, 1000L)
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getProjectionIntent(intent: Intent?): Intent? {
        return if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_RESULT_DATA)
    }

    private fun startCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ r ->
            val image = try { r.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
            val now = System.currentTimeMillis()
            if (now - lastFrameProcessed < 150L) { image.close(); return@setOnImageAvailableListener }
            if (!busy.compareAndSet(false, true)) { image.close(); return@setOnImageAvailableListener }
            lastFrameProcessed = now
            try {
                val bitmap = imageToBitmap(image)
                image.close()
                if (bitmap != null) {
                    val detected = SequenceDetector.detect(bitmap)
                    val ocrNow = System.currentTimeMillis()
                    if (ocrNow - lastOcrAt >= 400L && ocrBusy.compareAndSet(false, true)) {
                        lastOcrAt = ocrNow
                        ScreenOcrReader.read(bitmap) { snapshot ->
                            try {
                            snapshot.roundId?.let { roundId ->
                                if (lastRoundCandidate == roundId) roundCandidateStreak++ else { lastRoundCandidate = roundId; roundCandidateStreak = 1 }
                                if (roundCandidateStreak >= 2 && System.currentTimeMillis() - lastDetectedAt < 1500L) {
                                    if (SequenceStore.ingestByRoundId(this, roundId, lastDetected)) lastSequenceChangedAt = System.currentTimeMillis()
                                }
                            } ?: run { lastRoundCandidate = null; roundCandidateStreak = 0 }
                            snapshot.bankCandidate?.let { candidate ->
                                if (lastBankCandidate != null && kotlin.math.abs(lastBankCandidate!! - candidate) <= maxOf(1.0, candidate * 0.01)) bankCandidateStreak++
                                else bankCandidateStreak = 1
                                lastBankCandidate = candidate
                                if (bankCandidateStreak >= 3) {
                                    SequenceStore.setBank(this, candidate)
                                    SequenceStore.putSetting(this, "bank_source", "SIYA_OCR_STABLE")
                                }
                            } ?: run { lastBankCandidate = null; bankCandidateStreak = 0 }
                            if (snapshot.dragonCard != null && snapshot.tigerCard != null) {
                                val pair = snapshot.dragonCard to snapshot.tigerCard
                                if (lastCardCandidate == pair) cardCandidateStreak++ else { lastCardCandidate = pair; cardCandidateStreak = 1 }
                                if (cardCandidateStreak >= 2 && System.currentTimeMillis() - lastSequenceChangedAt < 5000L) {
                                    SequenceStore.recordLatestDetails(this, pair.first, pair.second, snapshot.bankCandidate, snapshot.roundId)
                                }
                            } else { lastCardCandidate = null; cardCandidateStreak = 0 }
                            } finally {
                                ocrBusy.set(false)
                                mainHandler.post { updateOverlay(lastDetected) }
                            }
                        }
                    }
                    bitmap.recycle()
                    if (detected.size in 8..12) processDetected(detected)
                }
            } catch (_: Exception) { ocrBusy.set(false); runCatching { image.close() } }
            finally { busy.set(false) }
        }, mainHandler)
        virtualDisplay = projection?.createVirtualDisplay("DragonTiger", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, mainHandler)
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val result = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return result
    }

    private fun processDetected(sequence: List<String>) {
        // A contagem de bolinhas não é uma medida de confiança. Até a calibração
        // visual na mesa real, a captura é marcada como preliminar (confidence=0).
        lastDetected = sequence
        lastDetectedAt = System.currentTimeMillis()
        if (SequenceStore.setting(this, "last_round_id", "").isBlank()) {
            val inserted = SequenceStore.ingestVisibleSequence(this, sequence, 0.0)
            if (inserted > 0) lastSequenceChangedAt = lastDetectedAt
        }
        mainHandler.post { updateOverlay(sequence) }
    }

    @Suppress("DEPRECATION")
    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14*density).toInt(), (10*density).toInt(), (14*density).toInt(), (10*density).toInt())
            val alpha = SequenceStore.setting(this@CaptureOverlayService, "overlay_opacity", "242").toIntOrNull()?.coerceIn(64,255) ?: 242
            setBackgroundColor((alpha shl 24) or 0x000A1428)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "DRAGON TIGER  •  PAINEL FULL / LEITURA AO VIVO"; textSize = 12f; setTextColor(0xFF71D7FF.toInt()); setPadding(0,0,8,0) }
        val expand = TextView(this).apply { text = "⤢"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(10,0,10,0) }
        val minimize = TextView(this).apply { text = "—"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(10,0,10,0) }
        val close = TextView(this).apply { text = "×"; textSize = 25f; setTextColor(0xFFFF6572.toInt()); gravity = Gravity.CENTER; setPadding(10,0,4,0) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(expand); header.addView(minimize); header.addView(close)
        close.setOnClickListener {
            // Fecha somente a camada visual. MediaProjection, OCR, histórico e análise continuam ativos.
            runCatching { wm.removeView(panel) }
            overlay = null; overlayText = null; sequenceHost = null
            SequenceStore.putSetting(this, "overlay_mode", "hidden")
        }
        val content = TextView(this).apply { text = "INICIANDO CAPTURA…"; textSize = 13f; setTextColor(Color.WHITE); setPadding(0,8,0,4) }
        overlayText = content
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0,8,0,8) }
        sequenceHost = dots
        val sequenceLabel = TextView(this).apply { text = "SEQUÊNCIA SIYA • ÚLTIMOS 30 • MAIS NOVO À ESQUERDA"; textSize = 10f; setTextColor(0xFF9FB4D0.toInt()); setPadding(0,6,0,0) }
        val sequenceScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(dots) }
        val scrollContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(sequenceLabel); addView(sequenceScroll); addView(content) }
        val footer = TextView(this).apply { text = "Arraste pelo cabeçalho • — minimiza • ⤢ expande"; textSize = 10f; setTextColor(0xFF9FB4D0.toInt()) }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(scrollContent) }
        panel.addView(header)
        panel.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        panel.addView(footer)
        var minimized = false
        var fullScreen = false
        minimize.setOnClickListener {
            // Minimizar altera somente a apresentação; serviço foreground, MediaProjection, OCR e banco continuam ativos.
            minimized = !minimized
            scroll.visibility = if (minimized) View.GONE else View.VISIBLE
            footer.visibility = if (minimized) View.GONE else View.VISIBLE
            minimize.text = if (minimized) "＋" else "—"
            (overlay?.layoutParams as? WindowManager.LayoutParams)?.let { params ->
                params.height = if (minimized) (48*density).toInt() else if (fullScreen) (resources.displayMetrics.heightPixels * 0.90f).toInt() else (resources.displayMetrics.heightPixels * 0.40f).toInt()
                runCatching { wm.updateViewLayout(panel, params) }
            }
        }
        expand.setOnClickListener {
            if (!minimized) {
                fullScreen = !fullScreen
                overlayExpanded = fullScreen
                updateOverlay(lastDetected)
                (overlay?.layoutParams as? WindowManager.LayoutParams)?.let { params ->
                    params.height = (resources.displayMetrics.heightPixels * if (fullScreen) 0.90f else 0.40f).toInt()
                    runCatching { wm.updateViewLayout(panel, params) }
                }
                expand.text = if (fullScreen) "⤡" else "⤢"
            }
        }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        header.setOnTouchListener { v, event ->
            val lp = overlay?.layoutParams as? WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX=lp?.x ?: 0; startY=lp?.y ?: 0; touchX=event.rawX; touchY=event.rawY; true }
                MotionEvent.ACTION_MOVE -> { if (lp != null) { lp.x=startX+(event.rawX-touchX).toInt(); lp.y=startY+(event.rawY-touchY).toInt(); runCatching { wm.updateViewLayout(panel,lp) }; SequenceStore.putSetting(this@CaptureOverlayService, "overlay_x", lp.x.toString()); SequenceStore.putSetting(this@CaptureOverlayService, "overlay_y", lp.y.toString()) }; true }
                else -> true
            }
        }
        val selectedMode = SequenceStore.setting(this, "overlay_mode", "full")
        if (selectedMode == "compact") {
            // Compacto reduz somente o espaço externo; mantém sequência e análise
            // idênticas ao Full para não esconder a decisão nem as probabilidades.
            panel.setPadding((8*density).toInt(), (6*density).toInt(), (8*density).toInt(), (6*density).toInt())
        }
        if (selectedMode == "icon") {
            scroll.visibility = View.GONE; footer.visibility = View.GONE
            title.text = "DT • ATIVO"
            expand.visibility = View.GONE
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val metrics = resources.displayMetrics
        val sizeMode = SequenceStore.setting(this, "overlay_size", "medium")
        val widthFactor = when (sizeMode) { "small" -> 0.72f; "large" -> 0.96f; else -> 0.86f }
        val heightFactor = when (sizeMode) { "small" -> 0.24f; "large" -> 0.52f; else -> 0.30f }
        val width = if (selectedMode == "icon") (112*density).toInt() else (metrics.widthPixels * widthFactor).toInt()
        val height = if (selectedMode == "icon") (48*density).toInt() else (metrics.heightPixels * if (selectedMode == "compact") 0.42f else heightFactor).toInt()
        val lp = WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = if (selectedMode == "icon") Gravity.TOP or Gravity.END else Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = SequenceStore.setting(this@CaptureOverlayService, "overlay_x", "0").toIntOrNull() ?: 0
            y = SequenceStore.setting(this@CaptureOverlayService, "overlay_y", (24*density).toInt().toString()).toIntOrNull() ?: (24*density).toInt()
        }
        overlay = panel
        runCatching { wm.addView(panel, lp) }
        updateOverlay(lastDetected)
    }

    private fun updateOverlay(seq: List<String>) {
        if (SequenceStore.setting(this, "overlay_mode", "full") == "hidden" && overlay == null) return
        val rows = SequenceStore.all(this)
        val current = PatternEngine.current(rows)
        val recentRows = rows.takeLast(30)
        sequenceHost?.let { host ->
            host.removeAllViews()
            fun dot(value: String): TextView = TextView(this).apply {
                text = when(value) { "D" -> "D"; "T" -> "T"; else -> "E" }
                textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                val fill = when(value) { "D" -> 0xFF168DDB.toInt(); "T" -> 0xFFE34850.toInt(); else -> 0xFF79B82A.toInt() }
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill) }
                val size = (25 * resources.displayMetrics.density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(2, 2, 2, 2) }
            }
            val visualRows = recentRows.asReversed() // espelha o SIYA: resultado mais novo à esquerda
            val markedCount = current?.window?.coerceAtMost(visualRows.size) ?: 0
            if (markedCount > 0 && visualRows.size >= 10) {
                val marked = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    background = GradientDrawable().apply { setColor(0x00000000); setStroke((2 * resources.displayMetrics.density).toInt(), 0xFFFFD45A.toInt()); cornerRadius = 8 * resources.displayMetrics.density }
                    setPadding(2, 2, 2, 2)
                }
                visualRows.take(markedCount).forEach { marked.addView(dot(it.value)) }
                host.addView(marked)
                visualRows.drop(markedCount).forEach { host.addView(dot(it.value)) }
            } else visualRows.forEach { host.addView(dot(it.value)) }
        }
        val signal = if (current == null) "PADRÃO: NENHUM CONFIRMADO\nOBSERVAR — NÃO FORÇAR ENTRADA" else "PADRÃO: ${current.name}\n${current.description}"
        val stats = SequenceStore.stats(this)
        val frequencySignal = "FREQUÊNCIA ATUAL (HISTÓRICO): D ${String.format(java.util.Locale.getDefault(), "%.1f", stats.pD)}% (${stats.d}) • E ${String.format(java.util.Locale.getDefault(), "%.1f", stats.pE)}% (${stats.e}) • T ${String.format(java.util.Locale.getDefault(), "%.1f", stats.pT)}% (${stats.t})"
        val drawSignal = PatternEngine.drawEvidence(rows, current)
        val entrySignal = PatternEngine.entrySummary(rows, current)
        val projection = SequenceStore.updateProjection(this)
        val projectionSignal = if (projection == null) {
            "PRÓXIMO MAIS FREQUENTE: AGUARDANDO DADOS"
        } else {
            val sideName = when (projection.side) { "D" -> "DRAGÃO"; "T" -> "TIGRE"; else -> "EMPATE" }
            val sidePct = when (projection.side) { "D" -> projection.pD; "T" -> projection.pT; else -> projection.pE }
            val prefix = if (analysisMode == "calibration") "PROJEÇÃO DE CALIBRAÇÃO" else "PRÓXIMA TENDÊNCIA HISTÓRICA"
            "$prefix: $sideName • ${String.format(java.util.Locale.getDefault(), "%.1f", sidePct)}% • ${projection.samples} casos • ${projection.pattern}"
        }
        val details = SequenceStore.latestRoundDetails(this)
        val cards = "CARTAS: Dragão ${details?.dragonCard ?: "—"} • Tigre ${details?.tigerCard ?: "—"}"
        val entryMode = SequenceStore.setting(this, "entry_mode", "all")
        val capture = if (seq.size in 8..12) "BOLINHAS LIDAS: ${seq.size} • sequência visual capturada • validação SIYA pendente" else "LEITURA INCOMPLETA — aguardando bolinhas visíveis"
        val finance = SequenceStore.financeSummary(this)
        val pause = SequenceStore.suggestedPauseMinutes(this)
        val financeSignal = when {
            finance.stopLossReached -> "STOP LOSS −30% • PAUSA 39 MIN"
            finance.takeReached >= 3 -> "TAKE 3 +75% • PAUSA 30 MIN"
            finance.takeReached == 2 -> "TAKE 2 +50% DA BANCA INICIAL"
            finance.takeReached == 1 -> "TAKE 1 +25% DA BANCA INICIAL"
            else -> "GESTÃO: TAKE 1 +25% • TAKE 2 +50% • TAKE 3 +75% • STOP −30%"
        }
        val modeSignal = if (entryMode == "draw") "MODO SOMENTE EMPATE • ${if (drawSignal.startsWith("ALERTA")) "EVIDÊNCIA HISTÓRICA PRESENTE" else "NÃO ENTRAR"}" else "MODO COMPLETO • SEM ENTRADA AUTOMÁTICA VALIDADA"
        val mode = if (analysisMode == "calibration") {
            val elapsed = (System.currentTimeMillis() - observationStartedAt).coerceAtLeast(0L)
            val remaining = (calibrationDurationMs - elapsed).coerceAtLeast(0L)
            if (remaining == 0L) {
                SequenceStore.putSetting(this, "first_calibration_done", "true")
                analysisMode = "database"
                "OBSERVAÇÃO CONCLUÍDA • MONITORAMENTO CONTÍNUO ATIVO"
            } else "OBSERVAÇÃO INICIAL: ${((remaining + 59999L) / 60000L)} min restantes"
        } else "MODO BANCO EXISTENTE — REGISTRO CONTÍNUO"
        // A projeção é calculada e gravada também durante os 3 minutos iniciais.
        // Nesse período ela serve para comparar previsão x resultado, nunca para liberar aposta.
        val projectionText = SequenceStore.projectionSummary(this, analysisMode == "calibration")
        val compactDecision = if (projection == null) "PRÓXIMA ENTRADA: OBSERVAR • aguardando amostra" else {
            val sideName = when (projection.side) { "D" -> "DRAGÃO"; "T" -> "TIGRE"; else -> "EMPATE" }
            val pct = when (projection.side) { "D" -> projection.pD; "T" -> projection.pT; else -> projection.pE }
            "PRÓXIMA ENTRADA: $sideName • ${String.format(java.util.Locale.getDefault(), "%.1f", pct)}% histórico • ${projection.samples} casos
        }
        val compactText = "$compactDecision\\nEMPATE: ${String.format(java.util.Locale.getDefault(), "%.1f", stats.pE)}% histórico\\n$signal\\n$frequencySignal"
        val fullText = "$signal\\n$frequencySignal\\n$projectionSignal\\n$cards\\n$drawSignal\\n${entrySignal.replace("\\n", " • ")}\\n$projectionText\\n$capture\\n$modeSignal\\n$financeSignal\\n$mode"
        overlayText?.text = if (overlayExpanded) fullText else compactText
    }

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL).setContentTitle("Dragon Tiger").setContentText("Leitura de tela ativa • toque para abrir").setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(pi).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("Dragon Tiger").setContentText("Leitura de tela ativa").setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(pi).build()
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CHANNEL, "Leitura Dragon Tiger", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onDestroy() {
        CaptureOverlayServiceActive.isActive = false
        runCatching { overlay?.let { wm.removeView(it) } }
        overlay = null; overlayText = null; sequenceHost = null
        mainHandler.removeCallbacks(uiTicker)
        runCatching { virtualDisplay?.release() }; virtualDisplay = null
        runCatching { reader?.close() }; reader = null
        runCatching { projection?.stop() }; projection = null
        runCatching { ScreenOcrReader.close() }
        stopForeground(true)
        super.onDestroy()
    }
}

private object SequenceDetector {
    // Detecta as 10 bolinhas da faixa SIYA de referência. A ROI é normalizada
    // pela captura S20 FE enviada; a calibração em outros layouts ainda precisa ser validada.
    fun detect(bitmap: Bitmap): List<String> {
        val w = bitmap.width; val h = bitmap.height
        if (w < 100 || h < 100) return emptyList()
        val xStep = max(1, w / 700)
        // ROI inicial normalizada pela captura SIYA de referência: fileira de resultados
        // fica imediatamente abaixo das cartas. A calibração fina da mesa continua pendente.
        val xStart = (w * 0.24).toInt(); val xEnd = (w * 0.77).toInt()
        val yStart = (h * 0.715).toInt(); val yEnd = (h * 0.730).toInt()
        var bestY = -1; var bestRuns = emptyList<Pair<Int,String>>(); var bestScore = 0
        val rowStep = max(1, h / 1000)
        for (y in yStart until yEnd step rowStep) {
            val runs = mutableListOf<Pair<Int,String>>()
            var active: String? = null; var start = 0; var lastX = 0
            var x = xStart
            while (x < xEnd) {
                val c = classify(bitmap.getPixel(x,y))
                if (c != null && c == active) { lastX=x }
                else {
                    if (active != null && lastX-start >= max(4,w/50) && lastX-start <= w/12) runs.add(((start+lastX)/2) to active)
                    active = c; start=x; lastX=x
                }
                x += xStep
            }
            if (active != null && lastX-start >= max(4,w/50) && lastX-start <= w/12) runs.add(((start+lastX)/2) to active)
            val cleaned = mutableListOf<Pair<Int,String>>()
            runs.forEach { r -> if (cleaned.lastOrNull()?.second != r.second || cleaned.lastOrNull()?.first?.let { abs(it-r.first)>w/25 } != false) cleaned.add(r) }
            val score = cleaned.size * 100 - abs(y - (h*0.722).toInt()) / max(1,h/100)
            if (cleaned.size in 8..12 && score > bestScore) { bestScore=score; bestY=y; bestRuns=cleaned }
        }
        if (bestY < 0) return emptyList()
        // Cada bolinha é um resultado independente. Não colapsar cores iguais:
        // sequências consecutivas (ex.: D-D-D-D) são padrões válidos do jogo.
        // No SIYA de referência, o marcador NEW fica à esquerda: a bolinha mais nova
        // é a primeira visualmente. Inverter a leitura horizontal preserva cronologia
        // (mais antiga -> mais recente) no banco e no motor de padrões.
        return bestRuns.sortedByDescending { it.first }.map { it.second }
    }
    private fun classify(color: Int): String? {
        val r=Color.red(color); val g=Color.green(color); val b=Color.blue(color)
        return when {
            b > 105 && b > r*1.22 && b > g*1.08 -> "D"
            r > 115 && r > g*1.30 && r > b*1.15 -> "T"
            g > 120 && r > 135 && g > r*1.03 && r > b*1.5 -> "E"
            else -> null
        }
    }
}
