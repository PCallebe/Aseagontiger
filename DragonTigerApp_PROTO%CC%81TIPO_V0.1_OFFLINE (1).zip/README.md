# DragonTigerApp — v0.5.9 (modo manual offline + modo online)

Projeto Android Kotlin exclusivo Dragon Tiger. `applicationId` permanece `com.infinity.dragontiger` para preservar compatibilidade de instalação.

## Ambiente
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk/targetSdk 35
- ML Kit Text Recognition 16.0.1

## Compilação
```bash
gradle --no-daemon :app:compileDebugKotlin
gradle --no-daemon :app:assembleDebug
```

O APK esperado é `app/build/outputs/apk/debug/app-debug.apk`.

## Estado funcional
Esta versão evolui a base anterior com banco SQLite persistente, cursor de deduplicação da sequência visível, biblioteca inicial de padrões, leitura de cores na faixa das bolinhas SIYA, OCR experimental para cartas e saldo, modo de observação inicial de 3 minutos, OCR experimental de cartas/saldo/identificador da rodada e popup arrastável/minimizável/expansível com marcação visual do padrão.

A captura usa MediaProjection e depende das permissões oficiais do Android. O ROI de cartas, saldo e bolinhas é uma calibração inicial aproximada baseada nas capturas SIYA fornecidas. A regra de cor foi comparada com 10 quadros extraídos do vídeo; isso não substitui a validação do APK no aparelho e na mesa real.

## Build automatizado v0.5.3
O workflow `.github/workflows/InfinityDragonTiger.yml` instala explicitamente JDK 17, Gradle 8.9 e Android SDK 35. Ele não depende de `gradlew` nem de arquivo ZIP externo. Execute pelo GitHub Actions > DragonTigerApp - Android APK > Run workflow. O APK só é considerado gerado quando o job publicar `DragonTigerApp-APK-v0.5.3`.


## Modos de operação v0.5.9
Ao abrir o aplicativo, o usuário escolhe a modalidade da sessão:
- **OFFLINE — MANUAL:** painel em tela cheia; cada rodada é registrada pelo usuário tocando em Dragão, Empate ou Tigre. O registro é gravado no SQLite local. Não inicia captura nem popup.
- **ONLINE — CAPTURA SIYA:** mantém a captura MediaProjection, OCR experimental e popup flutuante. O processamento e o histórico continuam locais; a conexão com a internet é necessária para o próprio SIYA e pode ser necessária para disponibilização inicial do modelo ML Kit.

A escolha é solicitada a cada abertura. O usuário pode alterar o modo pelo painel. Fechar o popup no modo online não encerra o serviço; o comando **DESLIGAR MONITORAMENTO** encerra captura e popup sem apagar o histórico.

No modo manual, cada toque representa uma rodada nova. Confira o resultado antes de tocar, pois cada toque gera um registro independente. A tela de gestão financeira permanece separada: registre também lado apostado, valor e resultado da aposta para atualizar a banca.
