# DragonTigerApp — piloto v0.2

Projeto Android Kotlin exclusivo Dragon Tiger. `applicationId` permanece `com.infinity.dragontiger` para preservar compatibilidade de instalação.

## Ambiente
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk/targetSdk 35
- ML Kit Text Recognition 16.0.1

## Compilação
```bash
gradle --no-daemon :app:compileDebugKotlin
gradle --no-daemon :app:assembleDebug
```

O APK esperado é `app/build/outputs/apk/debug/app-debug.apk`.

## Estado funcional
Esta versão evolui a base anterior com banco SQLite persistente, cursor de deduplicação da sequência visível, biblioteca inicial de padrões, leitura de cores na faixa das bolinhas SIYA, OCR experimental para cartas e saldo, modo de observação inicial de 10 minutos, OCR experimental de cartas/saldo/identificador da rodada e popup arrastável/minimizável/expansível com marcação visual do padrão.

A captura usa MediaProjection e depende das permissões oficiais do Android. O ROI de cartas, saldo e bolinhas é uma calibração inicial aproximada baseada nas capturas SIYA fornecidas. A regra de cor foi comparada com 10 quadros extraídos do vídeo; isso não substitui a validação do APK no aparelho e na mesa real.
