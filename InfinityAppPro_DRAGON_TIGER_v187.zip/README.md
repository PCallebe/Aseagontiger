# Infinity Pro V15 Complete — ᦠINFINITY

Projeto Android completo e independente das versões anteriores.

## Funções consolidadas
- leitura automática somente quando o SIYA (`com.zr.siya`) está em primeiro plano;
- confirma que existe uma sala ativa antes de alimentar estatísticas;
- leitura inicial ao entrar em cada sala e atualização contínua depois;
- memória independente por nome/ID da sala;
- painel flutuante arrastável verticalmente sobre o SIYA;
- OCR de WINs 2x–1000x, incluindo decimais;
- deduplicação para não contar a mesma animação várias vezes;
- JACKPOT atual e faixas de referência 1.275M–1.500M / 1.600M–2.000M;
- detecção de queda/reset do contador com confirmação em duas leituras;
- leitura visual dos seis painéis LUCKY x20/x50/x200/x300/x500/x1000 por transição apagado→aceso;
- frequência e aceleração dos acendimentos;
- aprendizado pré-hit por sala;
- Gift Engine para 🍀 Trevo, 🌹 Rosa e 🥚 Ovo;
- detecção visual do card selecionado no painel de presentes;
- associação de multiplicadores observados ao presente selecionado;
- sequência de multiplicadores baixos e sugestão de manter/considerar troca/troca sugerida;
- score e tamanho de amostra de Trevo/Rosa/Ovo por sala.

## Identidade
- Nome do app: Infinity Pro
- Nome no launcher: ᦠINFINITY
- applicationId mantido: `com.example.siyaheatradar.v10`
- versão: 15.0-complete-gift-engine

## Observação
Os indicadores são estatísticos e dependem da qualidade/quantidade das amostras. Não garantem o próximo resultado de um jogo aleatório.
