plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.siyaheatradar"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.infinity.apppro.v16fullauto"
        minSdk = 30
        targetSdk = 35
        versionCode = 187
        versionName = "17.0-dragon-tiger"
    }

    signingConfigs {
        create("infinity") {
            storeFile = file("keystore/infinityapp.jks")
            storePassword = "InfinityAppProV16"
            keyAlias = "infinityapp"
            keyPassword = "InfinityAppProV16"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("infinity")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
