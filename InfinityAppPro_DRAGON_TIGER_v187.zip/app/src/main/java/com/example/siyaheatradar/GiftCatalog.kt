package com.example.siyaheatradar

import java.text.Normalizer
import java.util.Locale

object GiftCatalog {
    private val afortunados = linkedMapOf(
        "TREVO" to listOf("trevo", "trevo dourado", "clover"),
        "ROSA" to listOf("rosa", "rosa da sorte", "rose"),
        "OVO" to listOf("ovo", "quebre o ovo", "egg"),
        "ESTRELA_DOURADA" to listOf("estrela dourada", "estrela"),
        "PERGAMINHO" to listOf("pergaminho", "pergamin"),
        "BOLSA_DA_SORTE" to listOf("bolsa da sorte", "bolsa"),
        "SINO_DA_SORTE" to listOf("sino da sorte", "sino"),
        "MOEDAS_DA_SORTE" to listOf("moedas da sorte", "moedas de", "moedas")
    )

    fun normalizeText(raw: String): String {
        val noAccent = Normalizer.normalize(raw, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return noAccent.lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun afortunadoFromText(raw: String): String? {
        val text = normalizeText(raw)
        return afortunados.entries.firstOrNull { (_, aliases) ->
            aliases.any { text.contains(normalizeText(it)) }
        }?.key
    }

    fun isAfortunado(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        val canonical = name.uppercase(Locale.ROOT)
        return afortunados.containsKey(canonical) || afortunadoFromText(name) != null
    }

    fun displayName(name: String): String = when (name.uppercase(Locale.ROOT)) {
        "TREVO" -> "Trevo"
        "ROSA" -> "Rosa"
        "OVO" -> "Ovo"
        "ESTRELA_DOURADA" -> "Estrela Dourada"
        "PERGAMINHO" -> "Pergaminho"
        "BOLSA_DA_SORTE" -> "Bolsa da Sorte"
        "SINO_DA_SORTE" -> "Sino da Sorte"
        "MOEDAS_DA_SORTE" -> "Moedas da Sorte"
        else -> name.replace('_', ' ').lowercase(Locale.ROOT)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }

    fun normalGiftNameFromSendText(raw: String): String? {
        val clean = raw.replace(Regex("\\s+"), " ").trim()
        val rx = Regex("(?i)(?:enviou|mandou|enviado|sent|gifted)\\s+(?:um\\s+|uma\\s+)?(?:presente\\s+)?(.{2,40}?)(?:\\s+e\\s+ganhou|\\s+x\\d+|$)")
        val candidate = rx.find(clean)?.groupValues?.getOrNull(1)?.trim()?.trim('•', '-', ':')
            ?: return null
        if (candidate.length !in 2..36) return null
        if (afortunadoFromText(candidate) != null) return afortunadoFromText(candidate)
        return candidate.uppercase(Locale.ROOT)
            .replace(Regex("[^A-Z0-9À-Ü ]+"), " ")
            .replace(Regex("\\s+"), "_")
            .trim('_')
            .takeIf { it.isNotBlank() }
    }
}
