package com.example.siyaheatradar

import android.graphics.Bitmap
import android.graphics.Color
import java.text.Normalizer
import java.util.Locale

/**
 * Lê o painel de presentes/Afortunados e identifica o presente selecionado.
 * Trevo, Rosa e Ovo continuam com nomes canônicos para o Gift Engine, mas
 * outros presentes conhecidos também são registrados por sala.
 */
class GiftVision {

    data class Result(
        val panelVisible: Boolean,
        val selectedGift: String?,
        val samples: List<GiftSelectionSample>
    )

    fun measure(bitmap: Bitmap, items: List<OcrItem>): Result {
        val normalizedItems = items.map { it to normalize(it.text) }
        val panelVisible = normalizedItems.any { (_, t) ->
            t.contains("afortunados") || t == "presentes" || t.contains("presentes")
        }
        if (!panelVisible) return Result(false, null, emptyList())

        val candidates = normalizedItems.mapNotNull { (item, text) ->
            val gift = giftFromText(text) ?: genericGift(text) ?: return@mapNotNull null
            val y = item.cy.toDouble() / bitmap.height
            if (y < 0.58) return@mapNotNull null
            val score = selectionBorderScore(bitmap, item)
            GiftSelectionSample(
                gift = gift,
                selectedScore = score,
                positionKey = "$gift:${item.cx / 40}:${item.cy / 40}"
            )
        }.groupBy { it.gift }
            .mapNotNull { (_, values) -> values.maxByOrNull { it.selectedScore } }

        if (candidates.isEmpty()) return Result(true, null, emptyList())

        val sorted = candidates.sortedByDescending { it.selectedScore }
        val best = sorted.first()
        val second = sorted.getOrNull(1)?.selectedScore ?: 0.0
        val selected = if (best.selectedScore >= 0.38 && best.selectedScore >= second + 0.06) {
            best.gift
        } else null

        return Result(true, selected, candidates)
    }

    private fun giftFromText(text: String): String? = when {
        text.contains("trevo") -> "TREVO"
        text.contains("rosa") && (text.contains("sorte") || text == "rosa") -> "ROSA"
        text.contains("quebre o ovo") || text == "ovo" || text.contains(" ovo") -> "OVO"
        text.contains("estrela dour") || text == "estrela" -> "ESTRELA DOURADA"
        text.contains("pergamin") -> "PERGAMINHO"
        text.contains("bolsa da sor") || text == "bolsa" -> "BOLSA DA SORTE"
        text.contains("sino da sor") || text == "sino" -> "SINO DA SORTE"
        text.contains("moedas de") || text == "moedas" -> "MOEDAS"
        else -> null
    }

    private fun genericGift(text: String): String? {
        if (text.length !in 4..26) return null
        if (text.any { it.isDigit() }) return null
        val blocked = listOf(
            "afortunados", "presentes", "token", "celebrid", "recarregar", "nobreza",
            "enviar", "ranking", "jackpot", "todos", "all", "combo", "lucky",
            "atualmente", "destinatarios", "destinatário", "presente"
        )
        if (blocked.any { text.contains(it) }) return null
        val words = text.split(' ').filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 4) return null
        return text.uppercase(Locale.ROOT)
    }

    private fun normalize(raw: String): String = Normalizer.normalize(raw, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9 ]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun selectionBorderScore(bitmap: Bitmap, label: OcrItem): Double {
        val w = bitmap.width
        val h = bitmap.height
        val cx = label.cx
        val halfW = (w * 0.105).toInt()
        val top = (label.cy - h * 0.115).toInt().coerceAtLeast(0)
        val bottom = (label.cy + h * 0.055).toInt().coerceAtMost(h - 1)
        val left = (cx - halfW).coerceAtLeast(0)
        val right = (cx + halfW).coerceAtMost(w - 1)
        if (right <= left || bottom <= top) return 0.0

        fun isSelectedColor(x: Int, y: Int): Boolean {
            if (x !in 0 until w || y !in 0 until h) return false
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            return r >= 145 && r > g * 1.28 && (b >= 55 || r - g >= 65) && (r + g + b) >= 300
        }

        val y0 = (top + h * 0.030).toInt().coerceAtMost(bottom)
        val y1 = (bottom - h * 0.010).toInt().coerceAtLeast(y0)
        val sideBand = (w * 0.012).toInt().coerceAtLeast(4)

        fun bestVerticalFraction(centerX: Int): Double {
            var best = 0.0
            val from = (centerX - sideBand).coerceAtLeast(0)
            val to = (centerX + sideBand).coerceAtMost(w - 1)
            var x = from
            while (x <= to) {
                var hit = 0
                var total = 0
                var y = y0
                while (y <= y1) {
                    if (isSelectedColor(x, y)) hit++
                    total++
                    y += 2
                }
                if (total > 0) best = maxOf(best, hit.toDouble() / total)
                x++
            }
            return best
        }

        val leftSide = bestVerticalFraction(left)
        val rightSide = bestVerticalFraction(right)
        return (maxOf(leftSide, rightSide) * 0.82 + minOf(leftSide, rightSide) * 0.18).coerceIn(0.0, 1.0)
    }
}
