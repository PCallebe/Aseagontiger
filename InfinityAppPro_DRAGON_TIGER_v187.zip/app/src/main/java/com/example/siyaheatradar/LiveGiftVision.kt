package com.example.siyaheatradar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.abs


data class LiveGiftEvent(
    val name: String,
    val isAfortunado: Boolean,
    val quantity: Int,
    val burstTotal: Int?,
    val signature: String,
    val source: String
)

/**
 * Detector de presentes AO VIVO na sala.
 * Usa texto/accessibility e, para Trevo/Rosa/Ovo, referência visual do próprio SIYA.
 */
class LiveGiftVision(context: Context) {
    private val seen = LinkedHashMap<String, Long>()
    private data class BurstState(val total: Int, val ts: Long)
    private val burstState = HashMap<String, BurstState>()

    private val templates = linkedMapOf(
        "TREVO" to BitmapFactory.decodeResource(context.resources, R.drawable.afortunado_trevo_ref),
        "ROSA" to BitmapFactory.decodeResource(context.resources, R.drawable.afortunado_rosa_ref),
        "OVO" to BitmapFactory.decodeResource(context.resources, R.drawable.afortunado_ovo_ref)
    )

    fun reset() {
        seen.clear()
        burstState.clear()
    }

    fun detect(bitmap: Bitmap, items: List<OcrItem>, width: Int, height: Int, now: Long, dynamicAfortunados: Set<String> = emptySet()): List<LiveGiftEvent> {
        if (items.isEmpty() || width <= 0 || height <= 0) return emptyList()
        prune(now)
        val out = mutableListOf<LiveGiftEvent>()

        // 1) Texto de envio vindo do OCR ou da Accessibility tree.
        items.forEach { item ->
            val text = item.text.trim()
            val low = GiftCatalog.normalizeText(text)
            val sendVerb = low.contains("enviou") || low.contains("mandou") || low.contains("enviado") ||
                low.contains(" sent ") || low.startsWith("sent ") || low.contains("gifted")
            if (!sendVerb) return@forEach

            val staticAf = GiftCatalog.afortunadoFromText(text)
            val dynamicAf = dynamicAfortunados.firstOrNull { candidate ->
                val n = GiftCatalog.normalizeText(candidate.replace('_', ' '))
                n.length >= 3 && low.contains(n)
            }
            val af = staticAf ?: dynamicAf
            val name = af ?: GiftCatalog.normalGiftNameFromSendText(text) ?: "PRESENTE_NORMAL"
            val q = quantityFromText(text) ?: 1
            val sig = "SEND:$name:$q:${item.cx / 48}:${item.cy / 48}"
            if (once(sig, now, 1_300L)) {
                out += LiveGiftEvent(name, af != null, q.coerceIn(1, 999), null, sig, "SEND_TEXT")
            }
        }

        // 2) Rajadas xN exibidas na própria sala. Ex.: Ovo x13 -> x35 -> x63.
        items.forEach { item ->
            val total = burstValue(item.text) ?: return@forEach
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            val h = item.h.toDouble() / height
            if (x !in 0.08..0.93 || y !in 0.45..0.91 || h < 0.012) return@forEach

            val near = nearbyText(items, item, width, height)
            val nearLow = GiftCatalog.normalizeText(near)
            if (nearLow.contains("win") || nearLow.contains("jackpot") || nearLow.contains("lucky") ||
                nearLow.contains("rocket") || nearLow.contains("svip") || nearLow.contains("recargar") ||
                nearLow.contains("enviar para") || nearLow.contains("quantidade")) return@forEach

            val textual = GiftCatalog.afortunadoFromText(near)
            val visual = if (textual == null) visualAfortunado(bitmap, item) else null
            val af = textual ?: visual
            val name = af ?: "PRESENTE_RAJADA"
            val key = "$name:${item.cx / 90}:${item.cy / 90}"
            val previous = burstState[key]
            val delta = when {
                previous == null -> total
                now - previous.ts > 8_000L -> total
                total > previous.total -> total - previous.total
                total == previous.total -> 0
                else -> total
            }.coerceIn(0, 500)
            burstState[key] = BurstState(total, now)
            if (delta <= 0) return@forEach

            val sig = "BURST:$key:$total"
            if (once(sig, now, 800L)) {
                out += LiveGiftEvent(name, af != null, delta, total, sig, if (visual != null) "BURST_VISUAL" else "BURST_XN")
            }
        }

        return out
    }

    private fun visualAfortunado(bitmap: Bitmap, xItem: OcrItem): String? {
        return try {
            // O ícone da rajada costuma ficar imediatamente à esquerda do xN.
            val itemH = xItem.h.coerceAtLeast(24)
            // Recorte apertado no ícone imediatamente à esquerda do xN para não misturar placares/nomes.
            val cropW = (itemH * 1.8).toInt().coerceIn(70, (bitmap.width * 0.16).toInt())
            val cropH = (itemH * 1.5).toInt().coerceIn(70, (bitmap.height * 0.07).toInt())
            val right = (xItem.box.left - itemH / 6).coerceIn(1, bitmap.width)
            val left = (right - cropW).coerceAtLeast(0)
            val top = (xItem.cy - cropH / 2).coerceAtLeast(0)
            val bottom = (top + cropH).coerceAtMost(bitmap.height)
            if (right - left < 40 || bottom - top < 40) return null
            val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            val scores = templates.mapValues { (_, ref) -> imageDistance(crop, ref) }
            crop.recycle()
            val best = scores.minByOrNull { it.value } ?: return null
            // Conservador: se a imagem não parece com as referências, não inventa o Afortunado.
            if (best.value <= 58.0) best.key else null
        } catch (_: Throwable) {
            null
        }
    }

    private fun imageDistance(a: Bitmap, b: Bitmap): Double {
        val size = 20
        val aa = Bitmap.createScaledBitmap(a, size, size, true)
        val bb = Bitmap.createScaledBitmap(b, size, size, true)
        var sum = 0.0
        var n = 0
        for (y in 0 until size) {
            for (x in 0 until size) {
                val ca = aa.getPixel(x, y)
                val cb = bb.getPixel(x, y)
                val va = (Color.red(ca) + Color.green(ca) + Color.blue(ca)) / 3
                val vb = (Color.red(cb) + Color.green(cb) + Color.blue(cb)) / 3
                // Fundo escuro em ambos não ajuda a distinguir.
                if (va < 28 && vb < 28) continue
                val dr = abs(Color.red(ca) - Color.red(cb))
                val dg = abs(Color.green(ca) - Color.green(cb))
                val db = abs(Color.blue(ca) - Color.blue(cb))
                sum += (dr + dg + db) / 3.0
                n++
            }
        }
        aa.recycle(); bb.recycle()
        return if (n == 0) 999.0 else sum / n
    }

    private fun quantityFromText(text: String): Int? =
        Regex("(?i)(?:x|×)\\s*(\\d{1,4})").find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()

    private fun burstValue(text: String): Int? {
        val clean = text.trim()
        return Regex("(?i)^(?:x|×)\\s*(\\d{1,4})$").find(clean)?.groupValues?.getOrNull(1)?.toIntOrNull()
            ?: Regex("(?i)\\b(?:x|×)\\s*(\\d{1,4})\\b").find(clean)?.groupValues?.getOrNull(1)?.toIntOrNull()
    }

    private fun nearbyText(items: List<OcrItem>, target: OcrItem, width: Int, height: Int): String {
        val maxDx = width * 0.24
        val maxDy = height * 0.085
        return items.asSequence()
            .filter { it !== target }
            .filter { abs(it.cx - target.cx) <= maxDx && abs(it.cy - target.cy) <= maxDy }
            .sortedBy { abs(it.cy - target.cy) + abs(it.cx - target.cx) }
            .take(10)
            .joinToString(" ") { it.text }
    }

    private fun once(key: String, now: Long, cooldown: Long): Boolean {
        val prev = seen[key] ?: 0L
        if (now - prev < cooldown) return false
        seen[key] = now
        return true
    }

    private fun prune(now: Long) {
        val seenCutoff = now - 60_000L
        val it = seen.entries.iterator()
        while (it.hasNext()) if (it.next().value < seenCutoff) it.remove()
        val burstCutoff = now - 20_000L
        val bit = burstState.entries.iterator()
        while (bit.hasNext()) if (bit.next().value.ts < burstCutoff) bit.remove()
    }
}
