package com.example.siyaheatradar

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs

data class MajorPopupHit(
    val multiplier: Double,
    val yellow: Boolean,
    val signature: String,
    val source: String
)

/**
 * Detecta pagamentos/resultados x50+ que passam como popup/banner lateral na sala.
 *
 * Regras:
 * - ignora os botões estáticos da tela Afortunados/LUCKY;
 * - aceita banner com WIN/ganhou/won;
 * - aceita x50+ grande na metade superior da sala (popup lateral);
 * - amarelo/dourado é marcado como resultado do próprio usuário e alimenta o "meu Lucky".
 */
class MajorPopupVision {
    private val seen = LinkedHashMap<String, Long>()

    fun reset() = seen.clear()

    fun detect(
        bitmap: Bitmap,
        items: List<OcrItem>,
        width: Int,
        height: Int,
        now: Long,
        afortunadosPanelVisible: Boolean
    ): List<MajorPopupHit> {
        if (items.isEmpty() || width <= 0 || height <= 0 || afortunadosPanelVisible) return emptyList()
        prune(now)

        val out = mutableListOf<MajorPopupHit>()

        items.forEach { item ->
            val own = item.text.trim()
            val near = nearbyText(items, item, width, height)
            val merged = "$own $near"
            val normalized = GiftCatalog.normalizeText(merged)

            if (normalized.contains("enviar para") ||
                normalized.contains("quantidade") ||
                normalized.contains("rocket") ||
                normalized.contains("foguete") ||
                normalized.contains("anterior") ||
                normalized.contains("recarregar") ||
                normalized.contains("jackpot")
            ) return@forEach

            val values = multipliers(merged)
                .filter { it in 50.0..1000.0 }
                .distinct()
            if (values.isEmpty()) return@forEach

            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            val h = item.h.toDouble() / height

            // Popup de prêmio corre pela parte superior/meio da sala.
            if (x !in 0.03..0.97 || y !in 0.08..0.58 || h < 0.010) return@forEach

            val hasWinLanguage =
                normalized.contains("win") ||
                normalized.contains("ganhou") ||
                normalized.contains("won") ||
                normalized.contains("premio") ||
                normalized.contains("prêmio") ||
                normalized.contains("recompensa")

            val yellow = yellowRatio(bitmap, item.box, width, height) >= 0.085

            // Fallback para popup lateral grande mesmo quando o OCR perdeu a palavra WIN.
            val largeLateral = h >= 0.020 && y in 0.14..0.48

            if (!hasWinLanguage && !yellow && !largeLateral) return@forEach

            values.forEach { mx ->
                val bucketX = item.cx / 70
                val bucketY = item.cy / 70
                val source = when {
                    yellow -> "YELLOW_SELF"
                    hasWinLanguage -> "WIN_TEXT"
                    else -> "LATERAL_BANNER"
                }
                val sig = "MAJOR:$mx:$bucketX:$bucketY:$source"
                val prev = seen[sig] ?: 0L
                if (now - prev >= 2_400L) {
                    seen[sig] = now
                    out += MajorPopupHit(mx, yellow, sig, source)
                }
            }
        }

        return out.distinctBy { "${it.multiplier}:${it.signature}" }
    }

    private fun multipliers(raw: String): List<Double> {
        val out = mutableListOf<Double>()
        Regex("(?i)(?:WIN\\s*)?(?:x|×)\\s*(\\d{1,4}(?:[.,]\\d+)?)")
            .findAll(raw)
            .forEach { m ->
                m.groupValues[1].replace(',', '.').toDoubleOrNull()?.let(out::add)
            }
        Regex("(?i)\\bWIN\\s*(\\d{1,4}(?:[.,]\\d+)?)\\b")
            .findAll(raw)
            .forEach { m ->
                m.groupValues[1].replace(',', '.').toDoubleOrNull()?.let(out::add)
            }
        return out
    }

    private fun yellowRatio(bitmap: Bitmap, box: Rect, width: Int, height: Int): Double {
        return try {
            val expandX = (width * 0.09).toInt()
            val expandY = (height * 0.028).toInt()
            val left = (box.left - expandX).coerceIn(0, bitmap.width - 1)
            val right = (box.right + expandX).coerceIn(left + 1, bitmap.width)
            val top = (box.top - expandY).coerceIn(0, bitmap.height - 1)
            val bottom = (box.bottom + expandY).coerceIn(top + 1, bitmap.height)

            val stepX = ((right - left) / 18).coerceAtLeast(2)
            val stepY = ((bottom - top) / 10).coerceAtLeast(2)
            var yellow = 0
            var total = 0

            var yy = top
            while (yy < bottom) {
                var xx = left
                while (xx < right) {
                    val c = bitmap.getPixel(xx, yy)
                    val r = Color.red(c)
                    val g = Color.green(c)
                    val b = Color.blue(c)
                    val isYellow = r >= 150 && g >= 105 && b <= 135 &&
                        r >= b + 45 && g >= b + 20 &&
                        abs(r - g) <= 125
                    if (isYellow) yellow++
                    total++
                    xx += stepX
                }
                yy += stepY
            }
            if (total == 0) 0.0 else yellow.toDouble() / total
        } catch (_: Throwable) {
            0.0
        }
    }

    private fun nearbyText(items: List<OcrItem>, target: OcrItem, width: Int, height: Int): String {
        val maxDx = width * 0.36
        val maxDy = height * 0.085
        return items.asSequence()
            .filter { it !== target }
            .filter { abs(it.cx - target.cx) <= maxDx && abs(it.cy - target.cy) <= maxDy }
            .sortedBy { abs(it.cx - target.cx) + abs(it.cy - target.cy) }
            .take(12)
            .joinToString(" ") { it.text }
    }

    private fun prune(now: Long) {
        val cutoff = now - 60_000L
        val it = seen.entries.iterator()
        while (it.hasNext()) {
            if (it.next().value < cutoff) it.remove()
        }
    }
}
