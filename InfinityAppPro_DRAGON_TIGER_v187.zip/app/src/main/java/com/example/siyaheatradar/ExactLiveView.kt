package com.example.siyaheatradar

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.provider.Settings
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityManager
import java.io.File
import java.util.Locale
import kotlin.math.abs

/**
 * Tela AO VIVO baseada diretamente na Referência Visual Mestre aprovada.
 * O fundo preserva ícones, bordas, brilhos, proporções e letras estáticas da referência.
 * Somente os campos de dados são redesenhados em tempo real.
 */
class ExactLiveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        private const val BASE_W = 864f
        private const val BASE_H = 1356f
        private const val SOURCE_CROP_TOP = 44f
    }

    var onUseStrategy: (() -> Unit)? = null
    var onHistory: (() -> Unit)? = null
    var onAuthorize: (() -> Unit)? = null
    var onRoom: (() -> Unit)? = null
    var onJackpot: (() -> Unit)? = null
    var onHeat: (() -> Unit)? = null
    var onTrend: (() -> Unit)? = null
    var onPayout: (() -> Unit)? = null
    var onMultiplier: (() -> Unit)? = null
    var onEmojis: (() -> Unit)? = null
    var onGifts: (() -> Unit)? = null
    var onRocket: (() -> Unit)? = null
    var onPk: (() -> Unit)? = null
    var onLucky: (() -> Unit)? = null
    var onVisitors: (() -> Unit)? = null
    var onScroll: (() -> Unit)? = null
    var onTrevo: (() -> Unit)? = null
    var onRosa: (() -> Unit)? = null
    var onOvo: (() -> Unit)? = null
    var onOthers: (() -> Unit)? = null

    private val prefs = context.getSharedPreferences("radar", Context.MODE_PRIVATE)
    private val master: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.live_clone_master)
    private val defaultBanner: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.room_banner_default)
    private val trevo: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.gift_trevo_gold_clean)
    private val rosa: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.gift_rosa_gold_clean)
    private val ovo: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.gift_ovo_gold_clean)
    private val outros: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.gift_outros_clean)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val bold = Typeface.create("sans-serif", Typeface.BOLD)
    private val medium = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    private var bannerBitmap: Bitmap? = null
    private var bannerStamp = -1L

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        canvas.save()
        canvas.scale(width / BASE_W, height / BASE_H)
        canvas.drawBitmap(master, null, RectF(0f, 0f, BASE_W, BASE_H), p)
        coverReferenceValues(canvas)
        renderDynamic(canvas)
        canvas.restore()
    }

    private fun renderDynamic(c: Canvas) {
        val authorized = isServiceEnabled()
        val room = prefs.getString("current_room", "Detectando sala...") ?: "Detectando sala..."
        val roomId = prefs.getString("current_room_id", null)
        val context = prefs.getString("monitor_context", "SALA") ?: "SALA"
        val seat = prefs.getString("room_seat_status", "DETECTANDO") ?: "DETECTANDO"
        val people = prefs.getInt("room_people_count", 0)
        val lastRead = prefs.getLong("last_read_at", 0L)
        val age = if (lastRead > 0L) ((System.currentTimeMillis() - lastRead) / 1000L).coerceAtLeast(0L) else -1L

        // Cabeçalho: mesma forma da referência, texto de estado real.
        centerText(c, if (authorized) "● AUTOMÁTICO ATIVO" else "● AUTO AGUARDANDO", 298f, fy(162f), 15.5f,
            if (authorized) Color.rgb(72, 255, 155) else Color.rgb(255, 198, 82), true)
        centerText(c, if (authorized) "🔒 AUTORIZADO" else "🔒 PENDENTE", 545f, fy(162f), 15.5f,
            if (authorized) Color.rgb(72, 255, 155) else Color.rgb(255, 198, 82), true)

        // Banner real quando capturado; fallback nunca é a flor antiga.
        val banner = loadRoomBanner()
        c.drawBitmap(banner, null, rf(29f, 190f, 164f, 316f), p)

        val inRoom = !context.contains("ROLAGEM", true) && !room.contains("Detectando", true)
        val roomLabel = if (inRoom) room.take(28) else "DETECTANDO SALA"
        text(c, roomLabel, 177f, fy(223f), 25f, Color.WHITE, true)

        // Mantém o modelo visual Ouro + chip verde + ID, mas com o ID real.
        centerText(c, roomId ?: "—", 313f, fy(257f), 14.5f, Color.WHITE, true)
        val chairs = prefs.getInt("room_chairs_total", 0)
        val idLine = buildString {
            append("ID ${roomId ?: "—"}")
            if (chairs > 0) append("  •  🪑$chairs")
        }
        text(c, idLine, 371f, fy(258f), 13.2f, Color.rgb(196, 211, 239), false)

        val seatText = when {
            !inRoom -> "Detectando"
            seat.contains("POLTRONA", true) -> "Na poltrona"
            else -> "Sala detectada"
        }
        centerText(c, seatText, 265f, fy(300f), 14.5f, Color.WHITE, true)
        centerText(c, if (people > 0) "+$people online" else "atividade", 596f, fy(228f), 15f, Color.rgb(230, 238, 255), false)

        val target = prefs.getString("active_siya_name", "SIYA") ?: "SIYA"
        val radar = when {
            !authorized -> "Radar aguardando autorização"
            age in 0..4 -> "Radar ativo  •  Lendo no $target"
            else -> "Radar ativo  •  aguardando nova leitura"
        }
        text(c, radar, 87f, fy(353f), 15.2f, if (authorized) Color.WHITE else Color.rgb(255, 203, 100), true)

        // Painel ao vivo.
        val heat = prefs.getInt("heat_score", 0)
        val heatState = prefs.getString("heat_state", "FRIA") ?: "FRIA"
        val trend = prefs.getString("trend", "ESTÁVEL") ?: "ESTÁVEL"
        val payout = prefs.getLong("last_confirmed_payout", 0L)
        val maxX = prefs.getFloat("max_multiplier_v14", 0f).toDouble()

        text(c, "$heat/100", 61f, fy(511f), 48f, Color.WHITE, true)
        centerText(c, heatState.take(12), 315f, fy(508f), 16f, Color.rgb(255, 219, 125), true)
        text(c, trend.take(15), 475f, fy(510f), 31f, Color.rgb(255, 235, 197), true)
        text(c, if (payout > 0) format(payout) else "—", 62f, fy(620f), 49f, Color.WHITE, true)
        text(c, if (maxX > 0) "x${formatX(maxX)}" else "—", 470f, fy(620f), 48f, Color.WHITE, true)

        // Leitura da sala.
        val emojis = prefs.getInt("room_emojis_1m", 0)
        val emojiLevel = prefs.getString("room_emojis_level", "SEM SINAL") ?: "SEM SINAL"
        val gifts = prefs.getInt("room_gifts_1m", 0)
        val giftLevel = prefs.getString("room_gifts_level", "SEM SINAL") ?: "SEM SINAL"
        val rocket = prefs.getInt("room_rocket_progress", -1)
        val rocketTrend = prefs.getString("room_rocket_trend", "AGUARDANDO VALOR") ?: "AGUARDANDO VALOR"
        val rocketLabel = prefs.getString("room_rocket_label", "—") ?: "—"
        val pk = prefs.getString("room_pk_status", "NÃO DETECTADO") ?: "NÃO DETECTADO"
        val lucky = prefs.getInt("light_1m", 0)
        val luckyHigh = prefs.getInt("light_high_1m", 0)
        val luckyOwnTotal = prefs.getInt("lucky_session_total_x", 0)
        val luckyMajorHits = prefs.getInt("lucky_major_hits_1m", 0)
        val scrolls = prefs.getInt("room_scroll_1m", 0)
        val scrollLevel = prefs.getString("room_scroll_level", "BAIXA") ?: "BAIXA"

        signalText(c, emojiLevel, "$emojis/min", 112f, 770f, Color.rgb(84,255,171))
        signalText(c, giftLevel, "$gifts/min", 316f, 770f, Color.rgb(84,255,171))
        signalText(c, if (rocketLabel != "—") rocketLabel else if (rocket >= 0) "$rocket%" else "—", if (rocket >= 0) "$rocket% • ${rocketTrend.take(9)}" else rocketTrend.take(13), 518f, 770f, Color.rgb(78,215,255))
        signalText(
            c,
            pk,
            when (pk) {
                "ATIVO" -> "batalha detectada"
                "DESLIGADO" -> "sem batalha"
                else -> ""
            },
            716f, 770f,
            if (pk == "ATIVO") Color.rgb(84,255,171) else Color.rgb(210,224,242)
        )
        signalText(
            c,
            when {
                luckyOwnTotal > 0 -> "x$luckyOwnTotal"
                lucky > 0 -> "$lucky pulsos"
                else -> "0/min"
            },
            when {
                luckyMajorHits > 0 -> "$luckyMajorHits 50x+ /min"
                luckyHigh > 0 -> "200x+ $luckyHigh"
                else -> "na sala"
            },
            113f, 861f, Color.rgb(215,137,255)
        )
        signalText(c, if (people > 0) people.toString() else "—", if (people > 0) "online" else "", 377f, 861f, Color.rgb(97,220,255))
        signalText(c, scrollLevel, "$scrolls/min", 674f, 861f, Color.rgb(255,219,113))

        // Estratégia: mesma lógica já existente; não altera janela/referência de jogadas.
        val bestGiftRaw = prefs.getString("data_best_gift", "").orEmpty().trim()
        val hasBestGift = bestGiftRaw.isNotBlank()
        val bestGift = if (hasBestGift) bestGiftRaw.uppercase(Locale.ROOT) else ""
        val bestDisplay = if (hasBestGift) giftDisplay(bestGift) else "Coletando"
        val confidence = prefs.getString("gift_confidence", "BAIXA • COLETANDO") ?: "BAIXA • COLETANDO"
        val maturity = prefs.getInt("data_maturity_confidence", 0).coerceIn(0, 100)
        val activity = prefs.getInt("room_activity_score", 0)

        val summary = buildString {
            if (hasBestGift) append("Neste momento, o melhor desempenho observado é com o Afortunado $bestDisplay. ")
            else append("Coletando resultados dos Afortunados desta sala. ")
            append("A sala está ${heatState.lowercase(Locale.getDefault())}, HEAT $heat/100")
            if (rocketTrend.isNotBlank() && !rocketTrend.contains("NÃO", true)) append(", foguete ${rocketTrend.lowercase(Locale.getDefault())}")
            if (pk == "ATIVO") append(" e PK ativo")
            append(". Acompanhamento baseado nas amostras reais desta sala.")
        }
        wrappedText(c, summary, 232f, fy(1017f), 395f, 15.2f, Color.rgb(241,229,255), 20f, 6)

        val confLabel = confidence.substringBefore('•').trim().ifBlank { "BAIXA" }
        centerText(c, "CONFIANÇA", 751f, fy(1030f), 14f, Color.rgb(103,255,202), false)
        centerText(c, confLabel, 751f, fy(1068f), 29f, Color.rgb(81,255,177), true)
        centerText(c, "${if (maturity > 0) maturity else 5}%  ▂▄▆█", 751f, fy(1111f), 22f, Color.rgb(81,255,177), true)

        // Presente sugerido com imagem dinâmica.
        val bestBmp = if (hasBestGift) giftBitmap(bestGift) else outros
        c.drawBitmap(bestBmp, null, rf(62f, 1172f, 151f, 1252f), p)
        text(c, bestDisplay, 165f, fy(1205f), 23f, Color.WHITE, true)
        centerText(c, if (hasBestGift) "MELHOR DESEMPENHO" else "AGUARDANDO DADOS", 242f, fy(1244f), 12.8f, Color.rgb(28,25,7), true)

        val ts = prefs.getInt("data_trevo_samples", 0)
        val rs = prefs.getInt("data_rosa_samples", 0)
        val os = prefs.getInt("data_ovo_samples", 0)
        val tScore = prefs.getInt("data_trevo_score", 0)
        val rScore = prefs.getInt("data_rosa_score", 0)
        val oScore = prefs.getInt("data_ovo_score", 0)
        val otherSamples = prefs.getInt("data_other_best_samples", 0)
        val otherScore = prefs.getInt("data_other_best_score", 0)
        val total = (tScore + rScore + oScore + otherScore).coerceAtLeast(1)
        fun pct(v: Int, samples: Int) = if (samples <= 0) 0 else ((v * 100.0) / total).toInt().coerceIn(0,100)
        performance(c, "Trevo", ts, pct(tScore, ts), 414f)
        performance(c, "Rosa", rs, pct(rScore, rs), 526f)
        performance(c, "Ovo", os, pct(oScore, os), 638f)
        performance(c, "Outros", otherSamples, pct(otherScore, otherSamples), 774f)

        val strategyPeople = prefs.getInt("strategy_people_count", 0)
        val strategyQty = prefs.getInt("strategy_gift_count", 0)
        val configValue = if (strategyPeople > 0) "$strategyPeople pessoas" else "coletando"
        centerText(c, configValue, 140f, fy(1374f), 16f, Color.WHITE, true)
        centerText(c, "HEAT $heat–${(heat+15).coerceAtMost(100)}", 342f, fy(1374f), 16f, Color.rgb(255,218,73), true)
        centerText(c, if (activity >= 55) "Rajadas curtas" else "janela observada", 536f, fy(1370f), 14f, Color.WHITE, true)
        centerText(c, if (activity >= 55) "Manter enquanto alta" else "aguardar amostras", 731f, fy(1370f), 13.2f, Color.WHITE, true)
    }

    /**
     * A referência visual contém números de demonstração.
     * Esta função cobre SOMENTE esses valores, com caixas pequenas dentro
     * da área útil de cada card. Não cobre títulos, ícones ou bordas.
     */
    private fun coverReferenceValues(c: Canvas) {
        fun box(
            x1: Float, y1: Float, x2: Float, y2: Float,
            color: Int, radius: Float = 8f
        ) {
            p.style = Paint.Style.FILL
            p.color = color
            c.drawRoundRect(rf(x1, y1, x2, y2), radius, radius, p)
        }

        // Sala
        box(174f, 193f, 486f, 230f, Color.rgb(5, 18, 40), 5f)     // nome
        box(299f, 236f, 363f, 260f, Color.rgb(23, 121, 76), 5f)   // chip verde
        box(395f, 237f, 492f, 262f, Color.rgb(5, 18, 40), 4f)     // ID
        box(550f, 205f, 644f, 237f, Color.rgb(7, 28, 56), 6f)     // online
        box(223f, 280f, 318f, 307f, Color.rgb(94, 27, 147), 5f)   // poltrona

        // Painel ao vivo — caixas pequenas, abaixo dos títulos
        box(59f, 474f, 232f, 526f, Color.rgb(65, 13, 34), 5f)
        box(270f, 478f, 348f, 511f, Color.rgb(67, 13, 34), 12f)
        box(469f, 474f, 721f, 522f, Color.rgb(31, 14, 68), 5f)
        box(59f, 588f, 211f, 646f, Color.rgb(58, 39, 5), 5f)
        box(468f, 589f, 619f, 646f, Color.rgb(8, 31, 60), 5f)

        // Leitura da sala — mantém os rótulos e ícones
        box(108f, 739f, 218f, 797f, Color.rgb(6, 52, 48), 5f)
        box(305f, 739f, 428f, 797f, Color.rgb(6, 52, 48), 5f)
        box(509f, 739f, 634f, 797f, Color.rgb(6, 38, 62), 5f)
        box(708f, 739f, 828f, 797f, Color.rgb(6, 50, 47), 5f)
        box(108f, 838f, 220f, 898f, Color.rgb(35, 20, 74), 5f)
        box(373f, 838f, 555f, 898f, Color.rgb(7, 40, 62), 5f)
        box(664f, 838f, 829f, 898f, Color.rgb(13, 31, 51), 5f)

        // Estratégia
        box(229f, 994f, 643f, 1129f, Color.rgb(50, 14, 80), 8f)
        box(685f, 1024f, 810f, 1117f, Color.rgb(5, 58, 47), 8f)
        box(162f, 1184f, 307f, 1223f, Color.rgb(38, 20, 13), 4f)

        // Números dos cards dos Afortunados — ícones e nomes permanecem
        box(378f, 1255f, 461f, 1317f, Color.rgb(6, 26, 48), 4f)
        box(492f, 1255f, 575f, 1317f, Color.rgb(6, 26, 48), 4f)
        box(606f, 1255f, 689f, 1317f, Color.rgb(6, 26, 48), 4f)
        box(736f, 1255f, 820f, 1317f, Color.rgb(6, 26, 48), 4f)

        // Cards inferiores
        box(70f, 1344f, 220f, 1393f, Color.rgb(6, 27, 49), 4f)
        box(273f, 1344f, 437f, 1393f, Color.rgb(6, 27, 49), 4f)
        box(469f, 1344f, 630f, 1393f, Color.rgb(6, 27, 49), 4f)
        box(666f, 1344f, 831f, 1393f, Color.rgb(6, 27, 49), 4f)

        p.style = Paint.Style.FILL
    }

    private fun signalText(c: Canvas, line1: String, line2: String, x: Float, fullY: Float, color: Int) {
        centerText(c, line1.take(16), x + 55f, fy(fullY), 16f, color, true)
        if (line2.isNotBlank()) centerText(c, line2.take(16), x + 55f, fy(fullY + 24f), 13.5f, Color.rgb(232,238,250), false)
    }

    private fun performance(c: Canvas, name: String, events: Int, pct: Int, centerX: Float) {
        centerText(c, name, centerX, fy(1254f), 13f, Color.WHITE, false)
        centerText(c, "$events eventos", centerX, fy(1278f), 12f, Color.rgb(215,223,241), false)
        centerText(c, "$pct%", centerX, fy(1302f), 16f,
            when(name) { "Trevo" -> Color.rgb(63,235,151); "Rosa" -> Color.rgb(224,90,255); "Ovo" -> Color.rgb(255,120,77); else -> Color.rgb(214,222,242) }, true)
    }

    private fun loadRoomBanner(): Bitmap {
        val stamp = prefs.getLong("room_banner_updated_at", 0L)
        if (stamp != bannerStamp) {
            bannerStamp = stamp
            try {
                val file = File(context.filesDir, "room_banner.jpg")
                if (file.exists()) {
                    val decoded = BitmapFactory.decodeFile(file.absolutePath)
                    if (decoded != null) bannerBitmap = decoded
                }
            } catch (_: Throwable) { }
        }
        return bannerBitmap ?: defaultBanner
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_UP) return true
        val rx = event.x / width * BASE_W
        val bodyY = event.y / height * BASE_H
        val fullY = bodyY + SOURCE_CROP_TOP

        when {
            rx in 175f..640f && fullY in 132f..182f -> onAuthorize?.invoke()
            rx in 20f..620f && fullY in 185f..320f -> onRoom?.invoke()
            rx in 620f..842f && fullY in 245f..322f -> onJackpot?.invoke()
            rx in 32f..430f && fullY in 420f..535f -> onHeat?.invoke()
            rx in 438f..835f && fullY in 420f..535f -> onTrend?.invoke()
            rx in 32f..430f && fullY in 540f..655f -> onPayout?.invoke()
            rx in 438f..835f && fullY in 540f..655f -> onMultiplier?.invoke()
            rx in 32f..225f && fullY in 718f..812f -> onEmojis?.invoke()
            rx in 230f..430f && fullY in 718f..812f -> onGifts?.invoke()
            rx in 435f..635f && fullY in 718f..812f -> onRocket?.invoke()
            rx in 640f..835f && fullY in 718f..812f -> onPk?.invoke()
            rx in 32f..275f && fullY in 815f..905f -> onLucky?.invoke()
            rx in 278f..562f && fullY in 815f..905f -> onVisitors?.invoke()
            rx in 565f..835f && fullY in 815f..905f -> onScroll?.invoke()
            rx in 44f..338f && fullY in 1250f..1314f -> onUseStrategy?.invoke()
            rx in 675f..835f && fullY in 925f..982f -> onHistory?.invoke()
            rx in 350f..463f && fullY in 1160f..1315f -> onTrevo?.invoke()
            rx in 465f..588f && fullY in 1160f..1315f -> onRosa?.invoke()
            rx in 590f..711f && fullY in 1160f..1315f -> onOvo?.invoke()
            rx in 713f..835f && fullY in 1160f..1315f -> onOthers?.invoke()
        }
        return true
    }

    private fun rf(x1: Float, fullY1: Float, x2: Float, fullY2: Float) = RectF(x1, fy(fullY1), x2, fy(fullY2))
    private fun fy(fullY: Float) = fullY - SOURCE_CROP_TOP

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, isBold: Boolean) {
        p.color = color
        p.textSize = size
        p.typeface = if (isBold) bold else medium
        p.textAlign = Paint.Align.LEFT
        c.drawText(s, x, y, p)
    }

    private fun centerText(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, isBold: Boolean) {
        p.color = color
        p.textSize = size
        p.typeface = if (isBold) bold else medium
        p.textAlign = Paint.Align.CENTER
        c.drawText(s, x, y, p)
    }

    private fun wrappedText(c: Canvas, text: String, x: Float, y: Float, maxWidth: Float, size: Float, color: Int, lineHeight: Float, maxLines: Int) {
        p.color = color
        p.textSize = size
        p.typeface = medium
        p.textAlign = Paint.Align.LEFT
        val words = text.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var current = ""
        for (word in words) {
            val candidate = if (current.isBlank()) word else "$current $word"
            if (p.measureText(candidate) <= maxWidth) current = candidate
            else {
                if (current.isNotBlank()) lines += current
                current = word
                if (lines.size >= maxLines - 1) break
            }
        }
        if (current.isNotBlank() && lines.size < maxLines) lines += current
        lines.take(maxLines).forEachIndexed { i, line -> c.drawText(line, x, y + i * lineHeight, p) }
    }

    private fun giftBitmap(raw: String): Bitmap = when(raw.uppercase(Locale.ROOT)) {
        "ROSA" -> rosa
        "OVO" -> ovo
        "TREVO" -> trevo
        else -> outros
    }

    private fun giftDisplay(raw: String): String = GiftCatalog.displayName(raw).take(16)

    private fun format(v: Long): String = when {
        v >= 1_000_000L -> String.format(Locale.US, "%.1fM", v / 1_000_000.0)
        v >= 1_000L -> String.format(Locale.US, "%.1fK", v / 1_000.0)
        else -> v.toString()
    }

    private fun formatX(v: Double): String {
        val r = kotlin.math.round(v * 10.0) / 10.0
        return if (abs(r - r.toInt()) < 0.0001) r.toInt().toString() else String.format(Locale.US, "%.1f", r)
    }

    private fun isServiceEnabled(): Boolean {
        val byManager = try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .any { info ->
                    val si = info.resolveInfo.serviceInfo
                    si.packageName == context.packageName &&
                        (si.name == SiyaAnalyzerService::class.java.name || si.name.endsWith(".SiyaAnalyzerService"))
                }
        } catch (_: Throwable) { false }
        if (byManager) return true

        return try {
            val expected = ComponentName(context, SiyaAnalyzerService::class.java)
            val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            raw.split(':').any { item ->
                val component = ComponentName.unflattenFromString(item.trim())
                component != null && component.packageName == expected.packageName && component.className == expected.className
            }
        } catch (_: Throwable) { false }
    }
}
