package com.example.siyaheatradar

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/** Evita OCR pesado em frames praticamente idênticos. */
class FrameGate {
    private var last: IntArray? = null
    private var lastProcessedAt = 0L

    fun reset() {
        last = null
        lastProcessedAt = 0L
    }

    fun shouldProcess(bitmap: Bitmap, now: Long, force: Boolean): Boolean {
        if (force) {
            last = signature(bitmap)
            lastProcessedAt = now
            return true
        }
        val sig = signature(bitmap)
        val prev = last
        if (prev == null) {
            last = sig
            lastProcessedAt = now
            return true
        }
        var diff = 0.0
        for (i in sig.indices) diff += abs(sig[i] - prev[i])
        diff /= sig.size.coerceAtLeast(1)
        val timeForce = now - lastProcessedAt >= 2_500L
        val changed = diff >= 7.5 || timeForce
        if (changed) {
            last = sig
            lastProcessedAt = now
        }
        return changed
    }

    private fun signature(bitmap: Bitmap): IntArray {
        val cols = 12
        val rows = 18
        val out = IntArray(cols * rows)
        var k = 0
        for (ry in 0 until rows) {
            val y = (((ry + 0.5) / rows) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
            for (rx in 0 until cols) {
                val x = (((rx + 0.5) / cols) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                val c = bitmap.getPixel(x, y)
                out[k++] = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
            }
        }
        return out
    }
}
