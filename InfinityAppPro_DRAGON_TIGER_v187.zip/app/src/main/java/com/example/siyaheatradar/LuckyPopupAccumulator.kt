package com.example.siyaheatradar

import java.util.ArrayDeque
import kotlin.math.roundToInt

data class LuckyPopupStats(
    val hits1m: Int,
    val sumX1m: Int,
    val maxX1m: Int,
    val sessionTotalX: Int
)

/**
 * Acumula apenas popups amarelos/dourados x50+ do próprio usuário.
 * Isso é separado das luzes fixas do painel LUCKY.
 */
class LuckyPopupAccumulator {
    private data class Hit(val ts: Long, val multiplier: Double)
    private val hits = ArrayDeque<Hit>()
    private var sessionTotal = 0.0

    fun reset() {
        hits.clear()
        sessionTotal = 0.0
    }

    fun ingest(hit: MajorPopupHit, now: Long) {
        if (!hit.yellow || hit.multiplier < 50.0) return
        hits.addLast(Hit(now, hit.multiplier))
        sessionTotal += hit.multiplier
        prune(now)
    }

    fun snapshot(now: Long): LuckyPopupStats {
        prune(now)
        val recent = hits.filter { it.ts >= now - 60_000L }
        return LuckyPopupStats(
            hits1m = recent.size,
            sumX1m = recent.sumOf { it.multiplier }.roundToInt(),
            maxX1m = recent.maxOfOrNull { it.multiplier }?.roundToInt() ?: 0,
            sessionTotalX = sessionTotal.roundToInt()
        )
    }

    private fun prune(now: Long) {
        val cutoff = now - 5L * 60L * 1000L
        while (hits.isNotEmpty() && hits.first().ts < cutoff) hits.removeFirst()
    }
}
