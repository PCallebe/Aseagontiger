package com.example.siyaheatradar

data class StrategyRead(
    val giftCount: Int?,
    val peopleCount: Int?,
    val rawHint: String
)

class StrategyVision {

    fun measure(items: List<OcrItem>): StrategyRead {
        val all = items.joinToString(" | ") { it.text }
        val clean = all
            .replace("×", "x")
            .replace("✕", "x")
            .replace(Regex("""\s+"""), " ")
            .trim()

        val giftCount = sequenceOf(
            Regex("""(?i)\benviar\s*x\s*(\d{1,3})\b"""),
            Regex("""(?i)\bquantidade\s*[:=]?\s*x?\s*(\d{1,3})\b"""),
            Regex("""(?i)\bqtd\s*[:=]?\s*x?\s*(\d{1,3})\b""")
        ).mapNotNull { rx ->
            rx.find(clean)?.groupValues?.getOrNull(1)?.toIntOrNull()
        }.firstOrNull { it in 1..100 }

        val peopleCount = sequenceOf(
            Regex("""(?i)\b(\d{1,2})\s*pessoas?\b"""),
            Regex("""(?i)\b(\d{1,2})\s*selecionad[oa]s?\b"""),
            Regex("""(?i)\bpara\s+(\d{1,2})\s*(?:pessoas?)?\b"""),
            Regex("""(?i)\balvos?\s*[:=]?\s*(\d{1,2})\b"""),
            Regex("""(?i)\b(\d{1,2})\s*/\s*\d{1,2}\s*(?:pessoas?|selecionad[oa]s?)?\b""")
        ).mapNotNull { rx ->
            rx.find(clean)?.groupValues?.getOrNull(1)?.toIntOrNull()
        }.firstOrNull { it in 1..20 }

        return StrategyRead(
            giftCount = giftCount,
            peopleCount = peopleCount,
            rawHint = clean.take(600)
        )
    }
}
