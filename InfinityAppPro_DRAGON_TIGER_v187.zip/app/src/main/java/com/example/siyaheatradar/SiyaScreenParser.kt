package com.example.siyaheatradar

import android.graphics.Rect
import kotlin.math.abs

class SiyaScreenParser {

    fun parse(
        items: List<OcrItem>,
        width: Int,
        height: Int,
        now: Long,
        luckyLights: List<LuckyLightSample> = emptyList(),
        selectedGift: String? = null,
        giftPanelVisible: Boolean = false
    ): ScreenRead {
        if (items.isEmpty()) {
            return ScreenRead(
                timestamp = now,
                roomName = null,
                roomId = null,
                roomUiConfirmed = false,
                jackpotBanner = false,
                jackpotValue = null,
                payout = null,
                previousPayout = null,
                wins = emptyList(),
                luckyLights = emptyList(),
                selectedGift = selectedGift,
                giftPanelVisible = giftPanelVisible,
                maxMultiplier = null,
                rawSignals = emptyList()
            )
        }

        val normalized = items
            .map { it.copy(text = clean(it.text)) }
            .filter { it.text.isNotBlank() }

        val signals = mutableListOf<String>()

        val roomId = detectRoomId(normalized, height)
        val roomName = detectRoomName(normalized, width, height)
        val allText = normalized.joinToString(" ") { it.text }.lowercase()
        val fixedLuckyCount = normalized.mapNotNull { exactFixedLuckyMultiplier(it.text) }.distinct().size
        val luckyPanelVisible = allText.contains("lucky") &&
            (allText.contains("jackpot") || allText.contains("afortunados")) &&
            fixedLuckyCount >= 2

        val roomControlMarkers = listOf(
            "top diário", "top diario", "ranking", "conversar", "presente",
            "todos", "rocket", "microfone", "visitantes"
        ).count { allText.contains(it) }
        val participantLikeTexts = normalized.count { item ->
            val y = item.cy.toDouble() / height
            y in 0.12..0.62 && item.text.count { it.isLetter() } >= 2 && item.text.length in 2..26
        }
        val occupiedRoomUi = roomControlMarkers >= 2 && participantLikeTexts >= 3

        val roomUiConfirmed =
            roomId != null ||
            roomName != null ||
            occupiedRoomUi ||
            luckyPanelVisible ||
            (allText.contains("afortunados") && allText.contains("presentes") &&
                (allText.contains("token") || allText.contains("jackpot")))

        if (roomUiConfirmed) signals += "TELA_SALA"
        if (roomName != null) signals += "SALA_$roomName"
        if (roomId != null) signals += "ID_$roomId"

        val previousPayout = detectPreviousPayout(normalized, width, height)
        if (previousPayout != null) signals += "ANTERIOR_$previousPayout"

        val jackpotBanner = luckyPanelVisible || normalized.any {
            val t = it.text.lowercase()
            val y = it.cy.toDouble() / height
            y in 0.05..0.34 && (
                t.contains("jackpot") ||
                t.contains("ganhe moedas") ||
                t.contains("ganhe moeda") ||
                t.contains("moedas de presente")
            )
        }

        if (jackpotBanner) signals += "JACKPOT"

        val jackpotValue = detectJackpotValue(normalized, width, height, luckyPanelVisible)
        if (jackpotValue != null) signals += "JACKPOT_VALOR_$jackpotValue"

        luckyLights.forEach { signals += "LUZ_X${it.multiplier}_${String.format("%.3f", it.score)}" }
        if (giftPanelVisible) signals += "PAINEL_PRESENTES"
        selectedGift?.let { signals += "PRESENTE_$it" }

        val wins = detectWins(normalized, width, height, signals, luckyPanelVisible)

        val payout = detectCenterPayout(
            normalized = normalized,
            width = width,
            height = height,
            jackpotBanner = jackpotBanner
        )

        if (payout != null) signals += "PAYOUT_$payout"

        return ScreenRead(
            timestamp = now,
            roomName = roomName,
            roomId = roomId,
            roomUiConfirmed = roomUiConfirmed,
            jackpotBanner = jackpotBanner,
            jackpotValue = jackpotValue,
            payout = payout,
            previousPayout = previousPayout,
            wins = wins,
            luckyLights = luckyLights,
            selectedGift = selectedGift,
            giftPanelVisible = giftPanelVisible,
            maxMultiplier = wins.maxOfOrNull { it.multiplier },
            rawSignals = signals
        )
    }

    private fun detectRoomId(
        items: List<OcrItem>,
        height: Int
    ): String? {
        items.forEach { item ->
            val y = item.cy.toDouble() / height
            if (y !in 0.045..0.145) return@forEach

            Regex("""(?i)\bID\s*[:#-]?\s*(\d{5,12})\b""")
                .find(item.text)
                ?.groupValues
                ?.getOrNull(1)
                ?.let { return it }
        }

        // ML Kit às vezes separa "ID" e o número em elementos diferentes.
        val idLabels = items.filter {
            val y = it.cy.toDouble() / height
            y in 0.045..0.145 && it.text.equals("ID", true)
        }

        for (label in idLabels) {
            val near = items
                .filter {
                    it.cy in (label.cy - 35)..(label.cy + 35) &&
                    it.cx > label.cx &&
                    it.cx < label.cx + 260
                }
                .sortedBy { it.cx }

            near.forEach {
                Regex("""\b(\d{5,12})\b""")
                    .find(it.text)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.let { id -> return id }
            }
        }

        return null
    }

    private fun detectRoomName(
        items: List<OcrItem>,
        width: Int,
        height: Int
    ): String? {
        val blocked = listOf(
            "prata", "ouro", "bronze", "diamante", "id",
            "anterior", "jackpot", "win", "enviar", "top",
            "svip", "presente", "mensagem", "todos", "chat",
            "microfone", "nova mensagem", "whatsapp", "ligação", "ligacao",
            "chamada", "videochamada", "chamada de vídeo", "chamada de video",
            "visitantes", "explorar", "jogos", "festa", "inicio", "início",
            "top diário", "top diario", "conversar", "rocket", "go", "ranking"
        )

        data class Candidate(
            val label: String,
            val score: Double
        )

        val candidates = items.mapNotNull { item ->
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            val h = item.h.toDouble() / height

            // Título da sala nas telas enviadas fica no canto superior esquerdo,
            // acima da linha Prata/Ouro + ID e abaixo da barra do sistema.
            if (y !in 0.025..0.155) return@mapNotNull null
            if (x !in 0.025..0.62) return@mapNotNull null

            val label = item.text
                .replace(Regex("""[^\p{L}\p{N} _'\-]+"""), " ")
                .replace(Regex("""\s+"""), " ")
                .trim()

            if (label.length !in 4..42) return@mapNotNull null
            if (label.count { it.isLetter() } < 4) return@mapNotNull null

            val low = label.lowercase()

            if (blocked.any { low == it || low.startsWith("$it ") }) {
                return@mapNotNull null
            }

            if (low.contains(" id ") || low.startsWith("id ")) return@mapNotNull null
            if (Regex("""^\d+[:.]\d+$""").matches(label)) return@mapNotNull null
            if (Regex("""^\d+(?:[.,]\d+)?[kKmM]?$""").matches(label)) return@mapNotNull null

            var score = 0.0
            score += label.count { it.isLetter() } * 1.1
            score += (h * 420.0).coerceAtMost(15.0)

            if (x in 0.08..0.34) score += 8.0
            if (y in 0.045..0.105) score += 12.0
            if (label.length in 6..28) score += 4.0
            if (label.any { it.isUpperCase() }) score += 2.0

            Candidate(label, score)
        }

        return candidates.maxByOrNull { it.score }?.label
    }

    private fun detectPreviousPayout(
        items: List<OcrItem>,
        width: Int,
        height: Int
    ): Long? {
        val header = items.filter {
            val y = it.cy.toDouble() / height
            val x = it.cx.toDouble() / width
            y in 0.085..0.18 && x < 0.62
        }

        header.forEach { item ->
            val low = item.text.lowercase()
            if (low.contains("anterior")) {
                parseCompactNumber(item.text)?.let { return it }

                val near = nearbyText(header, item, width, height)
                parseCompactNumber(near)?.let { return it }
            }
        }

        return null
    }

    private fun detectWins(
        items: List<OcrItem>,
        width: Int,
        height: Int,
        signals: MutableList<String>,
        luckyPanelVisible: Boolean
    ): List<WinHit> {
        val wins = mutableListOf<WinHit>()
        val seen = mutableSetOf<String>()

        items.forEach { item ->
            val mx = multiplierValue(item.text) ?: return@forEach
            if (mx < 2.0 || mx > 1000.0) return@forEach

            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            val hNorm = item.h.toDouble() / height
            val near = nearbyText(items, item, width, height).lowercase()
            val own = item.text.lowercase()

            // COMBO é contador de sequência/quantidade, não pagamento individual.
            if (own.contains("combo") || near.contains("combo")) return@forEach

            // Os seis botões fixos do LUCKY são pagamentos somente quando o painel
            // acende. A confirmação deles é feita pela visão de luminosidade, não
            // pelo OCR estático do texto x20/x50/x200/x300/x500/x1000.
            if (luckyPanelVisible && mx in setOf(20.0, 50.0, 200.0, 300.0, 500.0, 1000.0)) {
                val yLucky = item.cy.toDouble() / height
                if (yLucky in 0.28..0.70 && isFixedLuckySlot(mx.toInt(), x) && !own.contains("win")) {
                    return@forEach
                }
            }

            // Quantidade que alguém está enviando não é resultado.
            if (
                near.contains("enviar") ||
                near.contains("enviar para") ||
                near.contains("quantidade")
            ) return@forEach

            // Badges/níveis/IDs e barra do foguete não são WIN.
            if (
                near.contains("svip") ||
                near.contains("id ") ||
                near.contains("300k") ||
                near.contains("100k")
            ) {
                // Se a própria palavra WIN estiver junto, ainda pode ser resultado real.
                if (!own.contains("win") && !near.contains(" win ")) return@forEach
            }

            val explicitWin = own.contains("win") || near.contains("win")

            // Resultados de Afortunados podem aparecer como banner com nome + xN,
            // mesmo sem a palavra WIN. Nas referências esse banner ocupa a faixa
            // inferior da grade (ex.: x32).
            val resultBanner =
                y in 0.60..0.755 &&
                x in 0.30..0.92 &&
                hNorm >= 0.015

            // Animações grandes no miolo também são resultados válidos.
            val centerAnimation =
                y in 0.16..0.60 &&
                x in 0.16..0.90 &&
                hNorm >= 0.020

            if (!explicitWin && !resultBanner && !centerAnimation) return@forEach

            val key = "$mx:${item.cx / 55}:${item.cy / 55}"
            if (seen.add(key)) {
                wins += WinHit(mx, key)
                signals += "WIN_X$mx"
            }
        }

        return wins
    }



    private fun isFixedLuckySlot(multiplier: Int, x: Double): Boolean = when (multiplier) {
        20 -> x in 0.02..0.16
        50 -> x in 0.12..0.30
        200 -> x in 0.25..0.43
        300 -> x in 0.52..0.70
        500 -> x in 0.64..0.84
        1000 -> x in 0.78..0.98
        else -> false
    }

    private fun detectJackpotValue(
        items: List<OcrItem>,
        width: Int,
        height: Int,
        luckyPanelVisible: Boolean
    ): Long? {
        val jackpotLabels = items.filter { it.text.contains("jackpot", true) }
        val candidates = mutableListOf<Pair<Long, Double>>()

        for (label in jackpotLabels) {
            for (item in items) {
                val dx = kotlin.math.abs(item.cx - label.cx).toDouble() / width
                val dy = kotlin.math.abs(item.cy - label.cy).toDouble() / height
                if (dx > 0.28 || dy > 0.12) continue

                val n = parseLargeNumber(item.text) ?: continue
                if (n !in 100_000L..5_000_000L) continue
                val score = 2.2 - dx * 2.2 - dy * 4.2 + (item.h.toDouble() / height * 8.0)
                candidates += n to score
            }
        }

        if (candidates.isNotEmpty()) return candidates.maxByOrNull { it.second }?.first

        if (luckyPanelVisible) {
            // Fallback para quando o OCR perde a palavra JACKPOT, mas lê o contador.
            items.forEach { item ->
                val x = item.cx.toDouble() / width
                val y = item.cy.toDouble() / height
                if (x < 0.62 || y !in 0.25..0.62) return@forEach
                val n = parseLargeNumber(item.text) ?: return@forEach
                if (n in 100_000L..5_000_000L) {
                    candidates += n to (x + item.h.toDouble() / height)
                }
            }
        }

        return candidates.maxByOrNull { it.second }?.first
    }

    private fun exactFixedLuckyMultiplier(raw: String): Int? {
        val t = clean(raw)
        return Regex("""(?i)^x\s*(20|50|200|300|500|1000)$""")
            .find(t)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
    }

    private fun detectCenterPayout(
        normalized: List<OcrItem>,
        width: Int,
        height: Int,
        jackpotBanner: Boolean
    ): Long? {
        val payoutCandidates = mutableListOf<Pair<Long, Double>>()

        normalized.forEach { item ->
            val t = item.text
            val y = item.cy.toDouble() / height
            val x = item.cx.toDouble() / width
            val hNorm = item.h.toDouble() / height

            if (y !in 0.28..0.74) return@forEach
            if (x !in 0.13..0.87) return@forEach

            // Ignora valores compactos e barras de progresso.
            if (
                t.contains("k", true) ||
                t.contains("m/", true) ||
                t.contains("/") ||
                t.contains("%") ||
                t.contains("anterior", true)
            ) return@forEach

            if (Regex("""(?i)\bx\s*\d+\b""").containsMatchIn(t)) return@forEach

            val n = parseLargeNumber(t) ?: return@forEach
            if (n !in 10_000L..100_000_000L) return@forEach

            val near = nearbyText(normalized, item, width, height).lowercase()
            if (
                near.contains("enviar") ||
                near.contains("saldo") ||
                near.contains("300k") ||
                near.contains("100k") ||
                near.contains(" id ") ||
                near.contains("jackpot")
            ) return@forEach

            val centerPenalty = abs(x - 0.5)
            var score = 1.2 - centerPenalty
            score += (hNorm * 18.0).coerceAtMost(1.8)
            if (jackpotBanner) score += 0.5
            if (near.contains("win") || near.contains("jackpot")) score += 0.6

            payoutCandidates += n to score
        }

        return payoutCandidates.maxByOrNull { it.second }?.first
    }

    private fun multiplierValue(s: String): Double? {
        val t = clean(s)

        Regex("""(?i)\b(?:win\s*)?x\s*(\d{1,4}(?:[.,]\d{1,2})?)\b""").find(t)?.let {
            return it.groupValues[1].replace(",", ".").toDoubleOrNull()
        }

        Regex("""(?i)\b(\d{1,4}(?:[.,]\d{1,2})?)\s*x\b""").find(t)?.let {
            return it.groupValues[1].replace(",", ".").toDoubleOrNull()
        }

        return null
    }

    private fun parseLargeNumber(s: String): Long? {
        val t = clean(s)

        Regex("""(?<!\d)(\d{1,3}(?:[.,\s]\d{3}){1,2})(?!\d)""").find(t)?.let {
            val raw = it.groupValues[1]
                .replace(".", "")
                .replace(",", "")
                .replace(" ", "")
            return raw.toLongOrNull()
        }

        Regex("""(?<!\d)(\d{5,8})(?!\d)""").find(t)?.let {
            return it.groupValues[1].toLongOrNull()
        }

        return null
    }

    private fun parseCompactNumber(s: String): Long? {
        val t = clean(s)

        Regex("""(?i)(\d+(?:[.,]\d+)?)\s*([km])\b""").find(t)?.let {
            val value = it.groupValues[1].replace(",", ".").toDoubleOrNull()
                ?: return@let
            val mult = when (it.groupValues[2].lowercase()) {
                "m" -> 1_000_000.0
                "k" -> 1_000.0
                else -> 1.0
            }
            return (value * mult).toLong()
        }

        return parseLargeNumber(t)
    }

    private fun nearbyText(
        all: List<OcrItem>,
        target: OcrItem,
        width: Int,
        height: Int
    ): String {
        val dx = (width * 0.24).toInt()
        val dy = (height * 0.050).toInt()

        val area = Rect(
            target.cx - dx,
            target.cy - dy,
            target.cx + dx,
            target.cy + dy
        )

        return all
            .filter { Rect.intersects(area, it.box) }
            .joinToString(" ") { it.text }
    }

    private fun clean(s: String): String =
        s.replace("\u00A0", " ")
            .replace("×", "x")
            .replace("✕", "x")
            .replace(Regex("""\s+"""), " ")
            .trim()
}
