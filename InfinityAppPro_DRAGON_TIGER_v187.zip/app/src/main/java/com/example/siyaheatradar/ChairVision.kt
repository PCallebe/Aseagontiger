package com.example.siyaheatradar

/** Leitura separada de POLTRONAS; não confunde com visitantes/pessoas. */
data class ChairReading(
    val total: Int?,
    val occupied: Int?,
    val userSeat: Int?,
    val confidence: String
)

class ChairVision {
    private var bestTotal: Int? = null
    private var stableCandidate: Int? = null
    private var stableHits = 0

    fun reset() {
        bestTotal = null
        stableCandidate = null
        stableHits = 0
    }

    fun detect(items: List<OcrItem>, width: Int, height: Int): ChairReading {
        if (items.isEmpty() || width <= 0 || height <= 0) return ChairReading(bestTotal, null, null, "BAIXA")

        // Números das poltronas ficam na grade central. Não usa simplesmente o maior número,
        // porque moedas, níveis e contadores podiam virar falsos 60/99.
        val seatNumbers = items.mapNotNull { item ->
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            val h = item.h.toDouble() / height
            if (x !in 0.02..0.96 || y !in 0.14..0.70 || h !in 0.006..0.032) return@mapNotNull null
            val raw = item.text.trim()
            if (!Regex("^\\d{1,2}$").matches(raw)) return@mapNotNull null
            val n = raw.toIntOrNull() ?: return@mapNotNull null
            n.takeIf { it in 1..48 }
        }.distinct().sorted()

        val candidate = detectGridTotal(seatNumbers)
        if (candidate != null) {
            if (stableCandidate == candidate) stableHits++ else {
                stableCandidate = candidate
                stableHits = 1
            }
            // Confirma depois de duas leituras, exceto quando a sequência é muito completa.
            if (stableHits >= 2 || seatNumbers.size >= 10) bestTotal = candidate
        }

        val all = items.joinToString(" ") { it.text }
        val userSeat = Regex("(?i)(?:minha\\s+poltrona|poltrona|assento)\\s*[#:]?\\s*(\\d{1,2})")
            .find(all)?.groupValues?.getOrNull(1)?.toIntOrNull()?.takeIf { it in 1..48 }

        // Sem visão de avatar confiável, não inventa ocupação. Se a árvore de acessibilidade
        // trouxer um texto explícito, usa; caso contrário retorna null.
        val occupied = Regex("(?i)(\\d{1,2})\\s*(?:ocupadas|ocupados|sentados|assentos ocupados)")
            .find(all)?.groupValues?.getOrNull(1)?.toIntOrNull()?.takeIf { n ->
                val total = bestTotal
                n >= 0 && (total == null || n <= total)
            }

        val confidence = when {
            bestTotal != null && seatNumbers.size >= 10 -> "ALTA"
            bestTotal != null && stableHits >= 2 -> "MÉDIA"
            candidate != null -> "PROVISÓRIA"
            else -> "BAIXA"
        }
        return ChairReading(bestTotal, occupied, userSeat, confidence)
    }

    private fun detectGridTotal(numbers: List<Int>): Int? {
        if (numbers.size < 5) return null

        // Sequência contínua a partir de 1 é a evidência mais forte.
        val set = numbers.toSet()
        var prefix = 0
        for (n in 1..48) {
            if (set.contains(n)) prefix = n else break
        }
        if (prefix >= 6) return prefix

        // Quando OCR perde alguns números, aceita apenas uma grade muito densa.
        val max = numbers.maxOrNull() ?: return null
        if (max < 6) return null
        val inRange = numbers.count { it in 1..max }
        val coverage = inRange.toDouble() / max
        val firstHalfCoverage = (1..minOf(max, 12)).count { set.contains(it) }.toDouble() / minOf(max, 12)
        return if (coverage >= 0.55 && firstHalfCoverage >= 0.55 && numbers.size >= 7) max else null
    }
}
