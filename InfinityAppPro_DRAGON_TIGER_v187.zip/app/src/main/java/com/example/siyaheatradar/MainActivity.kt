package com.example.siyaheatradar

import android.app.AlertDialog
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private var lastRoomBannerStamp = -1L

    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("radar", MODE_PRIVATE) }

    private lateinit var pages: List<View>
    private lateinit var navs: List<TextView>

    private lateinit var exactLiveView: ExactLiveView
    private lateinit var autoBadge: TextView
    private lateinit var authorizedBadge: TextView
    private lateinit var roomAvatar: ImageView
    private lateinit var roomText: TextView
    private lateinit var roomMetaText: TextView
    private lateinit var roomOnlineText: TextView
    private lateinit var snapshotBadge: TextView
    private lateinit var jackpotBadge: TextView
    private lateinit var statusText: TextView
    private lateinit var permissionButton: Button
    private lateinit var heatValue: TextView
    private lateinit var trendValue: TextView
    private lateinit var payoutValue: TextView
    private lateinit var multiplierValue: TextView
    private lateinit var snapshotText: TextView
    private lateinit var emojiSignalText: TextView
    private lateinit var giftSignalText: TextView
    private lateinit var rocketSignalText: TextView
    private lateinit var pkSignalText: TextView
    private lateinit var luckySignalText: TextView
    private lateinit var visitorsSignalText: TextView
    private lateinit var scrollSignalText: TextView

    private lateinit var strategySummaryText: TextView
    private lateinit var confidenceText: TextView
    private lateinit var suggestedGiftText: TextView
    private lateinit var suggestedGiftImage: ImageView
    private lateinit var useStrategyButton: TextView
    private lateinit var strategyHistoryButton: TextView
    private lateinit var trevoPerformanceText: TextView
    private lateinit var rosaPerformanceText: TextView
    private lateinit var ovoPerformanceText: TextView
    private lateinit var otherPerformanceText: TextView
    private lateinit var bestConfigText: TextView
    private lateinit var idealMomentText: TextView
    private lateinit var frequencyText: TextView
    private lateinit var confirmationText: TextView
    private lateinit var strategyTrackingText: TextView

    private lateinit var roomsPageText: TextView
    private lateinit var historyPageText: TextView
    private lateinit var giftHistoryPageText: TextView
    private lateinit var rankingPageText: TextView
    private lateinit var giftRankingPageText: TextView

    private lateinit var packagesText: TextView
    private lateinit var configStatusText: TextView
    private lateinit var snapshotGroup: RadioGroup

    private val ticker = object : Runnable {
        override fun run() {
            render()
            main.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        bindNavigation()
        bindStrategy()
        bindConfig()
        bindExactClone()

        permissionButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        if (!isServiceEnabled() && !prefs.getBoolean("asked_accessibility", false)) {
            prefs.edit().putBoolean("asked_accessibility", true).apply()
            main.postDelayed({
                try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Throwable) { }
            }, 450L)
        }

        showPage(0)
    }

    override fun onResume() {
        super.onResume()
        main.removeCallbacks(ticker)
        main.post(ticker)
    }

    override fun onPause() {
        main.removeCallbacks(ticker)
        super.onPause()
    }

    private fun bindViews() {
        exactLiveView = findViewById(R.id.exactLiveView)
        autoBadge = findViewById(R.id.autoBadge)
        authorizedBadge = findViewById(R.id.authorizedBadge)
        roomAvatar = findViewById(R.id.roomAvatar)
        roomText = findViewById(R.id.roomText)
        roomMetaText = findViewById(R.id.roomMetaText)
        roomOnlineText = findViewById(R.id.roomOnlineText)
        snapshotBadge = findViewById(R.id.snapshotBadge)
        jackpotBadge = findViewById(R.id.jackpotBadge)
        statusText = findViewById(R.id.statusText)
        permissionButton = findViewById(R.id.openAccessibility)
        heatValue = findViewById(R.id.heatValue)
        trendValue = findViewById(R.id.trendValue)
        payoutValue = findViewById(R.id.payoutValue)
        multiplierValue = findViewById(R.id.multiplierValue)
        snapshotText = findViewById(R.id.snapshotText)
        emojiSignalText = findViewById(R.id.emojiSignalText)
        giftSignalText = findViewById(R.id.giftSignalText)
        rocketSignalText = findViewById(R.id.rocketSignalText)
        pkSignalText = findViewById(R.id.pkSignalText)
        luckySignalText = findViewById(R.id.luckySignalText)
        visitorsSignalText = findViewById(R.id.visitorsSignalText)
        scrollSignalText = findViewById(R.id.scrollSignalText)

        strategySummaryText = findViewById(R.id.strategySummaryText)
        confidenceText = findViewById(R.id.confidenceText)
        suggestedGiftText = findViewById(R.id.suggestedGiftText)
        suggestedGiftImage = findViewById(R.id.suggestedGiftImage)
        useStrategyButton = findViewById(R.id.useStrategyButton)
        strategyHistoryButton = findViewById(R.id.strategyHistoryButton)
        trevoPerformanceText = findViewById(R.id.trevoPerformanceText)
        rosaPerformanceText = findViewById(R.id.rosaPerformanceText)
        ovoPerformanceText = findViewById(R.id.ovoPerformanceText)
        otherPerformanceText = findViewById(R.id.otherPerformanceText)
        bestConfigText = findViewById(R.id.bestConfigText)
        idealMomentText = findViewById(R.id.idealMomentText)
        frequencyText = findViewById(R.id.frequencyText)
        confirmationText = findViewById(R.id.confirmationText)
        strategyTrackingText = findViewById(R.id.strategyTrackingText)

        roomsPageText = findViewById(R.id.roomsPageText)
        historyPageText = findViewById(R.id.historyPageText)
        giftHistoryPageText = findViewById(R.id.giftHistoryPageText)
        rankingPageText = findViewById(R.id.rankingPageText)
        giftRankingPageText = findViewById(R.id.giftRankingPageText)

        packagesText = findViewById(R.id.packagesText)
        configStatusText = findViewById(R.id.configStatusText)
        snapshotGroup = findViewById(R.id.snapshotGroup)

        pages = listOf(
            findViewById<View>(R.id.pageLive),
            findViewById<ScrollView>(R.id.pageRooms),
            findViewById<ScrollView>(R.id.pageHistory),
            findViewById<ScrollView>(R.id.pageRanking),
            findViewById<ScrollView>(R.id.pageConfig)
        )
        navs = listOf(
            findViewById(R.id.navLive),
            findViewById(R.id.navRooms),
            findViewById(R.id.navHistory),
            findViewById(R.id.navRanking),
            findViewById(R.id.navConfig)
        )
    }

    private fun bindNavigation() {
        navs.forEachIndexed { index, view ->
            view.setOnClickListener { showPage(index) }
        }
        strategyHistoryButton.setOnClickListener { showPage(2) }
    }

    private fun showPage(index: Int) {
        pages.forEachIndexed { i, page -> page.visibility = if (i == index) View.VISIBLE else View.GONE }
        navs.forEachIndexed { i, nav ->
            nav.setTextColor(if (i == index) Color.rgb(214, 108, 255) else Color.rgb(170, 187, 216))
            nav.alpha = if (i == index) 1f else 0.84f
        }
        prefs.edit().putInt("ui_page", index).apply()
    }

    private fun bindExactClone() {
        exactLiveView.onUseStrategy = {
            useStrategyButton.performClick()
            exactLiveView.invalidate()
        }
        exactLiveView.onHistory = { showPage(2) }
        exactLiveView.onAuthorize = {
            if (!isServiceEnabled()) {
                try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Throwable) { }
            }
        }
        exactLiveView.onRoom = { showRoomDetail() }
        exactLiveView.onJackpot = { showJackpotDetail() }
        exactLiveView.onHeat = { showHeatDetail() }
        exactLiveView.onTrend = { showHeatDetail() }
        exactLiveView.onPayout = { showResultDetail("💰 PAGAMENTOS E RESULTADOS") }
        exactLiveView.onMultiplier = { showResultDetail("🏆 RESULTADOS / MAIOR X") }
        exactLiveView.onEmojis = { showEmojiDetail() }
        exactLiveView.onGifts = { showGiftActivityDetail() }
        exactLiveView.onRocket = { showRocketDetail() }
        exactLiveView.onPk = { showPkDetail() }
        exactLiveView.onLucky = { showLuckyDetail() }
        exactLiveView.onVisitors = { showPeopleDetail() }
        exactLiveView.onScroll = { showScrollDetail() }
        exactLiveView.onTrevo = { showAfortunadoDetail("TREVO") }
        exactLiveView.onRosa = { showAfortunadoDetail("ROSA") }
        exactLiveView.onOvo = { showAfortunadoDetail("OVO") }
        exactLiveView.onOthers = { showOtherAfortunados() }
    }

    private fun currentRoomKey(): String? {
        val room = prefs.getString("current_room", "Detectando sala...") ?: return null
        if (room.contains("Detectando", true)) return null
        return RoomHistoryStore.key(room, prefs.getString("current_room_id", null))
    }

    private fun showInfo(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("FECHAR", null)
            .show()
    }

    private fun showRoomDetail() {
        val room = prefs.getString("current_room", "Detectando sala...") ?: "Detectando sala..."
        val id = prefs.getString("current_room_id", null) ?: "—"
        val chairs = prefs.getInt("room_chairs_total", 0)
        val occupied = prefs.getInt("room_chairs_occupied", 0)
        val seat = prefs.getInt("room_user_seat", 0)
        val people = prefs.getInt("room_people_count", 0)
        showInfo("🏠 SALA ATUAL", buildString {
            append("$room\nID $id\n")
            append("🪑 Poltronas: ${if (chairs > 0) chairs else "não lidas"}")
            if (occupied > 0) append(" • ocupadas $occupied")
            if (seat > 0) append(" • você: $seat")
            append("\n👥 Pessoas/visitantes visíveis: ${if (people > 0) people else "—"}")
            append("\n\nA identificação é automática ao entrar/trocar de sala. Os primeiros ~5s usam leitura acelerada; depois volta ao ritmo normal.")
        })
    }

    private fun showJackpotDetail() {
        val value = prefs.getLong("global_jackpot_confirmed", prefs.getLong("jackpot_value", 0L))
        val seen = prefs.getLong("global_jackpot_seen_at", 0L)
        val db = EventDatabase(this)
        val history = try { db.jackpotHistory() } finally { db.close() }
        showInfo("👑 JACKPOT GLOBAL", buildString {
            append("Valor confirmado: ${if (value > 0) format(value) else "aguardando painel Afortunados/Lucky"}\n")
            if (seen > 0) append("Última leitura confirmada: ${(System.currentTimeMillis()-seen).coerceAtLeast(0L)/1000L}s atrás\n")
            append("\n$history")
        })
    }

    private fun showHeatDetail() {
        val heat = prefs.getInt("heat_score", 0)
        val state = prefs.getString("heat_state", "FRIA") ?: "FRIA"
        val trend = prefs.getString("trend", "ESTÁVEL") ?: "ESTÁVEL"
        showInfo("🔥 HEAT / TENDÊNCIA", "HEAT $heat/100 • $state\nTendência: $trend\n\n😀 Emojis ${prefs.getInt("room_emojis_1m",0)}/min\n🎁 Presentes ${prefs.getInt("room_gifts_1m",0)}/min\n📜 Rolagem ${prefs.getInt("room_scroll_1m",0)}/min\n🚀 ${prefs.getString("room_rocket_label","—")} • ${prefs.getString("room_rocket_trend","—")}\n⚔️ PK ${prefs.getString("room_pk_status","DESLIGADO")}")
    }

    private fun showResultDetail(title: String) {
        val key = currentRoomKey()
        if (key == null) { showInfo(title, "Entre em uma sala confirmada para ver os eventos."); return }
        val db = EventDatabase(this)
        val text = try { db.recentResults(key) } finally { db.close() }
        val last = prefs.getLong("last_confirmed_payout", 0L)
        val previous = prefs.getLong("previous_payout", 0L)
        showInfo(title, "Último pagamento CONFIRMADO: ${if (last>0) format(last) else "—"}\nAnterior do SIYA (referência, não pagamento novo): ${if (previous>0) format(previous) else "—"}\n\n$text")
    }

    private fun showEmojiDetail() {
        val count = prefs.getInt("room_emojis_1m", 0)
        val level = prefs.getString("room_emojis_level", "SEM SINAL") ?: "SEM SINAL"
        showInfo(
            "😀 EMOJIS / REAÇÕES",
            "Nível atual: $level\n" +
                "Eventos no último minuto: $count\n\n" +
                "Emojis entram como atividade da sala e ajudam o HEAT; não são tratados como pagamento."
        )
    }

    private fun showGiftActivityDetail() {
        val key = currentRoomKey()
        if (key == null) { showInfo("🎁 PRESENTES", "Sala ainda não confirmada."); return }
        val db = EventDatabase(this)
        val normal = try { db.normalGiftActivity(key) } finally { db.close() }
        showInfo("🎁 PRESENTES DA SALA", "Total último minuto: ${prefs.getInt("room_gifts_1m",0)}\nAfortunados: ${prefs.getInt("room_afortunados_1m",0)}\nNormais: ${prefs.getInt("room_normal_gifts_1m",0)}\n\nPRESENTES NORMAIS\n$normal")
    }

    private fun showRocketDetail() {
        val label = prefs.getString("room_rocket_label", "—") ?: "—"
        val progress = prefs.getInt("room_rocket_progress", -1)
        val trend = prefs.getString("room_rocket_trend", "AGUARDANDO VALOR") ?: "AGUARDANDO VALOR"
        showInfo("🚀 FOGUETE", "Valor da sala: $label\nPercentual: ${if(progress>=0) "$progress%" else "—"}\nTendência: $trend\n\nO foguete é tratado como sinal contínuo da sala; o app lê o valor atual/meta quando aparecem na tela.")
    }

    private fun showPkDetail() {
        val key = currentRoomKey()
        val status = prefs.getString("room_pk_status", "DESLIGADO") ?: "DESLIGADO"
        if (key == null) { showInfo("⚔️ PK", "Status: $status"); return }
        val db = EventDatabase(this)
        val hist = try { db.pkHistory(key) } finally { db.close() }
        showInfo("⚔️ PK", "Status atual: $status\n\n$hist")
    }

    private fun showLuckyDetail() {
        val fixedPulses = prefs.getInt("light_1m", 0)
        val highPulses = prefs.getInt("light_high_1m", 0)
        val ownHits = prefs.getInt("lucky_major_hits_1m", 0)
        val ownSum = prefs.getInt("lucky_major_sum_1m", 0)
        val ownMax = prefs.getInt("lucky_major_max_1m", 0)
        val ownTotal = prefs.getInt("lucky_session_total_x", 0)
        showInfo(
            "💡 LUCKY",
            "Luzes do painel: $fixedPulses pulso(s)/min • 200x+ $highPulses\n" +
                "Seus popups amarelos x50+: $ownHits/min\n" +
                "Soma no último minuto: x$ownSum • maior x$ownMax\n" +
                "Acumulado nesta sessão/sala: x$ownTotal\n\n" +
                "Os popups laterais x50+ são registrados separadamente; quando aparecem amarelos/dourados, entram no acumulador do seu Lucky."
        )
    }

    private fun showPeopleDetail() {
        showInfo("👥 PESSOAS / POLTRONAS", "Visitantes/pessoas visíveis: ${prefs.getInt("room_people_count",0).takeIf{it>0} ?: "—"}\nPoltronas totais: ${prefs.getInt("room_chairs_total",0).takeIf{it>0} ?: "—"}\nPoltronas ocupadas: ${prefs.getInt("room_chairs_occupied",0).takeIf{it>0} ?: "—"}\nSua poltrona: ${prefs.getInt("room_user_seat",0).takeIf{it>0} ?: "—"}")
    }

    private fun showScrollDetail() {
        showInfo("📜 ROLAGEM DA SALA", "Eventos de rolagem no último minuto: ${prefs.getInt("room_scroll_1m",0)}\nNível: ${prefs.getString("room_scroll_level","BAIXA")}\n\nRolagem e poltrona alimentam a MESMA sessão da sala; não existe estatística global fora de sala.")
    }

    private fun showAfortunadoDetail(gift: String) {
        val key = currentRoomKey()
        if (key == null) { showInfo("🎯 ${GiftCatalog.displayName(gift)}", "Sala ainda não confirmada."); return }
        val db = EventDatabase(this)
        val text = try { db.giftDetail(key, gift) } finally { db.close() }
        showInfo("🎯 AFORTUNADO", text)
    }

    private fun showOtherAfortunados() {
        val key = currentRoomKey()
        if (key == null) { showInfo("🎯 OUTROS AFORTUNADOS", "Sala ainda não confirmada."); return }
        val db = EventDatabase(this)
        val text = try { db.roomAfortunados(key) } finally { db.close() }
        showInfo("🎯 AFORTUNADOS NESTA SALA", text)
    }

    private fun bindStrategy() {
        useStrategyButton.setOnClickListener {
            val active = prefs.getBoolean("strategy_tracking", false)
            if (active) {
                prefs.edit()
                    .putBoolean("strategy_tracking", false)
                    .putLong("strategy_stopped_at", System.currentTimeMillis())
                    .apply()
                Toast.makeText(this, "Acompanhamento da estratégia encerrado.", Toast.LENGTH_SHORT).show()
            } else {
                val gift = prefs.getString("data_best_gift", null)
                    ?: prefs.getString("gift_recommendation", "TREVO")
                    ?: "TREVO"
                prefs.edit()
                    .putBoolean("strategy_tracking", true)
                    .putString("strategy_selected_gift", gift)
                    .putLong("strategy_started_at", System.currentTimeMillis())
                    .apply()
                Toast.makeText(this, "Estratégia observacional em acompanhamento: $gift", Toast.LENGTH_SHORT).show()
            }
            renderStrategy()
        }
    }

    private fun bindConfig() {
        bindSwitch(R.id.switchGlobal, "monitor_global", true)
        bindSwitch(R.id.switchEmojis, "monitor_emojis", true)
        bindSwitch(R.id.switchGifts, "monitor_gifts", true)
        bindSwitch(R.id.switchRocket, "monitor_rocket", true)
        bindSwitch(R.id.switchPk, "monitor_pk", true)
        bindSwitch(R.id.switchLucky, "monitor_lucky", true)
        bindSwitch(R.id.switchPeople, "monitor_people", true)
        bindSwitch(R.id.switchScroll, "monitor_scroll", true)

        val interval = prefs.getInt("snapshot_interval_sec", 60)
        when (interval) {
            30 -> snapshotGroup.check(R.id.snapshot30)
            90 -> snapshotGroup.check(R.id.snapshot90)
            120 -> snapshotGroup.check(R.id.snapshot120)
            else -> snapshotGroup.check(R.id.snapshot60)
        }
        snapshotGroup.setOnCheckedChangeListener { _, checkedId ->
            val sec = when (checkedId) {
                R.id.snapshot30 -> 30
                R.id.snapshot90 -> 90
                R.id.snapshot120 -> 120
                else -> 60
            }
            prefs.edit().putInt("snapshot_interval_sec", sec).apply()
            configStatusText.text = "Snapshot da sala ajustado para ${sec}s."
        }

        findViewById<Button>(R.id.addCurrentPackageButton).setOnClickListener {
            val pkg = prefs.getString("last_event_package", null)
                ?: prefs.getString("foreground_package", null)
            if (pkg.isNullOrBlank()) {
                configStatusText.text = "Ainda não há pacote recente para adicionar. Abra o SIYA/Siya Lite e tente novamente."
            } else {
                val set = customPackages().toMutableSet()
                set += pkg
                saveCustomPackages(set)
                configStatusText.text = "Pacote adicionado: $pkg"
                renderPackages()
            }
        }

        findViewById<Button>(R.id.testReadingButton).setOnClickListener {
            val last = prefs.getLong("last_read_at", 0L)
            val age = if (last > 0L) (System.currentTimeMillis() - last) / 1000L else -1L
            val fg = prefs.getString("foreground_package", "desconhecido")
            val hb = prefs.getString("heartbeat", "sem heartbeat")
            configStatusText.text = "Teste: serviço=${if (isServiceEnabled()) "ATIVO" else "DESLIGADO"} • último OCR=${if (age >= 0) "${age}s" else "—"} • app=$fg\n$hb"
        }

        findViewById<Button>(R.id.redetectButton).setOnClickListener {
            requestEngineReset("REDETECT")
            configStatusText.text = "Redetecção solicitada. O motor continua ligado e procurará SIYA/Siya Lite novamente."
        }

        findViewById<Button>(R.id.restartEngineButton).setOnClickListener {
            requestEngineReset("RESTART")
            configStatusText.text = "Motor lógico reiniciado sem desligar a Acessibilidade."
        }

        findViewById<Button>(R.id.clearHistoryButton).setOnClickListener {
            try {
                val db = EventDatabase(this)
                db.clearAll()
                db.close()
                RoomHistoryStore(this).clearAll()
                prefs.edit()
                    .remove("data_ranking")
                    .remove("data_windows")
                    .remove("data_config_history")
                    .remove("data_gift_performance")
                    .remove("data_best_gift")
                    .apply()
                configStatusText.text = "Histórico local apagado. A leitura automática continua ativa."
            } catch (e: Throwable) {
                configStatusText.text = "Não foi possível limpar agora: ${e.javaClass.simpleName}"
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun bindSwitch(id: Int, key: String, defaultValue: Boolean) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = prefs.getBoolean(key, defaultValue)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            configStatusText.text = "Configuração atualizada: $key = ${if (checked) "ON" else "OFF"}"
        }
    }

    private fun requestEngineReset(reason: String) {
        prefs.edit()
            .putLong("engine_reset_token", System.currentTimeMillis())
            .putString("engine_reset_reason", reason)
            .apply()
    }

    private fun customPackages(): Set<String> = prefs.getString("custom_siya_packages", "")
        .orEmpty()
        .split(',')
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .toSet()

    private fun saveCustomPackages(packages: Set<String>) {
        prefs.edit().putString("custom_siya_packages", packages.sorted().joinToString(",")).apply()
    }

    private fun render() {
        val enabled = isServiceEnabled()
        permissionButton.visibility = if (enabled) View.GONE else View.VISIBLE

        if (!enabled) {
            autoBadge.text = "● AUTOMÁTICO AGUARDANDO"
            authorizedBadge.text = "🔒 AUTORIZAÇÃO PENDENTE"
            autoBadge.setTextColor(Color.rgb(255, 194, 91))
            authorizedBadge.setTextColor(Color.rgb(255, 194, 91))
            statusText.text = "● Ative Acessibilidade"
            statusText.setTextColor(Color.rgb(255, 194, 91))
        } else {
            autoBadge.text = "● AUTOMÁTICO ATIVO"
            authorizedBadge.text = "🔒 AUTORIZADO"
            autoBadge.setTextColor(Color.rgb(70, 255, 154))
            authorizedBadge.setTextColor(Color.rgb(70, 255, 154))
        }

        val room = prefs.getString("current_room", "Detectando sala...") ?: "Detectando sala..."
        val roomId = prefs.getString("current_room_id", null)
        val context = prefs.getString("monitor_context", "SALA") ?: "SALA"
        val lastRead = prefs.getLong("last_read_at", 0L)
        val age = if (lastRead > 0L) ((System.currentTimeMillis() - lastRead) / 1000L).coerceAtLeast(0L) else -1L
        val heartbeat = prefs.getString("heartbeat", "aguardando SIYA") ?: "aguardando SIYA"

        val heat = prefs.getInt("heat_score", 0)
        val heatState = prefs.getString("heat_state", "INICIANDO") ?: "INICIANDO"
        val trend = prefs.getString("trend", "INICIANDO") ?: "INICIANDO"
        val payout = prefs.getLong("last_payout", 0L)
        val maxX = prefs.getFloat("max_multiplier_v14", 0f).toDouble()
        val jackpot = prefs.getLong("jackpot_value", 0L)
        val people = prefs.getInt("room_people_count", 0)
        val snapshotInterval = prefs.getInt("snapshot_interval_sec", 60)

        val seatStatus = prefs.getString("room_seat_status", "DETECTANDO") ?: "DETECTANDO"
        roomText.text = if (context.contains("ROLAGEM")) "📜 ROLAGEM / GLOBAL" else "🏠 SALA ATUAL • ${room.uppercase()}"
        roomMetaText.text = if (context.contains("ROLAGEM")) {
            "SIYA visível • fora de sala confirmada"
        } else {
            buildString {
                append(roomId?.let { "ID $it" } ?: "ID —")
                append(" • ")
                append("🛋️ $seatStatus")
                append(" • ${snapshotInterval}s")
            }
        }
        renderRoomBanner(context)
        roomOnlineText.text = if (people > 0) "● ● ●  +$people online" else "● ● ●  atividade online"
        snapshotBadge.text = "⟳ Atualização sala\n${snapshotInterval}s"
        jackpotBadge.text = if (jackpot > 0L) "👑 JACKPOT\n${format(jackpot)}" else "👑 JACKPOT GLOBAL"

        statusText.text = when {
            !enabled -> "● Acessibilidade desativada"
            age in 0..4 -> "● Radar ativo • analisando Siya..."
            else -> "● $heartbeat"
        }
        statusText.setTextColor(if (enabled && age in 0..4) Color.rgb(101, 255, 167) else Color.rgb(170, 190, 215))

        heatValue.text = "🔥 HEAT\n$heat/100\n$heatState"
        trendValue.text = "📈 TENDÊNCIA\n$trend"
        payoutValue.text = "💰 ÚLTIMO PAGAMENTO\n${if (payout > 0L) format(payout) else "—"}"
        multiplierValue.text = "🏆 MAIOR x\n${if (maxX > 0.0) "x${formatMultiplier(maxX)}" else "—"}"

        val snapshotAt = prefs.getLong("room_snapshot_at", 0L)
        val snapshotAge = if (snapshotAt > 0L) ((System.currentTimeMillis() - snapshotAt) / 1000L).coerceAtLeast(0L) else -1L
        snapshotText.text = if (snapshotAge >= 0) "SINAIS EM TEMPO REAL • snapshot ${snapshotAge}s ●" else "SINAIS EM TEMPO REAL ●"

        val emojiCount = prefs.getInt("room_emojis_1m", 0)
        val emojiLevel = prefs.getString("room_emojis_level", "SEM SINAL") ?: "SEM SINAL"
        val giftCount = prefs.getInt("room_gifts_1m", 0)
        val giftLevel = prefs.getString("room_gifts_level", "SEM SINAL") ?: "SEM SINAL"
        val rocket = prefs.getInt("room_rocket_progress", -1)
        val rocketTrend = prefs.getString("room_rocket_trend", "AGUARDANDO VALOR") ?: "AGUARDANDO VALOR"
        val rocketLabel = prefs.getString("room_rocket_label", "—") ?: "—"
        val rocketStage = prefs.getInt("room_rocket_stage", 1)
        val pk = prefs.getString("room_pk_status", "NÃO DETECTADO") ?: "NÃO DETECTADO"
        val lucky1m = prefs.getInt("light_1m", 0)
        val luckyHigh = prefs.getInt("light_high_1m", 0)
        val scrolls = prefs.getInt("room_scroll_1m", 0)
        val scrollLevel = prefs.getString("room_scroll_level", "BAIXA") ?: "BAIXA"

        emojiSignalText.text = "😀 Emojis\n$emojiLevel\n$emojiCount/1m"
        giftSignalText.text = "🎁 Presentes\n$giftLevel\n$giftCount/1m"
        rocketSignalText.text = "🚀 Foguete\n${if (rocket >= 0) "$rocket%" else "${rocketStage}º sinal"}\n$rocketTrend"
        pkSignalText.text = "⚔️ PK\n$pk"
        luckySignalText.text = "💡 Lucky\n$lucky1m/1m\n200x+ $luckyHigh"
        visitorsSignalText.text = "👥 Visitantes\n${if (people > 0) people else "—"}"
        scrollSignalText.text = "📜 Rolagem\n$scrollLevel\n$scrolls/1m"

        renderStrategy()
        renderSecondaryPages()
        renderPackages()
        exactLiveView.invalidate()
    }

    private fun renderRoomBanner(context: String) {
        if (context.contains("ROLAGEM")) {
            roomAvatar.setImageResource(R.drawable.infinity_launcher)
            return
        }
        val file = File(filesDir, "room_banner.jpg")
        val stamp = prefs.getLong("room_banner_updated_at", 0L)
        if (!file.exists() || stamp <= 0L) {
            roomAvatar.setImageResource(R.drawable.infinity_launcher)
            return
        }
        if (stamp == lastRoomBannerStamp) return
        try {
            val bmp = BitmapFactory.decodeFile(file.absolutePath)
            if (bmp != null) {
                roomAvatar.setImageBitmap(bmp)
                lastRoomBannerStamp = stamp
            }
        } catch (_: Throwable) {
            roomAvatar.setImageResource(R.drawable.infinity_launcher)
        }
    }

    private fun renderStrategy() {
        val room = prefs.getString("current_room", "Sala") ?: "Sala"
        val heat = prefs.getInt("heat_score", 0)
        val rocketTrend = prefs.getString("room_rocket_trend", "NÃO LIDO") ?: "NÃO LIDO"
        val pk = prefs.getString("room_pk_status", "NÃO DETECTADO") ?: "NÃO DETECTADO"
        val activity = prefs.getInt("room_activity_score", 0)

        val bestGift = prefs.getString("data_best_gift", "").orEmpty().trim()
        val hasBestGift = bestGift.isNotBlank()
        val bestGiftDisplay = if (hasBestGift) giftDisplay(bestGift) else "Coletando"
        val conf = prefs.getString("gift_confidence", "BAIXA • COLETANDO") ?: "BAIXA • COLETANDO"
        val maturity = prefs.getInt("data_maturity_confidence", 0)

        strategySummaryText.text = buildString {
            if (hasBestGift) append("Neste momento, o melhor desempenho observado é com o Afortunado $bestGiftDisplay. ")
            else append("Coletando resultados dos Afortunados desta sala. ")
            append("HEAT $heat/100")
            if (rocketTrend != "NÃO LIDO") append(" • foguete ${rocketTrend.lowercase()}")
            if (pk != "NÃO DETECTADO") append(" • PK ${pk.lowercase()}")
            append(". Acompanhamento baseado nas amostras reais desta sala.")
        }
        val confidenceLabel = conf.substringBefore('•').trim()
        val confidenceValue = if (maturity > 0) "$maturity%" else "COLETANDO"
        confidenceText.text = "CONFIANÇA\n$confidenceLabel\n$confidenceValue  ▂▄▆█"

        suggestedGiftText.text = if (hasBestGift) "$bestGiftDisplay\nMELHOR DESEMPENHO" else "Coletando\nAGUARDANDO DADOS"
        suggestedGiftImage.setImageResource(if (hasBestGift) giftImage(bestGift) else R.drawable.gift_outros_clean)

        val trevoScore = prefs.getInt("data_trevo_score", 0)
        val rosaScore = prefs.getInt("data_rosa_score", 0)
        val ovoScore = prefs.getInt("data_ovo_score", 0)
        val trevoSamples = prefs.getInt("data_trevo_samples", 0)
        val rosaSamples = prefs.getInt("data_rosa_samples", 0)
        val ovoSamples = prefs.getInt("data_ovo_samples", 0)
        val otherName = prefs.getString("data_other_best_name", "Outros") ?: "Outros"
        val otherScore = prefs.getInt("data_other_best_score", 0)
        val otherSamples = prefs.getInt("data_other_best_samples", 0)

        val total = (trevoScore + rosaScore + ovoScore + otherScore).coerceAtLeast(1)
        fun pct(score: Int, samples: Int): Int = if (samples <= 0) 0 else ((score * 100.0) / total).toInt().coerceIn(0, 100)

        trevoPerformanceText.text = "Trevo\n$trevoSamples eventos\n${pct(trevoScore, trevoSamples)}%"
        rosaPerformanceText.text = "Rosa\n$rosaSamples eventos\n${pct(rosaScore, rosaSamples)}%"
        ovoPerformanceText.text = "Ovo\n$ovoSamples eventos\n${pct(ovoScore, ovoSamples)}%"
        otherPerformanceText.text = "${otherName.take(12)}\n$otherSamples eventos\n${pct(otherScore, otherSamples)}%"

        val qty = prefs.getInt("strategy_gift_count", 0)
        val ppl = prefs.getInt("strategy_people_count", 0)
        bestConfigText.text = "👥 MELHOR CONFIGURAÇÃO\n${if (ppl > 0) "$ppl pessoas" else "pessoas: coletando"}\n${if (qty > 0) "quantidade x$qty" else "quantidade: coletando"}"
        idealMomentText.text = "⚡ MOMENTO OBSERVADO\nHEAT $heat/100\n${if (rocketTrend != "NÃO LIDO") "foguete $rocketTrend" else "foguete: coletando"}"
        frequencyText.text = "◷ FREQUÊNCIA\natividade $activity/100\njanela observada"
        confirmationText.text = "▥ CONFIRMAÇÃO\n${if (activity >= 55) "atividade alta" else "aguardar mais amostras"}"

        val tracking = prefs.getBoolean("strategy_tracking", false)
        val trackedGift = prefs.getString("strategy_selected_gift", bestGift) ?: bestGift
        if (tracking) {
            useStrategyButton.text = "ENCERRAR ACOMPANHAMENTO"
            strategyTrackingText.text = "● Estratégia em acompanhamento: ${giftDisplay(trackedGift)} • iniciada ${elapsed(prefs.getLong("strategy_started_at", 0L))}."
            strategyTrackingText.setTextColor(Color.rgb(88, 255, 174))
        } else {
            useStrategyButton.text = "USAR ESTRATÉGIA"
            strategyTrackingText.text = "Estratégia observacional • não executa presentes automaticamente."
            strategyTrackingText.setTextColor(Color.rgb(145, 166, 200))
        }
    }

    private fun renderSecondaryPages() {
        roomsPageText.text = prefs.getString("room_history_summary", "Nenhuma sala memorizada ainda.")
            ?: "Nenhuma sala memorizada ainda."

        historyPageText.text = buildString {
            append(prefs.getString("data_windows", "⏱️ JANELAS DE TEMPO\nColetando...") ?: "")
            append("\n\n")
            append(prefs.getString("data_global_bank", "🗄️ BANCO ESTATÍSTICO\nColetando...") ?: "")
            append("\n\n")
            append(prefs.getString("data_global_jackpot", "👑 JACKPOT GLOBAL\nColetando...") ?: "")
        }
        giftHistoryPageText.text = prefs.getString("data_config_history", "🎁 HISTÓRICO DE PRESENTES\nAinda sem amostras.")
            ?: "🎁 HISTÓRICO DE PRESENTES\nAinda sem amostras."

        rankingPageText.text = prefs.getString("data_ranking", "🏆 RANKING DAS SALAS\nAinda sem base suficiente.")
            ?: "🏆 RANKING DAS SALAS\nAinda sem base suficiente."
        giftRankingPageText.text = prefs.getString("data_gift_performance", "🎯 DESEMPENHO DOS AFORTUNADOS\nAinda sem base suficiente.")
            ?: "🎯 DESEMPENHO DOS AFORTUNADOS\nAinda sem base suficiente."
    }

    private fun renderPackages() {
        val active = prefs.getString("active_siya_package", "nenhum") ?: "nenhum"
        val last = prefs.getString("last_event_package", "nenhum") ?: "nenhum"
        val custom = customPackages().joinToString().ifBlank { "nenhum" }
        packagesText.text = "Automático: qualquer pacote cujo nome contenha ‘siya’ + com.zr.siya.\nAtivo agora: $active\nÚltimo evento: $last\nAdicionados manualmente: $custom"
    }

    private fun giftDisplay(raw: String): String = GiftCatalog.displayName(raw)

    private fun giftImage(raw: String): Int = when (raw.uppercase()) {
        "ROSA" -> R.drawable.gift_rosa_gold_clean
        "OVO" -> R.drawable.gift_ovo_gold_clean
        "TREVO" -> R.drawable.gift_trevo_gold_clean
        else -> R.drawable.gift_outros_clean
    }

    private fun elapsed(ts: Long): String {
        if (ts <= 0L) return "agora"
        val sec = ((System.currentTimeMillis() - ts) / 1000L).coerceAtLeast(0L)
        return when {
            sec < 60 -> "há ${sec}s"
            sec < 3600 -> "há ${sec / 60}min"
            else -> "há ${sec / 3600}h"
        }
    }

    private fun isServiceEnabled(): Boolean {
        val byManager = try {
            val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .any { info ->
                    val si = info.resolveInfo.serviceInfo
                    si.packageName == packageName &&
                        (si.name == SiyaAnalyzerService::class.java.name || si.name.endsWith(".SiyaAnalyzerService"))
                }
        } catch (_: Throwable) { false }
        if (byManager) return true

        return try {
            val expected = ComponentName(this, SiyaAnalyzerService::class.java)
            val raw = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            raw.split(':').any { item ->
                val c = ComponentName.unflattenFromString(item.trim())
                c != null && c.packageName == expected.packageName && c.className == expected.className
            }
        } catch (_: Throwable) { false }
    }

    private fun format(v: Long): String = when {
        v >= 1_000_000L -> String.format(java.util.Locale.US, "%.2fM", v / 1_000_000.0)
        v >= 1_000L -> String.format(java.util.Locale.US, "%.1fK", v / 1_000.0)
        else -> v.toString()
    }

    private fun formatMultiplier(v: Double): String {
        val r = kotlin.math.round(v * 10.0) / 10.0
        return if (kotlin.math.abs(r - r.toInt()) < 0.0001) r.toInt().toString()
        else String.format(java.util.Locale.US, "%.1f", r)
    }
}
