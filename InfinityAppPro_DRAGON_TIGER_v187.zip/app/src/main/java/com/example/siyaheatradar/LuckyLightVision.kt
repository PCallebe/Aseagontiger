package com.example.siyaheatradar

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.max

/**
 * Mede a intensidade visual ao redor dos seis multiplicadores fixos do LUCKY.
 * Não decide sozinho se houve pagamento: entrega um score normalizado ao RadarEngine,
 * que aprende o baseline da sala e registra apenas a transição apagado -> aceso.
 */
class LuckyLightVision {

    private val valid = setOf(20, 50, 200, 300, 500, 1000)

    fun measure(bitmap: Bitmap, items: List<OcrItem>): List<LuckyLightSample> {
        val candidates = items.mapNotNull { item ->
            val m = exactLuckyMultiplier(item.text) ?: return@mapNotNull null
            if (m !in valid) return@mapNotNull null

            // O painel LUCKY ocupa aproximadamente a metade inferior/central da tela
            // nas gravações. O filtro vertical evita confundir WIN x20 ou COMBO x20.
            val x = item.cx.toDouble() / bitmap.width
            val y = item.cy.toDouble() / bitmap.height
            if (y !in 0.28..0.70) return@mapNotNull null
            if (!matchesLuckySlot(m, x)) return@mapNotNull null

            val score = glowScore(bitmap, item.box)
            LuckyLightSample(
                multiplier = m,
                score = score,
                positionKey = "$m:${item.cx / 32}:${item.cy / 32}"
            )
        }

        // OCR pode devolver linha + elemento para o mesmo botão. Mantém o melhor score.
        return candidates
            .groupBy { it.multiplier }
            .mapNotNull { (_, values) -> values.maxByOrNull { it.score } }
            .sortedBy { it.multiplier }
    }


    private fun matchesLuckySlot(multiplier: Int, x: Double): Boolean = when (multiplier) {
        20 -> x in 0.02..0.16
        50 -> x in 0.12..0.30
        200 -> x in 0.25..0.43
        300 -> x in 0.52..0.70
        500 -> x in 0.64..0.84
        1000 -> x in 0.78..0.98
        else -> false
    }

    private fun exactLuckyMultiplier(raw: String): Int? {
        val t = raw
            .replace("×", "x")
            .replace("✕", "x")
            .trim()

        return Regex("""(?i)^x\s*(20|50|200|300|500|1000)$""")
            .find(t)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
    }

    private fun glowScore(bitmap: Bitmap, textBox: Rect): Double {
        val cx = textBox.centerX()
        val cy = textBox.centerY()
        val radiusX = max(textBox.width() * 2.3, bitmap.width * 0.055).toInt()
        val radiusY = max(textBox.height() * 2.4, bitmap.height * 0.035).toInt()

        val left = (cx - radiusX).coerceAtLeast(0)
        val right = (cx + radiusX).coerceAtMost(bitmap.width - 1)
        val top = (cy - radiusY).coerceAtLeast(0)
        val bottom = (cy + radiusY).coerceAtMost(bitmap.height - 1)

        var samples = 0
        var warmBright = 0.0
        var luminanceSum = 0.0
        val step = 3

        var y = top
        while (y <= bottom) {
            var x = left
            while (x <= right) {
                // Exclui o miolo do texto e valoriza o aro/lâmpadas ao redor.
                val nx = kotlin.math.abs(x - cx).toDouble() / radiusX.coerceAtLeast(1)
                val ny = kotlin.math.abs(y - cy).toDouble() / radiusY.coerceAtLeast(1)
                val radial = nx * nx + ny * ny
                if (radial in 0.16..1.10) {
                    val c = bitmap.getPixel(x, y)
                    val r = Color.red(c)
                    val g = Color.green(c)
                    val b = Color.blue(c)
                    val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
                    luminanceSum += lum

                    // Dourado/laranja: quando o painel acende há aumento simultâneo
                    // de luminância e componente quente.
                    if (r >= 135 && g >= 65 && r > b * 1.25 && r >= g) {
                        warmBright += ((r + g) / 510.0).coerceIn(0.0, 1.0)
                    }
                    samples++
                }
                x += step
            }
            y += step
        }

        if (samples == 0) return 0.0
        val warm = warmBright / samples
        val lum = luminanceSum / samples
        return (warm * 0.72 + lum * 0.28).coerceIn(0.0, 1.0)
    }
}
