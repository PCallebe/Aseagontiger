package com.example.siyaheatradar

import android.content.Context
import kotlin.math.abs
import kotlin.math.max

/**
 * Contador GLOBAL do JACKPOT. Confirma o valor em duas leituras para evitar OCR falso.
 * Enquanto Afortunados/Lucky estiver aberto, atualiza continuamente o valor confirmado.
 */
data class JackpotReading(
    val panelVisible: Boolean,
    val confirmedValue: Long?,
    val newlyConfirmed: Boolean
)

class JackpotVision(context: Context) {
    private val prefs = context.getSharedPreferences("radar", Context.MODE_PRIVATE)
    private var pending: Long? = null
    private var pendingHits = 0
    private var pendingAt = 0L
    private var confirmed: Long = prefs.getLong("global_jackpot_confirmed", 0L)

    fun resetTransient() {
        pending = null
        pendingHits = 0
        pendingAt = 0L
    }

    fun detect(items: List<OcrItem>, width: Int, height: Int, now: Long): JackpotReading {
        if (items.isEmpty() || width <= 0 || height <= 0) {
            return JackpotReading(false, confirmed.takeIf { it > 0L }, false)
        }

        val all = GiftCatalog.normalizeText(items.joinToString(" ") { it.text })
        val jackpotLabels = items.filter { GiftCatalog.normalizeText(it.text).contains("jackpot") }
        val afortunados = all.contains("afortunados")
        val lucky = all.contains("lucky")
        val fixedLucky = items.count {
            Regex("(?i)^\\s*x\\s*(20|50|200|300|500|1000)\\s*$").matches(it.text.trim())
        }
        val panelVisible = jackpotLabels.isNotEmpty() || (afortunados && (lucky || fixedLucky >= 2)) || (lucky && fixedLucky >= 3)

        if (!panelVisible) return JackpotReading(false, confirmed.takeIf { it > 0L }, false)

        data class Candidate(val value: Long, val score: Double)
        val candidates = mutableListOf<Candidate>()
        for (item in items) {
            val value = parseValue(item.text) ?: continue
            if (value !in 100_000L..10_000_000L) continue
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            val near = nearbyText(items, item, width, height)
            val nearLow = GiftCatalog.normalizeText(near)

            // Rejeita foguete/Anterior/saldos e IDs.
            if (nearLow.contains("anterior") || nearLow.contains("rocket") || nearLow.contains("foguete") ||
                nearLow.contains("saldo") || nearLow.contains("id ") || nearLow.contains("recarregar") ||
                item.text.contains("/")) continue

            var score = 0.0
            jackpotLabels.forEach { label ->
                val dx = abs(item.cx - label.cx).toDouble() / width
                val dy = abs(item.cy - label.cy).toDouble() / height
                if (dx <= 0.34 && dy <= 0.15) score = max(score, 4.0 - dx * 3.0 - dy * 8.0)
            }
            // Fallback da tela Afortunados/Lucky: contador costuma ficar do meio para direita.
            if (x >= 0.55 && y in 0.20..0.70) score += 1.1
            if (nearLow.contains("jackpot")) score += 2.5
            score += (item.h.toDouble() / height * 16.0).coerceAtMost(1.2)
            if (score > 0.7) candidates += Candidate(value, score)
        }

        val candidate = candidates.maxByOrNull { it.score }?.value
            ?: return JackpotReading(true, confirmed.takeIf { it > 0L }, false)

        val samePending = pending?.let { old ->
            abs(old - candidate) <= max(5_000L, (old * 0.012).toLong())
        } == true && now - pendingAt <= 4_000L

        if (samePending) {
            // O contador continua subindo enquanto as pessoas jogam.
            // Mantém sempre o valor MAIS NOVO, em vez de confirmar o valor da captura anterior.
            pending = candidate
            pendingHits++
            pendingAt = now
        } else {
            pending = candidate
            pendingHits = 1
            pendingAt = now
        }

        var newly = false
        if (pendingHits >= 2) {
            val value = pending ?: candidate
            val changed = confirmed <= 0L || abs(confirmed - value) >= 1_000L
            confirmed = value
            prefs.edit()
                .putLong("global_jackpot_confirmed", confirmed)
                .putLong("global_jackpot_seen_at", now)
                .apply()
            newly = changed
            pendingHits = 0
            pending = null
        }

        return JackpotReading(true, confirmed.takeIf { it > 0L }, newly)
    }

    private fun parseValue(raw: String): Long? {
        val text = raw.replace(',', '.').trim()
        Regex("(?i)(\\d+(?:\\.\\d+)?)\\s*([KM])\\b").find(text)?.let { m ->
            val n = m.groupValues[1].toDoubleOrNull() ?: return@let
            val mult = if (m.groupValues[2].equals("M", true)) 1_000_000.0 else 1_000.0
            return (n * mult).toLong()
        }
        Regex("(?<!\\d)(\\d{1,3}(?:[.\\s]\\d{3}){1,2}|\\d{5,8})(?!\\d)").find(text)?.let { m ->
            return m.groupValues[1].replace(".", "").replace(" ", "").toLongOrNull()
        }
        return null
    }

    private fun nearbyText(items: List<OcrItem>, target: OcrItem, width: Int, height: Int): String {
        val maxDx = width * 0.30
        val maxDy = height * 0.10
        return items.asSequence()
            .filter { it !== target }
            .filter { abs(it.cx - target.cx) <= maxDx && abs(it.cy - target.cy) <= maxDy }
            .take(12)
            .joinToString(" ") { it.text }
    }
}
