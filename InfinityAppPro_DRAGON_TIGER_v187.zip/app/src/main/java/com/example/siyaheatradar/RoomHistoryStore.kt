package com.example.siyaheatradar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

class RoomHistoryStore(context: Context) {

    private val prefs = context.getSharedPreferences("room_history_v10", Context.MODE_PRIVATE)
    private val lastWinSignature = mutableMapOf<String, Pair<String, Long>>()

    fun onRoomEntered(
        roomName: String,
        roomId: String?,
        now: Long = System.currentTimeMillis()
    ) {
        val map = loadAll()
        val k = key(roomName, roomId)
        val old = map[k]

        map[k] = if (old == null) {
            RoomStats(
                name = roomName,
                roomId = roomId.orEmpty(),
                firstSeen = now,
                lastSeen = now,
                visits = 1
            )
        } else {
            old.copy(
                name = roomName,
                roomId = roomId ?: old.roomId,
                lastSeen = now,
                visits = old.visits + 1
            )
        }

        saveAll(map)
    }

    fun record(
        roomName: String,
        roomId: String?,
        read: ScreenRead,
        state: RadarState,
        now: Long = System.currentTimeMillis()
    ): RoomStats {
        val map = loadAll()
        val k = key(roomName, roomId)

        var stats = map[k] ?: RoomStats(
            name = roomName,
            roomId = roomId.orEmpty(),
            firstSeen = now,
            lastSeen = now,
            visits = 1
        )

        stats = stats.copy(
            name = roomName,
            roomId = roomId ?: stats.roomId,
            lastSeen = now,
            captures = stats.captures + 1,
            lastHeatScore = state.heatScore,
            maxHeatScore = maxOf(stats.maxHeatScore, state.heatScore),
            lastGift = read.selectedGift ?: stats.lastGift
        )

        // Payout central/animação: cooldown curto porque a animação desaparece.
        read.payout?.let { payout ->
            val isNew =
                payout != stats.lastPayout ||
                now - stats.lastPayoutAt >= 20_000L

            if (isNew) {
                stats = stats.copy(
                    totalPayout = stats.totalPayout + payout,
                    payoutCount = stats.payoutCount + 1,
                    lastPayout = payout,
                    lastPayoutAt = now
                )
            }
        }

        // "Anterior" é apenas referência exibida pelo SIYA.
        // NUNCA entra em total pago nem vira último pagamento novo.
        read.previousPayout?.let { payout ->
            if (payout > 0 && payout != stats.lastPreviousPayout) {
                stats = stats.copy(lastPreviousPayout = payout)
            }
        }

        if (read.wins.isNotEmpty()) {
            val signature = read.wins
                .sortedWith(compareBy<WinHit> { it.positionKey }.thenBy { it.multiplier })
                .joinToString("|") { "${it.multiplier}@${it.positionKey}" }

            val previous = lastWinSignature[k]
            val isNew = previous == null ||
                previous.first != signature ||
                now - previous.second >= 9_000L

            if (isNew) {
                lastWinSignature[k] = signature to now

                fun count(min: Double, max: Double): Long =
                    read.wins.count { it.multiplier >= min && it.multiplier <= max }.toLong()
                stats = stats.copy(
                    totalWins = stats.totalWins + read.wins.size,
                    maxMultiplier = maxOf(stats.maxMultiplier, read.maxMultiplier ?: 0.0),
                    wins2to4 = stats.wins2to4 + count(2.0, 4.999),
                    wins5to9 = stats.wins5to9 + count(5.0, 9.999),
                    wins10to24 = stats.wins10to24 + count(10.0, 24.999),
                    wins25to49 = stats.wins25to49 + count(25.0, 49.999),
                    wins50to99 = stats.wins50to99 + count(50.0, 99.999),
                    wins100to249 = stats.wins100to249 + count(100.0, 249.999),
                    wins250to499 = stats.wins250to499 + count(250.0, 499.999),
                    wins500to1000 = stats.wins500to1000 + count(500.0, 1000.0)
                )
            }
        }

        // JACKPOT é GLOBAL do SIYA e não é atribuído a esta sala.

        if (state.newLightPulses.isNotEmpty()) {
            fun pulseCount(m: Int): Long = state.newLightPulses.count { it == m }.toLong()
            stats = stats.copy(
                luckyLightPulses = stats.luckyLightPulses + state.newLightPulses.size,
                lightX20 = stats.lightX20 + pulseCount(20),
                lightX50 = stats.lightX50 + pulseCount(50),
                lightX200 = stats.lightX200 + pulseCount(200),
                lightX300 = stats.lightX300 + pulseCount(300),
                lightX500 = stats.lightX500 + pulseCount(500),
                lightX1000 = stats.lightX1000 + pulseCount(1000)
            )
        }


        if (state.newGiftResults.isNotEmpty()) {
            state.newGiftResults.forEach { result ->
                val x10 = kotlin.math.round(result.multiplier * 10.0).toLong()
                when (result.gift) {
                    "TREVO" -> stats = stats.copy(
                        giftTrevoSamples = stats.giftTrevoSamples + 1,
                        giftTrevoSumX10 = stats.giftTrevoSumX10 + x10,
                        giftTrevoLow = stats.giftTrevoLow + if (result.multiplier <= 5.999) 1 else 0,
                        giftTrevo50Plus = stats.giftTrevo50Plus + if (result.multiplier >= 50.0) 1 else 0,
                        giftTrevo200Plus = stats.giftTrevo200Plus + if (result.multiplier >= 200.0) 1 else 0,
                        giftTrevoMaxX10 = maxOf(stats.giftTrevoMaxX10, x10)
                    )
                    "ROSA" -> stats = stats.copy(
                        giftRosaSamples = stats.giftRosaSamples + 1,
                        giftRosaSumX10 = stats.giftRosaSumX10 + x10,
                        giftRosaLow = stats.giftRosaLow + if (result.multiplier <= 5.999) 1 else 0,
                        giftRosa50Plus = stats.giftRosa50Plus + if (result.multiplier >= 50.0) 1 else 0,
                        giftRosa200Plus = stats.giftRosa200Plus + if (result.multiplier >= 200.0) 1 else 0,
                        giftRosaMaxX10 = maxOf(stats.giftRosaMaxX10, x10)
                    )
                    "OVO" -> stats = stats.copy(
                        giftOvoSamples = stats.giftOvoSamples + 1,
                        giftOvoSumX10 = stats.giftOvoSumX10 + x10,
                        giftOvoLow = stats.giftOvoLow + if (result.multiplier <= 5.999) 1 else 0,
                        giftOvo50Plus = stats.giftOvo50Plus + if (result.multiplier >= 50.0) 1 else 0,
                        giftOvo200Plus = stats.giftOvo200Plus + if (result.multiplier >= 200.0) 1 else 0,
                        giftOvoMaxX10 = maxOf(stats.giftOvoMaxX10, x10)
                    )
                }
            }
        }

        map[k] = stats
        saveAll(map)
        return stats
    }

    fun get(roomName: String, roomId: String?): RoomStats? =
        loadAll()[key(roomName, roomId)]

    fun clearAll() {
        prefs.edit().clear().apply()
        lastWinSignature.clear()
    }

    fun recent(limit: Int = 10): List<RoomStats> =
        loadAll().values
            .sortedByDescending { it.lastSeen }
            .take(limit)

    fun summary(limit: Int = 8): String {
        val rooms = recent(limit)

        if (rooms.isEmpty()) return "Nenhuma sala memorizada ainda."

        return rooms.joinToString("\n\n") { r ->
            val avg = format(r.averagePayout)
            val total = format(r.totalPayout)
            val maxX = if (r.maxMultiplier > 0) "x${formatMultiplier(r.maxMultiplier)}" else "—"
            val id = if (r.roomId.isNotBlank()) " • ID ${r.roomId}" else ""

            val bands = listOf(
                "2–4x" to r.wins2to4, "5–9x" to r.wins5to9, "10–24x" to r.wins10to24,
                "25–49x" to r.wins25to49, "50–99x" to r.wins50to99, "100–249x" to r.wins100to249,
                "250–499x" to r.wins250to499, "500–1000x" to r.wins500to1000
            ).filter { it.second > 0 }.joinToString(" • ") { "${it.first} ${it.second}" }

            val lights = listOf(
                "20x" to r.lightX20, "50x" to r.lightX50, "200x" to r.lightX200,
                "300x" to r.lightX300, "500x" to r.lightX500, "1000x" to r.lightX1000
            ).filter { it.second > 0 }.joinToString(" • ") { "${it.first} ${it.second}" }

            buildString {
                append("🏠 ${r.name}$id\n")
                append("👁️ visitas ${r.visits} • leituras ${r.captures}\n")
                append("💰 pagamentos ${r.payoutCount} • volume $total • média $avg\n")
                append("🏆 resultados ${r.totalWins} • maior $maxX • atividade máx ${r.maxHeatScore}/100")
                if (bands.isNotBlank()) append("\n🎁 $bands")
                if (r.luckyLightPulses > 0) {
                    append("\n💡 LUCKY ${r.luckyLightPulses} acendimentos")
                    if (lights.isNotBlank()) append(" • $lights")
                }
                val giftTotal = r.giftTrevoSamples + r.giftRosaSamples + r.giftOvoSamples
                if (giftTotal > 0) {
                    fun giftLine(label: String, n: Long, sum: Long, low: Long, h50: Long, h200: Long): String {
                        if (n == 0L) return "$label 0"
                        val avg = (sum / 10.0) / n
                        return "$label $n • média x${String.format(Locale.US, "%.1f", avg)} • baixos $low • 50x+ $h50 • 200x+ $h200"
                    }
                    append("\n🎁 Gift Engine: ")
                    append(giftLine("🍀", r.giftTrevoSamples, r.giftTrevoSumX10, r.giftTrevoLow, r.giftTrevo50Plus, r.giftTrevo200Plus))
                    append("\n   ")
                    append(giftLine("🌹", r.giftRosaSamples, r.giftRosaSumX10, r.giftRosaLow, r.giftRosa50Plus, r.giftRosa200Plus))
                    append("\n   ")
                    append(giftLine("🥚", r.giftOvoSamples, r.giftOvoSumX10, r.giftOvoLow, r.giftOvo50Plus, r.giftOvo200Plus))
                }
            }
        }
    }

    private fun loadAll(): MutableMap<String, RoomStats> {
        val raw = prefs.getString("rooms", null) ?: return mutableMapOf()

        return try {
            val arr = JSONArray(raw)
            val map = mutableMapOf<String, RoomStats>()

            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val r = RoomStats(
                    name = o.optString("name", "Sala"),
                    roomId = o.optString("roomId", ""),
                    firstSeen = o.optLong("firstSeen", 0L),
                    lastSeen = o.optLong("lastSeen", 0L),
                    visits = o.optInt("visits", 0),
                    captures = o.optLong("captures", 0L),
                    totalWins = o.optLong("totalWins", 0L),
                    totalPayout = o.optLong("totalPayout", 0L),
                    payoutCount = o.optLong("payoutCount", 0L),
                    maxMultiplier = o.optDouble("maxMultiplier", 0.0),
                    jackpotEvents = o.optLong("jackpotEvents", 0L),
                    lastPayout = o.optLong("lastPayout", 0L),
                    lastHeatScore = o.optInt("lastHeatScore", 0),
                    maxHeatScore = o.optInt("maxHeatScore", 0),
                    lastPayoutAt = o.optLong("lastPayoutAt", 0L),
                    lastPreviousPayout = o.optLong("lastPreviousPayout", 0L),
                    wins2to4 = o.optLong("wins2to4", 0L),
                    wins5to9 = o.optLong("wins5to9", 0L),
                    wins10to24 = o.optLong("wins10to24", 0L),
                    wins25to49 = o.optLong("wins25to49", 0L),
                    wins50to99 = o.optLong("wins50to99", 0L),
                    wins100to249 = o.optLong("wins100to249", 0L),
                    wins250to499 = o.optLong("wins250to499", 0L),
                    wins500to1000 = o.optLong("wins500to1000", 0L),
                    jackpotSamples = o.optLong("jackpotSamples", 0L),
                    lastJackpotValue = o.optLong("lastJackpotValue", 0L),
                    maxJackpotValue = o.optLong("maxJackpotValue", 0L),
                    jackpotHitCount = o.optLong("jackpotHitCount", 0L),
                    jackpotHitValueSum = o.optLong("jackpotHitValueSum", 0L),
                    lastJackpotHitValue = o.optLong("lastJackpotHitValue", 0L),
                    lastJackpotHitAt = o.optLong("lastJackpotHitAt", 0L),
                    minJackpotHitValue = o.optLong("minJackpotHitValue", 0L),
                    maxJackpotHitValue = o.optLong("maxJackpotHitValue", 0L),
                    preHitLight1mSum = o.optLong("preHitLight1mSum", 0L),
                    preHitHighLight1mSum = o.optLong("preHitHighLight1mSum", 0L),
                    preHitWins1mSum = o.optLong("preHitWins1mSum", 0L),
                    ref1Hits = o.optLong("ref1Hits", 0L),
                    ref2Hits = o.optLong("ref2Hits", 0L),
                    luckyLightPulses = o.optLong("luckyLightPulses", 0L),
                    lightX20 = o.optLong("lightX20", 0L),
                    lightX50 = o.optLong("lightX50", 0L),
                    lightX200 = o.optLong("lightX200", 0L),
                    lightX300 = o.optLong("lightX300", 0L),
                    lightX500 = o.optLong("lightX500", 0L),
                    lightX1000 = o.optLong("lightX1000", 0L),
                    lastGift = o.optString("lastGift", ""),
                    giftTrevoSamples = o.optLong("giftTrevoSamples", 0L),
                    giftTrevoSumX10 = o.optLong("giftTrevoSumX10", 0L),
                    giftTrevoLow = o.optLong("giftTrevoLow", 0L),
                    giftTrevo50Plus = o.optLong("giftTrevo50Plus", 0L),
                    giftTrevo200Plus = o.optLong("giftTrevo200Plus", 0L),
                    giftTrevoMaxX10 = o.optLong("giftTrevoMaxX10", 0L),
                    giftRosaSamples = o.optLong("giftRosaSamples", 0L),
                    giftRosaSumX10 = o.optLong("giftRosaSumX10", 0L),
                    giftRosaLow = o.optLong("giftRosaLow", 0L),
                    giftRosa50Plus = o.optLong("giftRosa50Plus", 0L),
                    giftRosa200Plus = o.optLong("giftRosa200Plus", 0L),
                    giftRosaMaxX10 = o.optLong("giftRosaMaxX10", 0L),
                    giftOvoSamples = o.optLong("giftOvoSamples", 0L),
                    giftOvoSumX10 = o.optLong("giftOvoSumX10", 0L),
                    giftOvoLow = o.optLong("giftOvoLow", 0L),
                    giftOvo50Plus = o.optLong("giftOvo50Plus", 0L),
                    giftOvo200Plus = o.optLong("giftOvo200Plus", 0L),
                    giftOvoMaxX10 = o.optLong("giftOvoMaxX10", 0L)
                )
                map[key(r.name, r.roomId.ifBlank { null })] = r
            }

            map
        } catch (_: Throwable) {
            mutableMapOf()
        }
    }

    private fun saveAll(map: Map<String, RoomStats>) {
        val arr = JSONArray()

        map.values.forEach { r ->
            arr.put(
                JSONObject()
                    .put("name", r.name)
                    .put("roomId", r.roomId)
                    .put("firstSeen", r.firstSeen)
                    .put("lastSeen", r.lastSeen)
                    .put("visits", r.visits)
                    .put("captures", r.captures)
                    .put("totalWins", r.totalWins)
                    .put("totalPayout", r.totalPayout)
                    .put("payoutCount", r.payoutCount)
                    .put("maxMultiplier", r.maxMultiplier)
                    .put("jackpotEvents", r.jackpotEvents)
                    .put("lastPayout", r.lastPayout)
                    .put("lastHeatScore", r.lastHeatScore)
                    .put("maxHeatScore", r.maxHeatScore)
                    .put("lastPayoutAt", r.lastPayoutAt)
                    .put("lastPreviousPayout", r.lastPreviousPayout)
                    .put("wins2to4", r.wins2to4)
                    .put("wins5to9", r.wins5to9)
                    .put("wins10to24", r.wins10to24)
                    .put("wins25to49", r.wins25to49)
                    .put("wins50to99", r.wins50to99)
                    .put("wins100to249", r.wins100to249)
                    .put("wins250to499", r.wins250to499)
                    .put("wins500to1000", r.wins500to1000)
                    .put("jackpotSamples", r.jackpotSamples)
                    .put("lastJackpotValue", r.lastJackpotValue)
                    .put("maxJackpotValue", r.maxJackpotValue)
                    .put("jackpotHitCount", r.jackpotHitCount)
                    .put("jackpotHitValueSum", r.jackpotHitValueSum)
                    .put("lastJackpotHitValue", r.lastJackpotHitValue)
                    .put("lastJackpotHitAt", r.lastJackpotHitAt)
                    .put("minJackpotHitValue", r.minJackpotHitValue)
                    .put("maxJackpotHitValue", r.maxJackpotHitValue)
                    .put("preHitLight1mSum", r.preHitLight1mSum)
                    .put("preHitHighLight1mSum", r.preHitHighLight1mSum)
                    .put("preHitWins1mSum", r.preHitWins1mSum)
                    .put("ref1Hits", r.ref1Hits)
                    .put("ref2Hits", r.ref2Hits)
                    .put("luckyLightPulses", r.luckyLightPulses)
                    .put("lightX20", r.lightX20)
                    .put("lightX50", r.lightX50)
                    .put("lightX200", r.lightX200)
                    .put("lightX300", r.lightX300)
                    .put("lightX500", r.lightX500)
                    .put("lightX1000", r.lightX1000)
                    .put("lastGift", r.lastGift)
                    .put("giftTrevoSamples", r.giftTrevoSamples)
                    .put("giftTrevoSumX10", r.giftTrevoSumX10)
                    .put("giftTrevoLow", r.giftTrevoLow)
                    .put("giftTrevo50Plus", r.giftTrevo50Plus)
                    .put("giftTrevo200Plus", r.giftTrevo200Plus)
                    .put("giftTrevoMaxX10", r.giftTrevoMaxX10)
                    .put("giftRosaSamples", r.giftRosaSamples)
                    .put("giftRosaSumX10", r.giftRosaSumX10)
                    .put("giftRosaLow", r.giftRosaLow)
                    .put("giftRosa50Plus", r.giftRosa50Plus)
                    .put("giftRosa200Plus", r.giftRosa200Plus)
                    .put("giftRosaMaxX10", r.giftRosaMaxX10)
                    .put("giftOvoSamples", r.giftOvoSamples)
                    .put("giftOvoSumX10", r.giftOvoSumX10)
                    .put("giftOvoLow", r.giftOvoLow)
                    .put("giftOvo50Plus", r.giftOvo50Plus)
                    .put("giftOvo200Plus", r.giftOvo200Plus)
                    .put("giftOvoMaxX10", r.giftOvoMaxX10)
            )
        }

        prefs.edit().putString("rooms", arr.toString()).apply()
    }

    companion object {
        fun key(name: String, roomId: String?): String {
            if (!roomId.isNullOrBlank()) return "id:${roomId.trim()}"

            val normalized = Normalizer.normalize(name, Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
                .lowercase(Locale.ROOT)
                .replace(Regex("[^a-z0-9]+"), " ")
                .trim()

            return "name:" + normalized.ifBlank { "sala" }
        }

        fun formatMultiplier(v: Double): String {
            val rounded = kotlin.math.round(v * 10.0) / 10.0
            return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.0001) rounded.toInt().toString()
            else String.format(Locale.US, "%.1f", rounded)
        }

        fun format(v: Long): String = when {
            v >= 1_000_000L -> String.format(Locale.US, "%.2fM", v / 1_000_000.0)
            v >= 1_000L -> String.format(Locale.US, "%.1fK", v / 1_000.0)
            else -> v.toString()
        }
    }
}
