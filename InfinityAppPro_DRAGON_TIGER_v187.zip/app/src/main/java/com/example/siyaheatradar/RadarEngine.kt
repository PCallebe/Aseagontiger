package com.example.siyaheatradar

import java.util.ArrayDeque
import kotlin.math.max
import kotlin.math.roundToInt

class RadarEngine {

    private data class Event(
        val ts: Long,
        val type: String,
        val value: Long = 0,
        val multiplier: Double = 0.0,
        val signature: String = "",
        val gift: String? = null
    )

    private data class GiftAgg(
        val samples: Long,
        val sumX10: Long,
        val low: Long,
        val plus50: Long,
        val plus200: Long,
        val maxX10: Long
    )

    private val events = ArrayDeque<Event>()
    private val signatures = LinkedHashMap<String, Long>()

    private var previousScore = -1
    private var jackpotWasVisible = false
    private var jackpotLastSeenAt = 0L
    private var sessionStartedAt = 0L

    private val lightBaseline = mutableMapOf<Int, Double>()
    private val lightActive = mutableMapOf<Int, Boolean>()
    private val lastLightPulseAt = mutableMapOf<Int, Long>()

    private var lastJackpotValue: Long? = null
    private var pendingJackpotDropFrom: Long? = null
    private var pendingJackpotDropAt = 0L
    private var lastJackpotHitAt = 0L

    private var currentGift: String? = null
    private var currentGiftSeenAt = 0L

    fun restoreGift(gift: String?) {
        val normalized = gift?.trim()?.uppercase()?.takeIf { it.isNotBlank() }
        if (normalized != null && currentGift == null) currentGift = normalized
    }

    fun ingest(
        read: ScreenRead,
        history: RoomStats? = null,
        now: Long = System.currentTimeMillis()
    ): RadarState {
        if (sessionStartedAt == 0L) sessionStartedAt = now

        read.selectedGift?.trim()?.uppercase()?.takeIf { it.isNotBlank() }?.let {
            currentGift = it
            currentGiftSeenAt = now
        }

        if (read.jackpotBanner) {
            jackpotLastSeenAt = now
            if (!jackpotWasVisible) {
                addOnce(now, "jackpot", signature = "jackpot-enter", cooldown = 20_000)
            }
            jackpotWasVisible = true
        } else if (now - jackpotLastSeenAt > 4_000) {
            jackpotWasVisible = false
        }

        read.payout?.let {
            addOnce(now, "payout", value = it, signature = "payout:$it", cooldown = 14_000)
        }

        val newGiftResults = mutableListOf<GiftResult>()
        read.wins.forEach { hit ->
            val added = addOnce(
                now = now,
                type = "win",
                multiplier = hit.multiplier,
                signature = "win:${hit.positionKey}",
                cooldown = 8_000,
                gift = currentGift
            )
            if (added && currentGift != null) {
                newGiftResults += GiftResult(currentGift!!, hit.multiplier)
            }
        }

        val newLightPulses = processLuckyLights(read.luckyLights, now)
        val jackpotHitValue = processJackpotValue(read.jackpotValue, now)

        purge(now)
        return state(
            now = now,
            jackpotValue = read.jackpotValue ?: lastJackpotValue,
            newLightPulses = newLightPulses,
            jackpotHitValue = jackpotHitValue,
            history = history,
            newGiftResults = newGiftResults
        )
    }

    private fun processLuckyLights(samples: List<LuckyLightSample>, now: Long): List<Int> {
        if (samples.isEmpty()) return emptyList()
        val pulses = mutableListOf<Int>()

        for (sample in samples) {
            val m = sample.multiplier
            val score = sample.score.coerceIn(0.0, 1.0)
            val baseline = lightBaseline[m]

            if (baseline == null) {
                lightBaseline[m] = score
                lightActive[m] = false
                continue
            }

            val threshold = max(0.025, baseline * 0.22)
            val release = max(0.012, baseline * 0.10)
            val activeBefore = lightActive[m] ?: false
            val highNow = score > baseline + threshold && score > 0.095
            val released = score < baseline + release

            if (highNow && !activeBefore) {
                val previousPulse = lastLightPulseAt[m] ?: 0L
                if (now - previousPulse >= 2_000L) {
                    events.addLast(Event(now, "light", multiplier = m.toDouble(), signature = "light:$m:$now"))
                    pulses += m
                    lastLightPulseAt[m] = now
                }
                lightActive[m] = true
            } else if (activeBefore && released) {
                lightActive[m] = false
            }

            if (!highNow) {
                lightBaseline[m] = baseline * 0.94 + score * 0.06
            }
        }

        return pulses
    }

    private fun processJackpotValue(current: Long?, now: Long): Long? {
        if (current == null || current !in 100_000L..5_000_000L) return null

        val pendingFrom = pendingJackpotDropFrom
        if (pendingFrom != null) {
            val confirmDrop = max(200_000L, (pendingFrom * 0.12).toLong())
            if (current <= pendingFrom - confirmDrop && now - pendingJackpotDropAt <= 8_000L) {
                pendingJackpotDropFrom = null
                lastJackpotValue = current
                if (now - lastJackpotHitAt >= 45_000L) {
                    lastJackpotHitAt = now
                    events.addLast(Event(now, "jackpot_hit", value = pendingFrom, signature = "jackpot-hit:$pendingFrom"))
                    return pendingFrom
                }
            } else if (current >= (pendingFrom * 0.90).toLong() || now - pendingJackpotDropAt > 8_000L) {
                pendingJackpotDropFrom = null
            }
        }

        val previous = lastJackpotValue
        if (previous != null && previous >= 1_000_000L) {
            val largeDrop = max(250_000L, (previous * 0.15).toLong())
            if (current <= previous - largeDrop) {
                pendingJackpotDropFrom = previous
                pendingJackpotDropAt = now
                return null
            }
        }

        lastJackpotValue = current
        return null
    }

    private fun addOnce(
        now: Long,
        type: String,
        value: Long = 0,
        multiplier: Double = 0.0,
        signature: String,
        cooldown: Long,
        gift: String? = null
    ): Boolean {
        val previous = signatures[signature] ?: 0L
        if (now - previous < cooldown) return false

        signatures[signature] = now
        events.addLast(Event(now, type, value, multiplier, signature, gift))
        return true
    }

    private fun purge(now: Long) {
        val cutoff = now - 10 * 60_000L
        while (events.isNotEmpty() && events.first().ts < cutoff) events.removeFirst()

        val signatureCutoff = now - 2 * 60_000L
        val iterator = signatures.entries.iterator()
        while (iterator.hasNext()) {
            if (iterator.next().value < signatureCutoff) iterator.remove()
        }
    }

    private fun state(
        now: Long,
        jackpotValue: Long?,
        newLightPulses: List<Int>,
        jackpotHitValue: Long?,
        history: RoomStats?,
        newGiftResults: List<GiftResult>
    ): RadarState {
        val m1 = now - 60_000L
        val m2 = now - 2 * 60_000L
        val m5 = now - 5 * 60_000L
        val m10 = now - 10 * 60_000L

        val wins1 = events.count { it.type == "win" && it.ts >= m1 }
        val wins5 = events.count { it.type == "win" && it.ts >= m5 }
        val wins10 = events.count { it.type == "win" && it.ts >= m10 }
        val max1 = events.filter { it.type == "win" && it.ts >= m1 }.maxOfOrNull { it.multiplier }
        val payout5 = events.filter { it.type == "payout" && it.ts >= m5 }.sumOf { it.value }
        val jackpot5 = events.count { it.type == "jackpot" && it.ts >= m5 }
        val lastPayout = events.lastOrNull { it.type == "payout" }?.value

        val wins5Events = events.filter { it.type == "win" && it.ts >= m5 }
        fun bandCount(min: Double, max: Double): Int = wins5Events.count { it.multiplier >= min && it.multiplier <= max }
        val b2to4 = bandCount(2.0, 4.999)
        val b5to9 = bandCount(5.0, 9.999)
        val b10to24 = bandCount(10.0, 24.999)
        val b25to49 = bandCount(25.0, 49.999)
        val b50to99 = bandCount(50.0, 99.999)
        val b100to249 = bandCount(100.0, 249.999)
        val b250to499 = bandCount(250.0, 499.999)
        val b500to1000 = bandCount(500.0, 1000.0)

        val lights1 = events.count { it.type == "light" && it.ts >= m1 }
        val lights5 = events.count { it.type == "light" && it.ts >= m5 }
        val lightsPrev1 = events.count { it.type == "light" && it.ts in m2 until m1 }
        val highLights1 = events.count { it.type == "light" && it.ts >= m1 && it.multiplier >= 200.0 }

        fun lightCount(multiplier: Int): Int =
            events.count { it.type == "light" && it.ts >= m5 && it.multiplier == multiplier.toDouble() }

        val lightTrendPercent = when {
            lightsPrev1 == 0 && lights1 == 0 -> 0
            lightsPrev1 == 0 -> if (sampleStartedLongEnough(now, 60_000L)) 100 else 0
            else -> (((lights1 - lightsPrev1).toDouble() / lightsPrev1) * 100.0)
                .roundToInt().coerceIn(-999, 999)
        }

        val band = jackpotBand(jackpotValue)
        val baseRefScore = when {
            jackpotValue == null -> 0
            jackpotValue in 1_600_000L..2_000_000L -> 100
            jackpotValue in 1_275_000L..1_500_000L -> 78
            jackpotValue in 1_500_001L..1_599_999L -> 58
            jackpotValue > 2_000_000L -> 62
            else -> 25
        }
        val historicalHits = history?.jackpotHitCount ?: 0L
        val historicalRefHits = (history?.ref1Hits ?: 0L) + (history?.ref2Hits ?: 0L)
        val historicalRefRate = if (historicalHits > 0) historicalRefHits.toDouble() / historicalHits else 0.0
        val historyAdjustment = when {
            historicalHits < 3 -> 0
            historicalRefRate >= 0.75 -> 8
            historicalRefRate >= 0.50 -> 3
            historicalRefRate < 0.30 -> -18
            else -> -6
        }
        val refScore = (baseRefScore + historyAdjustment).coerceIn(0, 100)

        val historicalPatternScore = if (history != null && historicalHits >= 3 && jackpotValue != null) {
            val avgLights = history.averagePreHitLights1m.coerceAtLeast(0.5)
            val avgHigh = history.averagePreHitHighLights1m.coerceAtLeast(0.25)
            val avgWins = history.averagePreHitWins1m.coerceAtLeast(0.5)
            val avgJackpot = history.averageJackpotHit.toDouble().coerceAtLeast(1.0)

            val lightLevel = (lights1 / avgLights).coerceIn(0.0, 1.0)
            val highLevel = (highLights1 / avgHigh).coerceIn(0.0, 1.0)
            val winLevel = (wins1 / avgWins).coerceIn(0.0, 1.0)
            val tolerance = max(250_000.0, avgJackpot * 0.22)
            val jackpotProximity = (1.0 - kotlin.math.abs(jackpotValue - avgJackpot) / tolerance)
                .coerceIn(0.0, 1.0)

            (lightLevel * 35.0 + highLevel * 25.0 + winLevel * 15.0 + jackpotProximity * 25.0)
                .roundToInt().coerceIn(0, 100)
        } else 0

        val historicalPatternStatus = when {
            historicalHits < 3 -> "BASE PRÉ-HIT INSUFICIENTE"
            historicalPatternScore >= 75 -> "MUITO PARECIDO COM PRÉ-HITS OBSERVADOS"
            historicalPatternScore >= 55 -> "PARECIDO COM PRÉ-HITS OBSERVADOS"
            historicalPatternScore >= 35 -> "SEMELHANÇA PARCIAL"
            else -> "POUCA SEMELHANÇA"
        }

        fun norm(v: Double, cap: Double): Double = (v / cap).coerceIn(0.0, 1.0)
        val lightRateScore = norm(lights1.toDouble(), 8.0) * 25.0
        val highLightScore = norm(highLights1.toDouble(), 3.0) * 15.0
        val accelerationScore = when {
            lightTrendPercent >= 75 -> 12.0
            lightTrendPercent >= 30 -> 8.0
            lightTrendPercent > 0 -> 4.0
            else -> 0.0
        }
        val refBandScore = refScore / 100.0 * 18.0
        val resultActivityScore = norm(wins1.toDouble(), 7.0) * 7.0
        val persistenceScore = norm(wins5.toDouble(), 22.0) * 5.0
        val historyPatternContribution = historicalPatternScore / 100.0 * 18.0

        val score = (
            lightRateScore + highLightScore + accelerationScore + refBandScore +
                resultActivityScore + persistenceScore + historyPatternContribution
            ).roundToInt().coerceIn(0, 100)

        val state = when {
            score >= 72 -> "MUITO ALTA"
            score >= 52 -> "ALTA"
            score >= 32 -> "MODERADA"
            else -> "BAIXA"
        }

        val trend = when {
            previousScore < 0 -> "INICIANDO"
            score >= previousScore + 6 -> "SUBINDO"
            score <= previousScore - 6 -> "CAINDO"
            else -> "ESTÁVEL"
        }
        previousScore = score

        val sampleSeconds = ((now - sessionStartedAt) / 1000L).coerceAtLeast(0L)
        val evidenceEvents = wins10 + events.count { it.type == "light" }
        val historicalEvidence = (history?.luckyLightPulses ?: 0L) + (history?.totalWins ?: 0L)
        val confidence = when {
            historicalHits >= 5 || historicalEvidence >= 120 -> "ALTA • HISTÓRICO"
            sampleSeconds >= 300 && evidenceEvents >= 25 -> "ALTA"
            historicalHits >= 2 || historicalEvidence >= 35 || (sampleSeconds >= 90 && evidenceEvents >= 8) -> "MÉDIA"
            else -> "BAIXA • COLETANDO"
        }

        val activityWindow = when {
            confidence.startsWith("BAIXA") && score >= 75 -> "⚡ PROVISÓRIA • ATIVIDADE MUITO ELEVADA"
            confidence.startsWith("BAIXA") && score >= 58 -> "⚡ PROVISÓRIA • ATIVIDADE ELEVADA"
            confidence.startsWith("BAIXA") && score >= 38 -> "⚡ PROVISÓRIA • OBSERVAÇÃO"
            confidence.startsWith("BAIXA") -> "🧪 COLETANDO • ATIVIDADE BAIXA"
            score >= 75 && refScore >= 58 -> "JANELA DE ATIVIDADE MUITO ELEVADA"
            score >= 58 -> "JANELA DE ATIVIDADE ELEVADA"
            score >= 38 -> "OBSERVAÇÃO"
            else -> "SEM JANELA RELEVANTE"
        }

        val giftState = giftState(history, newGiftResults)

        return RadarState(
            heatScore = score,
            state = state,
            trend = trend,
            activityWindow = activityWindow,
            confidence = confidence,
            sampleSeconds = sampleSeconds,
            jackpotValue = jackpotValue,
            jackpotBand = band,
            jackpotReferenceScore = refScore,
            historicalPatternScore = historicalPatternScore,
            historicalPatternStatus = historicalPatternStatus,
            jackpotHitValue = jackpotHitValue,
            lastPayout = lastPayout,
            maxMultiplier1m = max1,
            wins1m = wins1,
            wins5m = wins5,
            wins10m = wins10,
            payouts5m = payout5,
            jackpotEvents5m = jackpot5,
            lightPulses1m = lights1,
            lightPulses5m = lights5,
            lightPulsesPrev1m = lightsPrev1,
            lightTrendPercent = lightTrendPercent,
            highLightPulses1m = highLights1,
            newLightPulses = newLightPulses,
            lightX20_5m = lightCount(20),
            lightX50_5m = lightCount(50),
            lightX200_5m = lightCount(200),
            lightX300_5m = lightCount(300),
            lightX500_5m = lightCount(500),
            lightX1000_5m = lightCount(1000),
            wins2to4_5m = b2to4,
            wins5to9_5m = b5to9,
            wins10to24_5m = b10to24,
            wins25to49_5m = b25to49,
            wins50to99_5m = b50to99,
            wins100to249_5m = b100to249,
            wins250to499_5m = b250to499,
            wins500to1000_5m = b500to1000,
            currentGift = currentGift,
            giftAction = giftState.action,
            giftRecommendation = giftState.recommendation,
            giftConfidence = giftState.confidence,
            lowMultiplierStreak = giftState.lowStreak,
            giftTrevoScore = giftState.trevoScore,
            giftRosaScore = giftState.rosaScore,
            giftOvoScore = giftState.ovoScore,
            giftTrevoSamples = giftState.trevoSamples,
            giftRosaSamples = giftState.rosaSamples,
            giftOvoSamples = giftState.ovoSamples,
            newGiftResults = newGiftResults
        )
    }

    private data class GiftState(
        val action: String,
        val recommendation: String,
        val confidence: String,
        val lowStreak: Int,
        val trevoScore: Int,
        val rosaScore: Int,
        val ovoScore: Int,
        val trevoSamples: Long,
        val rosaSamples: Long,
        val ovoSamples: Long
    )

    private fun giftState(history: RoomStats?, newGiftResults: List<GiftResult>): GiftState {
        val trevo = combineGift(historyGift(history, "TREVO"), resultGift(newGiftResults, "TREVO"))
        val rosa = combineGift(historyGift(history, "ROSA"), resultGift(newGiftResults, "ROSA"))
        val ovo = combineGift(historyGift(history, "OVO"), resultGift(newGiftResults, "OVO"))

        val scores = linkedMapOf(
            "TREVO" to giftScore(trevo),
            "ROSA" to giftScore(rosa),
            "OVO" to giftScore(ovo)
        )
        val samples = mapOf(
            "TREVO" to trevo.samples,
            "ROSA" to rosa.samples,
            "OVO" to ovo.samples
        )

        val current = currentGift
        val lowStreak = consecutiveLowStreak(current)
        val ranked = scores.entries.sortedWith(
            compareByDescending<Map.Entry<String, Int>> { it.value }
                .thenBy { when (it.key) { "TREVO" -> 0; "ROSA" -> 1; else -> 2 } }
        )

        val currentScore = current?.let { scores[it] } ?: 0
        val bestAlternative = ranked.firstOrNull { it.key != current } ?: ranked.first()
        val currentSamples = current?.let { samples[it] } ?: 0L
        val totalSamples = trevo.samples + rosa.samples + ovo.samples

        val action = when {
            current == null -> "🎁 SELECIONE TREVO / ROSA / OVO PARA CALIBRAR"
            lowStreak >= 5 -> "🔄 TROCA SUGERIDA • SEQUÊNCIA BAIXA"
            lowStreak >= 3 && bestAlternative.value >= currentScore + 8 -> "⚠️ CONSIDERAR TROCA"
            currentSamples < 4 -> "🧪 MANTER E COLETAR AMOSTRA"
            else -> "✅ MANTER E OBSERVAR"
        }

        val recommendation = when {
            current == null -> ranked.first().key
            action.startsWith("🔄") || action.startsWith("⚠️") -> bestAlternative.key
            else -> current
        }

        val confidence = when {
            totalSamples >= 45 && samples.getValue(recommendation) >= 12 -> "ALTA"
            totalSamples >= 18 && samples.getValue(recommendation) >= 5 -> "MÉDIA"
            else -> "BAIXA • COLETANDO"
        }

        return GiftState(
            action = action,
            recommendation = recommendation,
            confidence = confidence,
            lowStreak = lowStreak,
            trevoScore = scores.getValue("TREVO"),
            rosaScore = scores.getValue("ROSA"),
            ovoScore = scores.getValue("OVO"),
            trevoSamples = trevo.samples,
            rosaSamples = rosa.samples,
            ovoSamples = ovo.samples
        )
    }

    private fun consecutiveLowStreak(gift: String?): Int {
        if (gift == null) return 0
        var count = 0
        val iterator = events.descendingIterator()
        while (iterator.hasNext()) {
            val e = iterator.next()
            if (e.type != "win" || e.gift != gift) continue
            if (e.multiplier <= 5.999) count++ else break
        }
        return count
    }

    private fun historyGift(history: RoomStats?, gift: String): GiftAgg {
        if (history == null) return GiftAgg(0, 0, 0, 0, 0, 0)
        return when (gift) {
            "TREVO" -> GiftAgg(history.giftTrevoSamples, history.giftTrevoSumX10, history.giftTrevoLow, history.giftTrevo50Plus, history.giftTrevo200Plus, history.giftTrevoMaxX10)
            "ROSA" -> GiftAgg(history.giftRosaSamples, history.giftRosaSumX10, history.giftRosaLow, history.giftRosa50Plus, history.giftRosa200Plus, history.giftRosaMaxX10)
            else -> GiftAgg(history.giftOvoSamples, history.giftOvoSumX10, history.giftOvoLow, history.giftOvo50Plus, history.giftOvo200Plus, history.giftOvoMaxX10)
        }
    }

    private fun resultGift(results: List<GiftResult>, gift: String): GiftAgg {
        val list = results.filter { it.gift == gift }
        return GiftAgg(
            samples = list.size.toLong(),
            sumX10 = list.sumOf { (it.multiplier * 10.0).roundToInt().toLong() },
            low = list.count { it.multiplier <= 5.999 }.toLong(),
            plus50 = list.count { it.multiplier >= 50.0 }.toLong(),
            plus200 = list.count { it.multiplier >= 200.0 }.toLong(),
            maxX10 = ((list.maxOfOrNull { it.multiplier } ?: 0.0) * 10.0).roundToInt().toLong()
        )
    }

    private fun combineGift(a: GiftAgg, b: GiftAgg): GiftAgg = GiftAgg(
        samples = a.samples + b.samples,
        sumX10 = a.sumX10 + b.sumX10,
        low = a.low + b.low,
        plus50 = a.plus50 + b.plus50,
        plus200 = a.plus200 + b.plus200,
        maxX10 = maxOf(a.maxX10, b.maxX10)
    )

    private fun giftScore(a: GiftAgg): Int {
        if (a.samples <= 0) return 50
        val avg = (a.sumX10 / 10.0) / a.samples
        val lowRate = a.low.toDouble() / a.samples
        val rate50 = a.plus50.toDouble() / a.samples
        val rate200 = a.plus200.toDouble() / a.samples
        val avgComponent = (avg.coerceAtMost(80.0) / 80.0) * 24.0
        val highComponent = rate50 * 22.0 + rate200 * 24.0
        val lowPenalty = lowRate * 30.0
        val sampleBonus = (a.samples.coerceAtMost(20).toDouble() / 20.0) * 8.0
        return (46.0 + avgComponent + highComponent + sampleBonus - lowPenalty)
            .roundToInt().coerceIn(0, 100)
    }

    private fun sampleStartedLongEnough(now: Long, duration: Long): Boolean =
        sessionStartedAt > 0L && now - sessionStartedAt >= duration

    private fun jackpotBand(v: Long?): String = when {
        v == null -> "SEM LEITURA"
        v < 1_275_000L -> "ABAIXO DA 1ª REFERÊNCIA"
        v <= 1_500_000L -> "🎯 FAIXA ADM 1 • 1.275M–1.500M"
        v < 1_600_000L -> "ENTRE AS FAIXAS"
        v <= 2_000_000L -> "🔥 FAIXA ADM 2 • 1.600M–2.000M"
        else -> "ACIMA DAS REFERÊNCIAS"
    }
}
