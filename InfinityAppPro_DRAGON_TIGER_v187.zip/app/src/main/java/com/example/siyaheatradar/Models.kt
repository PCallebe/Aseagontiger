package com.example.siyaheatradar

import android.graphics.Rect

data class OcrItem(
    val text: String,
    val box: Rect
) {
    val cx: Int get() = box.centerX()
    val cy: Int get() = box.centerY()
    val h: Int get() = box.height()
    val w: Int get() = box.width()
}

data class WinHit(
    val multiplier: Double,
    val positionKey: String
)

data class LuckyLightSample(
    val multiplier: Int,
    val score: Double,
    val positionKey: String
)

data class GiftSelectionSample(
    val gift: String,
    val selectedScore: Double,
    val positionKey: String
)

data class GiftResult(
    val gift: String,
    val multiplier: Double
)

data class ScreenRead(
    val timestamp: Long,
    val roomName: String?,
    val roomId: String?,
    val roomUiConfirmed: Boolean,
    val jackpotBanner: Boolean,
    val jackpotValue: Long?,
    val payout: Long?,
    val previousPayout: Long?,
    val wins: List<WinHit>,
    val luckyLights: List<LuckyLightSample>,
    val selectedGift: String?,
    val giftPanelVisible: Boolean,
    val maxMultiplier: Double?,
    val rawSignals: List<String>
)

data class RadarState(
    val heatScore: Int,
    val state: String,
    val trend: String,
    val activityWindow: String,
    val confidence: String,
    val sampleSeconds: Long,
    val jackpotValue: Long?,
    val jackpotBand: String,
    val jackpotReferenceScore: Int,
    val historicalPatternScore: Int,
    val historicalPatternStatus: String,
    val jackpotHitValue: Long?,
    val lastPayout: Long?,
    val maxMultiplier1m: Double?,
    val wins1m: Int,
    val wins5m: Int,
    val wins10m: Int,
    val payouts5m: Long,
    val jackpotEvents5m: Int,
    val lightPulses1m: Int,
    val lightPulses5m: Int,
    val lightPulsesPrev1m: Int,
    val lightTrendPercent: Int,
    val highLightPulses1m: Int,
    val newLightPulses: List<Int>,
    val lightX20_5m: Int,
    val lightX50_5m: Int,
    val lightX200_5m: Int,
    val lightX300_5m: Int,
    val lightX500_5m: Int,
    val lightX1000_5m: Int,
    val wins2to4_5m: Int,
    val wins5to9_5m: Int,
    val wins10to24_5m: Int,
    val wins25to49_5m: Int,
    val wins50to99_5m: Int,
    val wins100to249_5m: Int,
    val wins250to499_5m: Int,
    val wins500to1000_5m: Int,
    val currentGift: String?,
    val giftAction: String,
    val giftRecommendation: String,
    val giftConfidence: String,
    val lowMultiplierStreak: Int,
    val giftTrevoScore: Int,
    val giftRosaScore: Int,
    val giftOvoScore: Int,
    val giftTrevoSamples: Long,
    val giftRosaSamples: Long,
    val giftOvoSamples: Long,
    val newGiftResults: List<GiftResult>
)

data class RoomStats(
    val name: String,
    val roomId: String = "",
    val firstSeen: Long = 0L,
    val lastSeen: Long = 0L,
    val visits: Int = 0,
    val captures: Long = 0L,
    val totalWins: Long = 0L,
    val totalPayout: Long = 0L,
    val payoutCount: Long = 0L,
    val maxMultiplier: Double = 0.0,
    val jackpotEvents: Long = 0L,
    val lastPayout: Long = 0L,
    val lastHeatScore: Int = 0,
    val maxHeatScore: Int = 0,
    val lastPayoutAt: Long = 0L,
    val lastPreviousPayout: Long = 0L,
    val wins2to4: Long = 0L,
    val wins5to9: Long = 0L,
    val wins10to24: Long = 0L,
    val wins25to49: Long = 0L,
    val wins50to99: Long = 0L,
    val wins100to249: Long = 0L,
    val wins250to499: Long = 0L,
    val wins500to1000: Long = 0L,
    val jackpotSamples: Long = 0L,
    val lastJackpotValue: Long = 0L,
    val maxJackpotValue: Long = 0L,
    val jackpotHitCount: Long = 0L,
    val jackpotHitValueSum: Long = 0L,
    val lastJackpotHitValue: Long = 0L,
    val lastJackpotHitAt: Long = 0L,
    val minJackpotHitValue: Long = 0L,
    val maxJackpotHitValue: Long = 0L,
    val preHitLight1mSum: Long = 0L,
    val preHitHighLight1mSum: Long = 0L,
    val preHitWins1mSum: Long = 0L,
    val ref1Hits: Long = 0L,
    val ref2Hits: Long = 0L,
    val luckyLightPulses: Long = 0L,
    val lightX20: Long = 0L,
    val lightX50: Long = 0L,
    val lightX200: Long = 0L,
    val lightX300: Long = 0L,
    val lightX500: Long = 0L,
    val lightX1000: Long = 0L,
    val lastGift: String = "",
    val giftTrevoSamples: Long = 0L,
    val giftTrevoSumX10: Long = 0L,
    val giftTrevoLow: Long = 0L,
    val giftTrevo50Plus: Long = 0L,
    val giftTrevo200Plus: Long = 0L,
    val giftTrevoMaxX10: Long = 0L,
    val giftRosaSamples: Long = 0L,
    val giftRosaSumX10: Long = 0L,
    val giftRosaLow: Long = 0L,
    val giftRosa50Plus: Long = 0L,
    val giftRosa200Plus: Long = 0L,
    val giftRosaMaxX10: Long = 0L,
    val giftOvoSamples: Long = 0L,
    val giftOvoSumX10: Long = 0L,
    val giftOvoLow: Long = 0L,
    val giftOvo50Plus: Long = 0L,
    val giftOvo200Plus: Long = 0L,
    val giftOvoMaxX10: Long = 0L
) {
    val averagePayout: Long
        get() = if (payoutCount > 0) totalPayout / payoutCount else 0L

    val averageJackpotHit: Long
        get() = if (jackpotHitCount > 0) jackpotHitValueSum / jackpotHitCount else 0L

    val averagePreHitLights1m: Double
        get() = if (jackpotHitCount > 0) preHitLight1mSum.toDouble() / jackpotHitCount else 0.0

    val averagePreHitHighLights1m: Double
        get() = if (jackpotHitCount > 0) preHitHighLight1mSum.toDouble() / jackpotHitCount else 0.0

    val averagePreHitWins1m: Double
        get() = if (jackpotHitCount > 0) preHitWins1mSum.toDouble() / jackpotHitCount else 0.0
}
