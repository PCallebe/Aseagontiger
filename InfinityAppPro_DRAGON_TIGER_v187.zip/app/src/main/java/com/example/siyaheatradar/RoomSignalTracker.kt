package com.example.siyaheatradar

import android.view.accessibility.AccessibilityEvent
import java.util.ArrayDeque
import kotlin.math.roundToInt


data class RoomSignalSnapshot(
    val effectiveHeat: Int,
    val heatState: String,
    val combinedTrend: String,
    val activityScore: Int,
    val emojiCount1m: Int,
    val emojiLevel: String,
    val giftEvents1m: Int,
    val giftLevel: String,
    val normalGiftUnits1m: Int,
    val afortunadoUnits1m: Int,
    val scrollEvents1m: Int,
    val scrollLevel: String,
    val rocketProgress: Int?,
    val rocketTrend: String,
    val rocketCurrent: Long?,
    val rocketTarget: Long?,
    val rocketLabel: String,
    val pkStatus: String,
    val peopleCount: Int?,
    val chairsTotal: Int?,
    val chairsOccupied: Int?,
    val userSeat: Int?,
    val trevoSent1m: Int,
    val rosaSent1m: Int,
    val ovoSent1m: Int,
    val snapshotAt: Long,
    val snapshotHeat: Int
)

data class RoomSignalSettings(
    val emojis: Boolean = true,
    val gifts: Boolean = true,
    val rocket: Boolean = true,
    val pk: Boolean = true,
    val people: Boolean = true,
    val scroll: Boolean = true,
    val snapshotIntervalSeconds: Int = 60
)

/**
 * Mede sinais observáveis dentro da sala. Rolagem e poltrona alimentam a MESMA sessão.
 * Presentes normais aquecem a sala; Afortunados também alimentam a análise de prêmio.
 */
class RoomSignalTracker {
    private data class Timed(val ts: Long, val kind: String)
    private data class GiftTimed(val ts: Long, val name: String, val amount: Int, val afortunado: Boolean)
    private data class RocketPoint(val ts: Long, val progress: Int, val current: Long, val target: Long)

    private val events = ArrayDeque<Timed>()
    private val giftEvents = ArrayDeque<GiftTimed>()
    private val rocketPoints = ArrayDeque<RocketPoint>()
    private val textSignatures = LinkedHashMap<String, Long>()
    private var pkActive = false
    private var pkConfidence = "DESLIGADO"
    private var pkUpdatedAt = 0L
    private var latestPeople: Int? = null
    private var latestChairsTotal: Int? = null
    private var latestChairsOccupied: Int? = null
    private var latestUserSeat: Int? = null
    private var lastSnapshotAt = 0L
    private var lastSnapshotHeat = 0

    fun resetTransient() {
        events.clear()
        giftEvents.clear()
        rocketPoints.clear()
        textSignatures.clear()
        pkActive = false
        pkConfidence = "DESLIGADO"
        pkUpdatedAt = 0L
        latestPeople = null
        latestChairsTotal = null
        latestChairsOccupied = null
        latestUserSeat = null
        lastSnapshotAt = 0L
        lastSnapshotHeat = 0
    }

    fun ingestAccessibility(eventType: Int, rawText: String, now: Long) {
        prune(now)
        val text = rawText.trim()

        if (eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            events.addLast(Timed(now, "SCROLL"))
        }

        if (text.isBlank()) return
        val normalized = normalize(text).take(900)
        if (!once("A:$normalized", now, 1_300L)) return

        val emojiCount = countEmoji(text).coerceAtMost(16)
        repeat(emojiCount) { events.addLast(Timed(now, "EMOJI")) }

        if (looksLikeSentGift(normalized)) {
            val name = GiftCatalog.afortunadoFromText(text)
                ?: GiftCatalog.normalGiftNameFromSendText(text)
                ?: "PRESENTE_NORMAL"
            giftEvents.addLast(GiftTimed(now, name, 1, GiftCatalog.isAfortunado(name)))
        }

    }

    fun ingestLiveGifts(found: List<LiveGiftEvent>, now: Long) {
        prune(now)
        found.forEach { event ->
            val amount = event.quantity.coerceIn(1, 500)
            giftEvents.addLast(GiftTimed(now, event.name, amount, event.isAfortunado))
        }
    }

    fun ingestChairs(reading: ChairReading) {
        reading.total?.let { latestChairsTotal = maxOf(latestChairsTotal ?: 0, it) }
        reading.occupied?.let { latestChairsOccupied = it }
        reading.userSeat?.let { latestUserSeat = it }
    }

    fun ingestOcr(
        items: List<OcrItem>,
        width: Int,
        height: Int,
        strategy: StrategyRead,
        giftPanelVisible: Boolean,
        now: Long
    ) {
        prune(now)
        latestPeople = strategy.peopleCount ?: latestPeople

        detectRocket(items.joinToString(" | ") { it.text })?.let { rocket ->
            val last = rocketPoints.peekLast()
            if (last == null || kotlin.math.abs(rocket.progress - last.progress) >= 1 ||
                rocket.current != last.current || rocket.target != last.target
            ) {
                rocketPoints.addLast(RocketPoint(now, rocket.progress, rocket.current, rocket.target))
            }
        }


        val lower = items.filter { it.cy.toDouble() / height >= 0.42 }
        val lowerText = lower.joinToString(" | ") { it.text }
        val normalizedLower = normalize(lowerText).take(2200)
        if (normalizedLower.isNotBlank() && once("O:$normalizedLower", now, 1_500L)) {
            val emojiCount = countEmoji(lowerText).coerceAtMost(14)
            repeat(emojiCount) { events.addLast(Timed(now, "EMOJI")) }

            // Fallback textual. O LiveGiftVision faz a contagem principal.
            if (!giftPanelVisible && looksLikeSentGift(normalizedLower)) {
                val name = GiftCatalog.afortunadoFromText(lowerText)
                    ?: GiftCatalog.normalGiftNameFromSendText(lowerText)
                    ?: "PRESENTE_NORMAL"
                giftEvents.addLast(GiftTimed(now, name, 1, GiftCatalog.isAfortunado(name)))
            }
        }
    }

    fun ingestPk(reading: PkReading, now: Long) {
        pkActive = reading.active
        pkConfidence = reading.confidence
        pkUpdatedAt = now
    }

    fun snapshot(
        baseHeat: Int,
        baseTrend: String,
        peopleCount: Int?,
        now: Long,
        settings: RoomSignalSettings = RoomSignalSettings()
    ): RoomSignalSnapshot {
        prune(now)
        if (settings.people && peopleCount != null) latestPeople = peopleCount

        val cutoff1m = now - 60_000L
        fun count(kind: String) = events.count { it.ts >= cutoff1m && it.kind == kind }

        val emojis = if (settings.emojis) count("EMOJI") else 0
        val scrolls = if (settings.scroll) count("SCROLL") else 0
        val liveGifts = if (settings.gifts) giftEvents.filter { it.ts >= cutoff1m } else emptyList()
        val gifts = liveGifts.sumOf { it.amount }.coerceAtMost(5000)
        val normal = liveGifts.filter { !it.afortunado }.sumOf { it.amount }.coerceAtMost(5000)
        val afortunados = liveGifts.filter { it.afortunado }.sumOf { it.amount }.coerceAtMost(5000)
        val trevo = liveGifts.filter { it.name == "TREVO" }.sumOf { it.amount }
        val rosa = liveGifts.filter { it.name == "ROSA" }.sumOf { it.amount }
        val ovo = liveGifts.filter { it.name == "OVO" }.sumOf { it.amount }

        val rocketPoint = if (settings.rocket) rocketPoints.peekLast() else null
        val rocket = rocketPoint?.progress
        val rocketTrend = if (settings.rocket) rocketTrend(now) else "DESATIVADO"
        val rocketLabel = rocketPoint?.let { "${compact(it.current)}/${compact(it.target)}" } ?: "—"
        val pkStatus = if (!settings.pk) {
            "DESATIVADO"
        } else if (pkActive && now - pkUpdatedAt <= 3_500L) {
            "ATIVO"
        } else {
            "DESLIGADO"
        }

        val emojiScore = (emojis * 2.5).roundToInt().coerceAtMost(18)
        // Unidades de presentes entram com curva mais suave para rajadas grandes não saturarem instantaneamente.
        val giftScore = when {
            gifts >= 60 -> 36
            gifts >= 30 -> 30
            gifts >= 15 -> 24
            gifts >= 6 -> 18
            gifts >= 2 -> 10
            gifts > 0 -> 5
            else -> 0
        }
        val scrollScore = (scrolls * 1.6).roundToInt().coerceAtMost(14)
        val rocketScore = ((rocket ?: 0) * 0.20).roundToInt().coerceAtMost(20)
        val pkScore = if (pkStatus == "ATIVO") 10 else 0
        val activity = (emojiScore + giftScore + scrollScore + rocketScore + pkScore).coerceIn(0, 100)

        val effective = (baseHeat * 0.50 + activity * 0.50).roundToInt().coerceIn(0, 100)
        val heatState = when {
            effective >= 85 -> "MUITO QUENTE"
            effective >= 70 -> "QUENTE"
            effective >= 50 -> "AQUECENDO"
            effective >= 30 -> "MORNA"
            else -> "FRIA"
        }
        val combinedTrend = when {
            rocketTrend == "SUBINDO" && activity >= 38 -> "ESQUENTANDO"
            gifts >= 10 && activity >= 38 -> "ESQUENTANDO"
            activity <= 12 && baseTrend == "CAINDO" -> "ESFRIANDO"
            baseTrend == "SUBINDO" -> "ESQUENTANDO"
            else -> baseTrend
        }

        val intervalMs = settings.snapshotIntervalSeconds.coerceIn(30, 120) * 1000L
        if (lastSnapshotAt == 0L || now - lastSnapshotAt >= intervalMs) {
            lastSnapshotAt = now
            lastSnapshotHeat = effective
        }

        return RoomSignalSnapshot(
            effectiveHeat = effective,
            heatState = heatState,
            combinedTrend = combinedTrend,
            activityScore = activity,
            emojiCount1m = emojis,
            emojiLevel = level(emojis, 6, 18),
            giftEvents1m = gifts,
            giftLevel = level(gifts, 4, 18),
            normalGiftUnits1m = normal,
            afortunadoUnits1m = afortunados,
            scrollEvents1m = scrolls,
            scrollLevel = when { scrolls >= 18 -> "INTENSA"; scrolls >= 7 -> "ATIVA"; scrolls > 0 -> "MODERADA"; else -> "BAIXA" },
            rocketProgress = rocket,
            rocketTrend = rocketTrend,
            rocketCurrent = rocketPoint?.current,
            rocketTarget = rocketPoint?.target,
            rocketLabel = rocketLabel,
            pkStatus = pkStatus,
            peopleCount = if (settings.people) latestPeople else null,
            chairsTotal = latestChairsTotal,
            chairsOccupied = latestChairsOccupied,
            userSeat = latestUserSeat,
            trevoSent1m = trevo,
            rosaSent1m = rosa,
            ovoSent1m = ovo,
            snapshotAt = lastSnapshotAt,
            snapshotHeat = lastSnapshotHeat
        )
    }

    private fun level(value: Int, medium: Int, high: Int): String = when {
        value >= high -> "ALTO"
        value >= medium -> "FORTE"
        value > 0 -> "BAIXO"
        else -> "SEM SINAL"
    }

    private fun prune(now: Long) {
        val eventCutoff = now - 5L * 60L * 1000L
        while (events.isNotEmpty() && events.peekFirst().ts < eventCutoff) events.removeFirst()
        while (giftEvents.isNotEmpty() && giftEvents.peekFirst().ts < eventCutoff) giftEvents.removeFirst()
        while (rocketPoints.isNotEmpty() && rocketPoints.peekFirst().ts < eventCutoff) rocketPoints.removeFirst()
        val sigCutoff = now - 60_000L
        val it = textSignatures.entries.iterator()
        while (it.hasNext()) if (it.next().value < sigCutoff) it.remove()
    }

    private fun once(key: String, now: Long, cooldown: Long): Boolean {
        val prev = textSignatures[key] ?: 0L
        if (now - prev < cooldown) return false
        textSignatures[key] = now
        return true
    }

    private fun normalize(text: String): String = GiftCatalog.normalizeText(text)

    private fun looksLikeSentGift(text: String): Boolean {
        val sendVerb = text.contains("enviou") || text.contains("mandou") ||
            text.contains("enviado") || text.contains(" sent ") || text.contains(" gifted")
        if (!sendVerb) return false
        return text.contains("presente") || text.contains("gift") || GiftCatalog.afortunadoFromText(text) != null
    }

    private data class RocketRead(val current: Long, val target: Long, val progress: Int)

    private fun detectRocket(textRaw: String): RocketRead? {
        val text = textRaw.replace(',', '.').uppercase()
        val rx = Regex("""(\\d+(?:\\.\\d+)?)\\s*([KM]?)\\s*/\\s*(\\d+(?:\\.\\d+)?)\\s*([KM]?)""")
        val candidates = rx.findAll(text).mapNotNull { m ->
            val current = scaled(m.groupValues[1], m.groupValues[2]) ?: return@mapNotNull null
            val target = scaled(m.groupValues[3], m.groupValues[4]) ?: return@mapNotNull null
            // Foguete mostrado no SIYA usa metas grandes; evita 3/10 ou outros contadores pequenos.
            if (target < 10_000.0 || current < 0.0 || current > target * 1.15) return@mapNotNull null
            RocketRead(
                current = current.roundToInt().toLong(),
                target = target.roundToInt().toLong(),
                progress = ((current / target) * 100.0).roundToInt().coerceIn(0, 100)
            )
        }.toList()
        return candidates.maxByOrNull { it.target }
    }

    private fun scaled(number: String, suffix: String): Double? {
        val n = number.toDoubleOrNull() ?: return null
        return when (suffix) { "K" -> n * 1_000.0; "M" -> n * 1_000_000.0; else -> n }
    }

    private fun rocketTrend(now: Long): String {
        if (rocketPoints.isEmpty()) return "AGUARDANDO VALOR"
        val recent = rocketPoints.filter { it.ts >= now - 120_000L }
        if (recent.size < 2) return "ESTÁVEL"
        val delta = recent.last().progress - recent.first().progress
        return when { delta >= 2 -> "SUBINDO"; delta <= -2 -> "CAINDO"; else -> "ESTÁVEL" }
    }

    private fun compact(v: Long): String = when {
        v >= 1_000_000L -> String.format(java.util.Locale.US, "%.1fM", v / 1_000_000.0)
        v >= 1_000L -> String.format(java.util.Locale.US, "%.1fK", v / 1_000.0)
        else -> v.toString()
    }

    private fun countEmoji(text: String): Int {
        var count = 0
        var i = 0
        while (i < text.length) {
            val cp = Character.codePointAt(text, i)
            if ((cp in 0x1F300..0x1FAFF) || (cp in 0x2600..0x27BF)) count++
            i += Character.charCount(cp)
        }
        return count
    }
}
