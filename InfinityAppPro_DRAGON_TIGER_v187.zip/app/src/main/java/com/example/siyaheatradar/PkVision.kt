package com.example.siyaheatradar

import kotlin.math.abs

/**
 * PK conservador. A palavra "PK" isolada NÃO liga o indicador.
 * Exige assinatura de batalha (PK/VS/Batalha + placar/timer/duas equipes).
 */
data class PkReading(val active: Boolean, val confidence: String)

class PkVision {
    fun detect(items: List<OcrItem>, width: Int, height: Int): PkReading {
        if (items.isEmpty() || width <= 0 || height <= 0) return PkReading(false, "SEM SINAL")
        val all = GiftCatalog.normalizeText(items.joinToString(" ") { it.text })
        val hasPkWord = Regex("(^|\\s)pk(\\s|$)").containsMatchIn(all)
        val hasVs = Regex("(^|\\s)(vs|versus)(\\s|$)").containsMatchIn(all)
        val hasBattleWord = listOf("batalha", "battle", "duelo", "desafio pk").any { all.contains(it) }

        val topItems = items.filter { it.cy.toDouble() / height in 0.04..0.42 }
        val timer = topItems.any { Regex("^\\s*\\d{1,2}:\\d{2}\\s*$").matches(it.text.trim()) }
        val scoreItems = topItems.filter {
            Regex("^\\s*\\d{1,6}\\s*$").matches(it.text.trim()) &&
                it.cx.toDouble() / width in 0.08..0.92
        }

        // Dois blocos de pontuação em lados opostos do topo é forte evidência de batalha.
        var opposingScores = false
        for (a in scoreItems) for (b in scoreItems) {
            if (a === b) continue
            val xa = a.cx.toDouble() / width
            val xb = b.cx.toDouble() / width
            val yDiff = abs(a.cy - b.cy).toDouble() / height
            if (((xa < 0.45 && xb > 0.55) || (xb < 0.45 && xa > 0.55)) && yDiff < 0.08) {
                opposingScores = true
            }
        }

        val strong = (hasPkWord && (hasVs || hasBattleWord || (timer && opposingScores))) ||
            (hasVs && hasBattleWord && (timer || opposingScores))

        return when {
            strong -> PkReading(true, "ALTA")
            hasPkWord || hasVs || hasBattleWord -> PkReading(false, "INSUFICIENTE")
            else -> PkReading(false, "DESLIGADO")
        }
    }
}
