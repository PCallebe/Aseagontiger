package com.example.siyaheatradar

import android.content.Context
import java.util.Locale

/**
 * Aprende nomes adicionais que aparecem dentro da aba Afortunados.
 * Trevo/Rosa/Ovo continuam prioritários, mas outros Afortunados podem
 * ser associados a WIN e se tornar o melhor desempenho observado.
 */
class DynamicAfortunadoRegistry(context: Context) {
    private val prefs = context.getSharedPreferences("radar", Context.MODE_PRIVATE)
    private val learned = linkedSetOf<String>()

    init {
        prefs.getString("dynamic_afortunados_csv", "").orEmpty()
            .split('|')
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .forEach(learned::add)
    }

    fun learn(samples: List<GiftSelectionSample>) {
        var changed = false
        samples.forEach { sample ->
            val n = canonical(sample.gift)
            if (n.isNotBlank() && n !in blocked && learned.add(n)) changed = true
        }
        if (changed) persist()
    }

    fun all(): Set<String> = learned.toSet()

    fun matchText(raw: String): String? {
        val normalized = GiftCatalog.normalizeText(raw)
        return learned.firstOrNull { gift ->
            val display = GiftCatalog.normalizeText(GiftCatalog.displayName(gift))
            val canonical = GiftCatalog.normalizeText(gift.replace('_', ' '))
            (display.length >= 3 && normalized.contains(display)) ||
                (canonical.length >= 3 && normalized.contains(canonical))
        }
    }

    fun isKnown(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        return GiftCatalog.isAfortunado(name) || canonical(name) in learned
    }

    private fun canonical(raw: String): String =
        raw.trim().uppercase(Locale.ROOT)
            .replace(Regex("[^A-Z0-9À-Ü ]+"), " ")
            .replace(Regex("\\s+"), "_")
            .trim('_')

    private fun persist() {
        prefs.edit().putString("dynamic_afortunados_csv", learned.joinToString("|")).apply()
    }

    companion object {
        private val blocked = setOf(
            "PRESENTES", "AFORTUNADOS", "TOKEN", "CELEBRIDADE",
            "RECARREGAR", "NOBREZA", "ENVIAR", "RANKING", "JACKPOT",
            "TODOS", "ALL", "LUCKY"
        )
    }
}
