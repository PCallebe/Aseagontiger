package com.example.siyaheatradar

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class SiyaAnalyzerService : AccessibilityService() {

    private companion object {
        const val SIYA_PACKAGE = "com.zr.siya"
        const val NORMAL_INTERVAL_MS = 1_050L
        const val EVENT_THROTTLE_MS = 500L
        const val SCREENSHOT_HIDE_MS = 28L
        const val ROOM_IDENTITY_GRACE_MS = 8_000L
        const val INITIAL_EXTRA_CAPTURES = 2
        const val INITIAL_BURST_DELAY_MS = 260L
    }

    private val parser = SiyaScreenParser()
    private val luckyVision = LuckyLightVision()
    private val giftVision = GiftVision()
    private lateinit var liveGiftVision: LiveGiftVision
    private val winVision = WinVision()
    private val majorPopupVision = MajorPopupVision()
    private val luckyPopupAccumulator = LuckyPopupAccumulator()
    private val chairVision = ChairVision()
    private val pkVision = PkVision()
    private val payoutVision = PayoutVision()
    private lateinit var jackpotVision: JackpotVision
    private val frameGate = FrameGate()
    private val strategyVision = StrategyVision()
    private val roomRadars = mutableMapOf<String, RadarEngine>()
    private val globalScrollRadar = RadarEngine()
    private val roomSignalTrackers = mutableMapOf<String, RoomSignalTracker>()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)

    private var overlay: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var overlayWindowManager: WindowManager? = null
    private var headline: TextView? = null
    private var details: TextView? = null
    private var overlayPanel: LinearLayout? = null
    private var overlayHandle: TextView? = null
    private var overlayExpanded = false
    private var lastRoomBannerSavedAt = 0L
    private var lastRoomBannerKey: String? = null
    private var currentPackage: String? = null
    private var captureCount = 0L
    private var errorCount = 0L
    private var lastCaptureStartedAt = 0L

    private lateinit var roomHistory: RoomHistoryStore
    private lateinit var globalJackpotHistory: GlobalJackpotHistory
    private lateinit var eventDb: EventDatabase
    private var dbSessionId: String? = null
    private val dataSignatures = LinkedHashMap<String, Long>()
    private var lastGlobalJackpotStored = 0L
    private var currentRoom = "Detectando sala..."
    private var currentRoomId: String? = null
    private var pendingRoom: String? = null
    private var pendingRoomId: String? = null
    private var pendingRoomHits = 0
    private var pendingNameForCurrentId: String? = null
    private var pendingNameHits = 0
    private var activeRoomKey: String? = null
    private var lastRoomIdentitySeenAt = 0L
    private var initialBurstRemaining = 0
    private var roomUiMisses = 0
    private var lastTargetPackage: String? = null
    private var lastEngineResetToken = 0L
    private var roomDetectionBurstUntil = 0L
    private var roomDetectionStartedAt = 0L
    private var roomSessionLatched = false
    private var roomMissStreak = 0
    private var recentAfortunado: String? = null
    private var recentAfortunadoAt = 0L
    private var recentAfortunadoQty = 0
    private var pendingForceProcessing = false
    private var lastOverlayPayload = ""
    private var lastPkPersisted = "DESLIGADO"
    private var jackpotPanelActiveUntil = 0L
    private var lastDragonTigerVisibleSequence = ""
    private var lastDragonTigerOverlayAt = 0L

    private val ticker = object : Runnable {
        override fun run() {
            processEngineResetIfRequested()
            val now = System.currentTimeMillis()
            captureAutomatically(force = now < roomDetectionBurstUntil)
            main.postDelayed(this, NORMAL_INTERVAL_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putBoolean("service_active", true)
            .putString("target_package", SIYA_PACKAGE)
            .putString("room_phase", "AGUARDANDO SALA")
            .putInt("room_rocket_stage", 1)
            .putInt("rocket_reference_count", 1)
            .putInt("snapshot_interval_sec", getSharedPreferences("radar", MODE_PRIVATE).getInt("snapshot_interval_sec", 60))
            .apply()

        roomHistory = RoomHistoryStore(this)
        globalJackpotHistory = GlobalJackpotHistory(this)
        eventDb = EventDatabase(this)
        liveGiftVision = LiveGiftVision(this)
        jackpotVision = JackpotVision(this)

        val radarPrefs = getSharedPreferences("radar", MODE_PRIVATE)
        currentRoom = radarPrefs.getString("current_room", "Detectando sala...")
            ?: "Detectando sala..."
        currentRoomId = radarPrefs.getString("current_room_id", null)
        captureCount = radarPrefs.getLong("capture_count", 0L)
        errorCount = radarPrefs.getLong("error_count", 0L)

        showOverlay()
        setOverlayVisible(false)
        main.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val eventPackage = event?.packageName?.toString()
        if (!eventPackage.isNullOrBlank()) currentPackage = eventPackage

        val radarPrefs = getSharedPreferences("radar", MODE_PRIVATE)
        radarPrefs.edit()
            .putString("last_event_package", eventPackage ?: currentPackage ?: "desconhecido")
            .apply()

        val foreground = activeForegroundPackage()
        radarPrefs.edit()
            .putString("foreground_package", foreground ?: currentPackage ?: "desconhecido")
            .apply()

        if (!isTargetPackage(foreground)) {
            val ownAppVisible = foreground == packageName
            setOverlayVisible(ownAppVisible)
            saveHeartbeat("🟢 AUTO conectado • aguardando SIYA / SIYA Lite")
            if (!ownAppVisible) setRoomPhase("AGUARDANDO SIYA")
            return
        }

        handleTargetPackageChange(foreground!!)
        setOverlayVisible(true)
        saveHeartbeat("📡 ${friendlyTargetName(foreground)} visível • leitura automática ativa")

        val eventText = buildString {
            event?.text?.forEach { if (!it.isNullOrBlank()) append(it).append(' ') }
            event?.contentDescription?.let { append(it) }
        }
        activeRoomKey?.let { key ->
            roomSignalTrackers.getOrPut(key) { RoomSignalTracker() }
                .ingestAccessibility(event?.eventType ?: 0, eventText, System.currentTimeMillis())
        }

        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            event?.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            event?.eventType == AccessibilityEvent.TYPE_VIEW_SELECTED
        ) {
            main.post { captureAutomatically(force = System.currentTimeMillis() < roomDetectionBurstUntil) }
        }
    }

    override fun onInterrupt() = Unit

    private fun configuredTargetPackages(): Set<String> {
        val raw = getSharedPreferences("radar", MODE_PRIVATE)
            .getString("custom_siya_packages", "").orEmpty()
        return raw.split(',').map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }

    private fun isTargetPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (pkg == SIYA_PACKAGE) return true
        if (configuredTargetPackages().contains(pkg)) return true
        // SIYA Lite e variantes normalmente preservam "siya" no package.
        return pkg.lowercase().contains("siya")
    }

    private fun friendlyTargetName(pkg: String): String = when {
        pkg == SIYA_PACKAGE -> "SIYA"
        pkg.lowercase().contains("lite") -> "SIYA Lite"
        else -> "SIYA"
    }

    private fun activeForegroundPackage(): String? {
        try {
            // A janela realmente ativa/focada do SIYA ou SIYA Lite ganha prioridade.
            windows.firstOrNull { window ->
                val pkg = window.root?.packageName?.toString()
                (window.isActive || window.isFocused) && isTargetPackage(pkg)
            }?.root?.packageName?.toString()?.let { return it }
        } catch (_: Throwable) { }

        val fromRoot = try { rootInActiveWindow?.packageName?.toString() } catch (_: Throwable) { null }
        if (!fromRoot.isNullOrBlank()) return fromRoot

        try {
            // Alguns Xiaomi/HyperOS mantêm a janela SIYA como interativa mesmo quando
            // o root ativo oscila durante troca de conta/painéis. Recupera sem matar o motor.
            windows.firstOrNull { window ->
                val pkg = window.root?.packageName?.toString()
                isTargetPackage(pkg) && window.root != null
            }?.root?.packageName?.toString()?.let { return it }
        } catch (_: Throwable) { }

        val fromWindow = try {
            windows.firstOrNull { it.isActive || it.isFocused }?.root?.packageName?.toString()
        } catch (_: Throwable) { null }
        if (!fromWindow.isNullOrBlank()) return fromWindow

        return currentPackage
    }

    private fun shouldShowOverlay(): Boolean {
        val fg = activeForegroundPackage()
        return isTargetPackage(fg) || fg == packageName
    }

    private fun isSiyaForeground(): Boolean = isTargetPackage(activeForegroundPackage())

    private fun handleTargetPackageChange(pkg: String) {
        val previous = lastTargetPackage
        if (previous == pkg) return
        lastTargetPackage = pkg
        beginRoomDetectionBurst()
        getSharedPreferences("radar", MODE_PRIVATE).edit()
            .putString("active_siya_package", pkg)
            .putString("active_siya_name", friendlyTargetName(pkg))
            .apply()

        if (previous != null && previous != pkg) {
            // Troca SIYA <-> SIYA Lite: encerra apenas a sessão lógica da sala.
            // A Acessibilidade e o motor continuam ligados e recomeçam a detectar.
            if (::eventDb.isInitialized) eventDb.endSession(dbSessionId)
            dbSessionId = null
            activeRoomKey = null
            currentRoom = "Detectando sala..."
            currentRoomId = null
            pendingRoom = null
            pendingRoomId = null
            pendingRoomHits = 0
            roomUiMisses = 0
            roomMissStreak = 0
            roomSessionLatched = false
            initialBurstRemaining = 0
            liveGiftVision.reset()
            winVision.reset()
            majorPopupVision.reset()
            luckyPopupAccumulator.reset()
            chairVision.reset()
            payoutVision.reset()
            jackpotVision.resetTransient()
            frameGate.reset()
            recentAfortunado = null
            recentAfortunadoAt = 0L
            recentAfortunadoQty = 0
            setRoomPhase("REDETECTANDO APÓS TROCA DE APP")
            persistCurrentRoom()
        }
    }

    private fun processEngineResetIfRequested() {
        val radarPrefs = getSharedPreferences("radar", MODE_PRIVATE)
        val token = radarPrefs.getLong("engine_reset_token", 0L)
        if (token <= 0L || token == lastEngineResetToken) return
        lastEngineResetToken = token

        if (::eventDb.isInitialized) eventDb.endSession(dbSessionId)
        dbSessionId = null
        activeRoomKey = null
        currentRoom = "Detectando sala..."
        currentRoomId = null
        pendingRoom = null
        pendingRoomId = null
        pendingRoomHits = 0
        pendingNameForCurrentId = null
        pendingNameHits = 0
        roomUiMisses = 0
        roomMissStreak = 0
        roomSessionLatched = false
        initialBurstRemaining = 0
        liveGiftVision.reset()
        winVision.reset()
        majorPopupVision.reset()
        luckyPopupAccumulator.reset()
        chairVision.reset()
        payoutVision.reset()
        jackpotVision.resetTransient()
        frameGate.reset()
        recentAfortunado = null
        recentAfortunadoAt = 0L
        recentAfortunadoQty = 0
        roomSignalTrackers.values.forEach { it.resetTransient() }
        persistCurrentRoom()
        setRoomPhase("REDETECTANDO")
        saveHeartbeat("🔄 Motor lógico reiniciado • Acessibilidade continua ativa")
    }

    private fun hasWhatsAppWindow(): Boolean {
        return try {
            windows.any { window ->
                val pkg = window.root?.packageName?.toString().orEmpty()
                pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun captureAutomatically(force: Boolean = false) {
        if (!isSiyaForeground()) {
            // Não destrói a sessão só porque o usuário minimizou/trocou de app.
            // Ao voltar ao SIYA a leitura retoma; se for outra sala, o ID/nome troca a sessão.
            setOverlayVisible(shouldShowOverlay())
            saveHeartbeat("🟢 AUTO conectado • aguardando SIYA / SIYA Lite")
            if (activeForegroundPackage() != packageName) setRoomPhase("AGUARDANDO SIYA")
            return
        }

        val now = System.currentTimeMillis()
        val effectiveForce = force || now < jackpotPanelActiveUntil
        if (!effectiveForce && now - lastCaptureStartedAt < EVENT_THROTTLE_MS) return
        if (busy.getAndSet(true)) return
        lastCaptureStartedAt = now
        pendingForceProcessing = effectiveForce

        // Esconde só pelo instante necessário para tirar o screenshot.
        // Assim o painel não contamina o OCR e deixa de piscar durante todo o processamento.
        setOverlayVisible(false)
        main.postDelayed({
            if (!isSiyaForeground()) {
                busy.set(false)
                setOverlayVisible(false)
                return@postDelayed
            }
            doScreenshot(pendingForceProcessing)
        }, SCREENSHOT_HIDE_MS)
    }

    private fun doScreenshot(forceProcessing: Boolean) {
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : TakeScreenshotCallback {

                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val bmp = toBitmap(screenshot)

                        // O screenshot já foi obtido. O painel pode voltar imediatamente,
                        // sem esperar o ML Kit terminar o OCR.
                        setOverlayVisible(shouldShowOverlay())

                        if (bmp == null) {
                            registerError("Falha ao converter screenshot")
                            busy.set(false)
                            scheduleInitialBurstIfNeeded()
                            return
                        }

                        // Proteção contra troca de app exatamente entre o pedido e a captura.
                        if (!isSiyaForeground()) {
                            bmp.recycle()
                            busy.set(false)
                            setOverlayVisible(false)
                            return
                        }

                        // Dragon Tiger mode: inspect the visible colored bead-history strip on every screenshot.
                        try {
                            val gameRead = DragonTigerVision.detect(bmp)
                            if (gameRead != null) updateDragonTigerAnalysis(gameRead.sequence)
                        } catch (_: Throwable) { }

                        val frameNowPreOcr = System.currentTimeMillis()
                        if (!frameGate.shouldProcess(bmp, frameNowPreOcr, forceProcessing)) {
                            bmp.recycle()
                            busy.set(false)
                            setOverlayVisible(shouldShowOverlay())
                            scheduleInitialBurstIfNeeded()
                            return
                        }

                        recognizer.process(InputImage.fromBitmap(bmp, 0))
                            .addOnSuccessListener { result ->
                                captureCount++

                                val ocrItems = flatten(result)
                                val accessibilityItems = collectAccessibilityItems()
                                val items = mergeItems(ocrItems, accessibilityItems)
                                val runtimePrefs = getSharedPreferences("radar", MODE_PRIVATE)
                                val lightSamples = if (runtimePrefs.getBoolean("monitor_lucky", true)) {
                                    luckyVision.measure(bmp, items)
                                } else emptyList()
                                val giftRead = giftVision.measure(bmp, items)
                                val strategyRead = strategyVision.measure(items)
                                val frameNow = System.currentTimeMillis()
                                val parsedRead = parser.parse(
                                    items = items,
                                    width = bmp.width,
                                    height = bmp.height,
                                    now = frameNow,
                                    luckyLights = lightSamples,
                                    selectedGift = giftRead.selectedGift,
                                    giftPanelVisible = giftRead.panelVisible
                                )
                                val dedicatedWins = winVision.detect(items, bmp.width, bmp.height, frameNow)
                                val majorPopupHits = majorPopupVision.detect(
                                    bitmap = bmp,
                                    items = items,
                                    width = bmp.width,
                                    height = bmp.height,
                                    now = frameNow,
                                    afortunadosPanelVisible = giftRead.panelVisible || parsedRead.giftPanelVisible
                                )
                                majorPopupHits.filter { it.yellow }.forEach {
                                    luckyPopupAccumulator.ingest(it, frameNow)
                                }
                                val popupWins = majorPopupHits.map {
                                    WinHit(it.multiplier, "MP:${it.signature}")
                                }
                                val fallbackWins = (dedicatedWins + popupWins).filter { extra ->
                                    parsedRead.wins.none { kotlin.math.abs(it.multiplier - extra.multiplier) < 0.001 }
                                }
                                val allWins = (parsedRead.wins + fallbackWins)
                                    .distinctBy { "${it.multiplier}:${it.positionKey}" }

                                val strictPayout = payoutVision.detect(items, bmp.width, bmp.height, frameNow)
                                val jackpotReading = jackpotVision.detect(items, bmp.width, bmp.height, frameNow)
                                if (jackpotReading.panelVisible) {
                                    // Enquanto Afortunados/LUCKY estiver aberto, não deixa o FrameGate
                                    // "congelar" o contador: continua lendo o Jackpot conforme ele varia.
                                    jackpotPanelActiveUntil = frameNow + 4_000L
                                }

                                val enhancedRead = parsedRead.copy(
                                    payout = strictPayout,
                                    jackpotBanner = jackpotReading.panelVisible,
                                    jackpotValue = jackpotReading.confirmedValue,
                                    wins = allWins,
                                    maxMultiplier = allWins.maxOfOrNull { it.multiplier },
                                    rawSignals = parsedRead.rawSignals +
                                        dedicatedWins.map { "WINVISION_X${it.multiplier}" } +
                                        majorPopupHits.map {
                                            "MAJOR_POPUP_X${it.multiplier}_${if (it.yellow) "AMARELO" else "LATERAL"}"
                                        } +
                                        (strictPayout?.let { listOf("PAYOUT_CONFIRMADO_$it") } ?: emptyList()) +
                                        (jackpotReading.confirmedValue?.let { listOf("JACKPOT_CONFIRMADO_$it") } ?: emptyList())
                                )
                                val read = improveRoomRead(enhancedRead, items, bmp.width, bmp.height)
                                if (giftRead.panelVisible && giftRead.samples.isNotEmpty()) {
                                    dynamicAfortunados.learn(giftRead.samples)
                                }

                                val liveGiftEvents = if (runtimePrefs.getBoolean("monitor_gifts", true)) {
                                    liveGiftVision.detect(
                                        bmp, items, bmp.width, bmp.height, frameNow,
                                        dynamicAfortunados.all()
                                    )
                                } else emptyList()
                                val chairReading = chairVision.detect(items, bmp.width, bmp.height)
                                val pkReading = pkVision.detect(items, bmp.width, bmp.height)

                                if (read.roomUiConfirmed || roomSessionLatched) {
                                    saveRoomBanner(bmp, read.roomName ?: currentRoom, read.roomId ?: currentRoomId)
                                    persistSeatStatus(items, bmp.width, bmp.height, true)
                                }

                                // REGRA OFICIAL: só computa dados quando existe uma sessão de SALA.
                                // Rolagem e poltrona dentro da sala alimentam a mesma sessão.
                                // Fora da sala o motor fica aguardando, sem criar estatística GLOBAL.
                                val belongsToConfirmedRoom = when {
                                    read.roomUiConfirmed -> {
                                        roomMissStreak = 0
                                        val ok = if (activeRoomKey != null && read.roomName == null && read.roomId == null) {
                                            true
                                        } else {
                                            resolveRoom(read.roomName, read.roomId)
                                        }
                                        if (ok) roomSessionLatched = true
                                        ok
                                    }
                                    roomSessionLatched && activeRoomKey != null && runtimePrefs.getBoolean("monitor_global", true) -> {
                                        roomMissStreak++
                                        if (isClearlyOutsideRoom(items, bmp.width, bmp.height) && roomMissStreak >= 5) {
                                            endCurrentRoomSession("AGUARDANDO SALA")
                                            false
                                        } else {
                                            // Cabeçalho pode sumir durante rolagem/painéis internos; mantém a sala atual.
                                            true
                                        }
                                    }
                                    else -> {
                                        roomMissStreak++
                                        false
                                    }
                                }

                                if (!belongsToConfirmedRoom) {
                                    setRoomPhase("AGUARDANDO SALA")
                                    getSharedPreferences("radar", MODE_PRIVATE).edit()
                                        .putString("monitor_context", "AGUARDANDO SALA")
                                        .putString("room_seat_status", "DETECTANDO")
                                        .apply()
                                    saveLightRead(read)
                                    return@addOnSuccessListener
                                }

                                roomUiMisses = 0
                                getSharedPreferences("radar", MODE_PRIVATE)
                                    .edit()
                                    .putString("monitor_context", "SALA")
                                    .apply()

                                val roomKey = RoomHistoryStore.key(currentRoom, currentRoomId)
                                val priorRoomHistory = if (currentRoom != "Detectando sala...") {
                                    roomHistory.get(currentRoom, currentRoomId)
                                } else null
                                val analysisHistory = globalJackpotHistory.mergeIntoRoomHistory(priorRoomHistory)
                                val radar = roomRadars.getOrPut(roomKey) {
                                    RadarEngine().apply { restoreGift(priorRoomHistory?.lastGift) }
                                }
                                val baseState = radar.ingest(read, history = analysisHistory)
                                val roomSignals = roomSignalTrackers.getOrPut(roomKey) { RoomSignalTracker() }
                                roomSignals.ingestLiveGifts(liveGiftEvents, frameNow)
                                roomSignals.ingestChairs(chairReading)
                                roomSignals.ingestPk(pkReading, frameNow)
                                persistPkTransition(roomKey, pkReading, frameNow)
                                liveGiftEvents.lastOrNull { it.isAfortunado }?.let { giftEvent ->
                                    recentAfortunado = giftEvent.name
                                    recentAfortunadoAt = frameNow
                                    recentAfortunadoQty = giftEvent.burstTotal ?: giftEvent.quantity
                                }
                                persistLiveGiftEvents(roomKey, liveGiftEvents, strategyRead, frameNow)
                                persistMajorPopupEvents(roomKey, majorPopupHits, strategyRead, frameNow)
                                roomSignals.ingestOcr(
                                    items = items,
                                    width = bmp.width,
                                    height = bmp.height,
                                    strategy = strategyRead,
                                    giftPanelVisible = giftRead.panelVisible,
                                    now = System.currentTimeMillis()
                                )
                                val signalSettings = RoomSignalSettings(
                                    emojis = runtimePrefs.getBoolean("monitor_emojis", true),
                                    gifts = runtimePrefs.getBoolean("monitor_gifts", true),
                                    rocket = runtimePrefs.getBoolean("monitor_rocket", true),
                                    pk = runtimePrefs.getBoolean("monitor_pk", true),
                                    people = runtimePrefs.getBoolean("monitor_people", true),
                                    scroll = runtimePrefs.getBoolean("monitor_scroll", true),
                                    snapshotIntervalSeconds = runtimePrefs.getInt("snapshot_interval_sec", 60)
                                )
                                val signalState = roomSignals.snapshot(
                                    baseHeat = baseState.heatScore,
                                    baseTrend = baseState.trend,
                                    peopleCount = strategyRead.peopleCount,
                                    now = System.currentTimeMillis(),
                                    settings = signalSettings
                                )
                                val state = baseState.copy(
                                    heatScore = signalState.effectiveHeat,
                                    state = signalState.heatState,
                                    trend = signalState.combinedTrend
                                )

                                val remembered = if (currentRoom != "Detectando sala...") {
                                    roomHistory.record(
                                        roomName = currentRoom,
                                        roomId = currentRoomId,
                                        read = read,
                                        state = state
                                    )
                                } else null

                                globalJackpotHistory.record(read, state)
                                persistDataEngine(read, state, strategyRead)
                                update(state, read, remembered, signalState)
                            }
                            .addOnFailureListener { e ->
                                registerError("OCR: ${e.javaClass.simpleName}")
                            }
                            .addOnCompleteListener {
                                bmp.recycle()
                                busy.set(false)
                                setOverlayVisible(shouldShowOverlay())
                                scheduleInitialBurstIfNeeded()
                            }
                    }

                    override fun onFailure(errorCode: Int) {
                        registerError("Screenshot erro $errorCode")
                        busy.set(false)
                        setOverlayVisible(shouldShowOverlay())
                        scheduleInitialBurstIfNeeded()
                    }
                }
            )
        } catch (e: Throwable) {
            registerError("Captura: ${e.javaClass.simpleName}")
            busy.set(false)
            setOverlayVisible(shouldShowOverlay())
            scheduleInitialBurstIfNeeded()
        }
    }

    private fun flatten(text: Text): List<OcrItem> {
        val out = mutableListOf<OcrItem>()

        for (block in text.textBlocks) {
            for (line in block.lines) {
                line.boundingBox?.let {
                    out += OcrItem(line.text, it)
                }

                for (element in line.elements) {
                    element.boundingBox?.let {
                        out += OcrItem(element.text, it)
                    }
                }
            }
        }

        return out
    }

    /**
     * Retorna true somente quando a captura pode ser atribuída com segurança
     * à sala atual. Isso impede que a primeira captura de uma nova sala seja
     * somada por engano à sala anterior.
     */
    private fun resolveRoom(candidateRaw: String?, candidateIdRaw: String?): Boolean {
        val now = System.currentTimeMillis()
        val candidateName = candidateRaw
            ?.replace(Regex("""\s+"""), " ")
            ?.trim()
            ?.takeIf { it.length >= 3 }

        val candidateId = candidateIdRaw
            ?.replace(Regex("""\D+"""), "")
            ?.takeIf { it.length >= 5 }

        if (candidateName == null && candidateId == null) {
            val recentIdentity = now - lastRoomIdentitySeenAt <= ROOM_IDENTITY_GRACE_MS
            if (!recentIdentity) {
                activeRoomKey = null
                setRoomPhase("AGUARDANDO SALA")
            }
            return currentRoom != "Detectando sala..." && recentIdentity
        }

        // Se já temos ID da sala, ele é a identidade principal. Um texto estranho
        // no topo (ligação, notificação, nome de contato) não cria outra sala.
        if (!currentRoomId.isNullOrBlank()) {
            if (candidateId == currentRoomId) {
                lastRoomIdentitySeenAt = now
                stabilizeCurrentRoomName(candidateName)
                clearPendingRoom()
                activateRoomIfNeeded()
                return true
            }

            if (candidateId == null) {
                if (candidateName == currentRoom) {
                    lastRoomIdentitySeenAt = now
                    clearPendingRoom()
                    activateRoomIfNeeded()
                    return true
                }

                // Se houver uma janela flutuante do WhatsApp, nunca usa um nome
                // isolado para trocar de sala. Mantém o ID confirmado como âncora.
                if (hasWhatsAppWindow()) {
                    clearPendingRoom()
                    return now - lastRoomIdentitySeenAt <= ROOM_IDENTITY_GRACE_MS
                }

                // Fallback: se o ID ficar temporariamente ilegível, um nome novo
                // precisa aparecer 4 vezes seguidas antes de trocar. Isso mantém a
                // troca de sala funcional sem depender 100% do OCR do ID.
                if (candidateName != null) {
                    val pendingKey = pendingRoom?.let { RoomHistoryStore.key(it, pendingRoomId) }
                    val newKey = RoomHistoryStore.key(candidateName, null)
                    if (pendingKey == newKey) {
                        pendingRoomHits++
                    } else {
                        pendingRoom = candidateName
                        pendingRoomId = null
                        pendingRoomHits = 1
                    }

                    if (pendingRoomHits >= 4 &&
                        (activeRoomKey == null || now - lastRoomIdentitySeenAt > 2_500L)
                    ) {
                        switchRoom(candidateName, null, now)
                        return true
                    }
                }

                return now - lastRoomIdentitySeenAt <= ROOM_IDENTITY_GRACE_MS
            }

            // ID diferente = nova sala confirmada. Troca imediatamente.
            switchRoom(
                candidateName ?: "Sala ID $candidateId",
                candidateId,
                now
            )
            return true
        }

        // Ainda sem ID salvo. Se aparecer um ID válido, ele confirma a sala imediatamente.
        if (candidateId != null) {
            switchRoom(
                candidateName ?: currentRoom.takeIf { it != "Detectando sala..." }
                    ?: "Sala ID $candidateId",
                candidateId,
                now
            )
            return true
        }

        val candidateDisplay = candidateName ?: return false
        val candidateKey = RoomHistoryStore.key(candidateDisplay, null)
        val currentKey = RoomHistoryStore.key(currentRoom, currentRoomId)

        if (candidateKey == currentKey) {
            currentRoom = candidateDisplay
            lastRoomIdentitySeenAt = now
            clearPendingRoom()
            activateRoomIfNeeded()
            return true
        }

        // Sem ID, exige duas leituras seguidas do mesmo nome. A primeira captura
        // não é registrada em sala nenhuma, evitando contaminar a anterior.
        val pendingKey = pendingRoom?.let { RoomHistoryStore.key(it, pendingRoomId) }
        if (pendingKey == candidateKey) {
            pendingRoomHits++
        } else {
            pendingRoom = candidateDisplay
            pendingRoomId = null
            pendingRoomHits = 1
        }

        if (pendingRoomHits >= 2) {
            switchRoom(candidateDisplay, null, now)
            return true
        }

        setRoomPhase("CONFIRMANDO NOVA SALA")
        return false
    }

    private fun stabilizeCurrentRoomName(candidateName: String?) {
        if (candidateName.isNullOrBlank() || candidateName == currentRoom) {
            pendingNameForCurrentId = null
            pendingNameHits = 0
            return
        }

        if (currentRoom.startsWith("Sala ID ")) {
            currentRoom = candidateName
            persistCurrentRoom()
            pendingNameForCurrentId = null
            pendingNameHits = 0
            return
        }

        if (pendingNameForCurrentId == candidateName) {
            pendingNameHits++
        } else {
            pendingNameForCurrentId = candidateName
            pendingNameHits = 1
        }

        // Nome só muda depois de repetido. O ID continua sendo a chave real.
        if (pendingNameHits >= 3) {
            currentRoom = candidateName
            persistCurrentRoom()
            pendingNameForCurrentId = null
            pendingNameHits = 0
        }
    }

    private fun switchRoom(name: String, id: String?, now: Long) {
        if (::eventDb.isInitialized) {
            eventDb.endSession(dbSessionId)
            dbSessionId = null
        }
        currentRoom = name
        currentRoomId = id
        lastRoomIdentitySeenAt = now
        roomSessionLatched = true
        roomMissStreak = 0
        liveGiftVision.reset()
        winVision.reset()
        majorPopupVision.reset()
        luckyPopupAccumulator.reset()
        chairVision.reset()
        payoutVision.reset()
        jackpotVision.resetTransient()
        frameGate.reset()
        recentAfortunado = null
        recentAfortunadoAt = 0L
        recentAfortunadoQty = 0
        lastPkPersisted = "DESLIGADO"
        beginRoomDetectionBurst() // até 5s somente na CHEGADA/TROCA de sala
        getSharedPreferences("radar", MODE_PRIVATE).edit()
            .putLong("room_auto_updated_at", now)
            .putLong("last_confirmed_payout", 0L)
            .putLong("last_confirmed_payout_at", 0L)
            .putString("last_confirmed_payout_type", "")
            .putString("room_pk_status", "DESLIGADO")
            .apply()
        clearPendingRoom()
        pendingNameForCurrentId = null
        pendingNameHits = 0
        activeRoomKey = null
        persistCurrentRoom(now)
        activateRoomIfNeeded()
    }

    private fun activateRoomIfNeeded() {
        if (currentRoom == "Detectando sala...") return

        val key = RoomHistoryStore.key(currentRoom, currentRoomId)
        if (activeRoomKey == key) return

        activeRoomKey = key
        initialBurstRemaining = INITIAL_EXTRA_CAPTURES

        roomHistory.onRoomEntered(
            roomName = currentRoom,
            roomId = currentRoomId
        )

        if (::eventDb.isInitialized) {
            eventDb.endSession(dbSessionId)
            dbSessionId = eventDb.startSession(
                roomKey = key,
                roomName = currentRoom,
                roomId = currentRoomId
            )
        }

        setRoomPhase("LEITURA INICIAL")
        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putLong("room_entered_at", System.currentTimeMillis())
            .apply()

        main.post {
            val id = currentRoomId?.let { " • ID $it" } ?: ""
            headline?.text = "📥 NOVA SALA • $currentRoom$id"
            details?.text = "Leitura inicial em andamento • depois atualiza automaticamente"
        }
    }

    private fun scheduleInitialBurstIfNeeded() {
        if (initialBurstRemaining <= 0) {
            if (activeRoomKey != null) setRoomPhase("MONITORANDO")
            return
        }
        if (!isSiyaForeground() || activeRoomKey == null) {
            initialBurstRemaining = 0
            return
        }

        initialBurstRemaining--
        main.postDelayed({
            if (isSiyaForeground() && activeRoomKey != null) {
                captureAutomatically(force = true)
            }
        }, INITIAL_BURST_DELAY_MS)
    }

    private fun clearPendingRoom() {
        pendingRoom = null
        pendingRoomId = null
        pendingRoomHits = 0
    }

    private fun persistCurrentRoom(changedAt: Long = System.currentTimeMillis()) {
        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putString("current_room", currentRoom)
            .putString("current_room_id", currentRoomId)
            .putLong("room_changed_at", changedAt)
            .apply()
    }

    private fun setRoomPhase(phase: String) {
        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putString("room_phase", phase)
            .apply()
    }

    private fun saveLightRead(read: ScreenRead) {
        val signals = if (read.rawSignals.isEmpty()) "nenhum sinal" else read.rawSignals.joinToString(" • ")
        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putLong("capture_count", captureCount)
            .putLong("last_read_at", System.currentTimeMillis())
            .putString("last_signals", signals)
            .putLong("error_count", errorCount)
            .apply()
    }


    private fun persistLiveGiftEvents(
        roomKey: String,
        events: List<LiveGiftEvent>,
        strategy: StrategyRead,
        now: Long
    ) {
        if (!::eventDb.isInitialized || events.isEmpty()) return
        events.forEach { gift ->
            val sig = "LIVE_GIFT:$roomKey:${gift.signature}"
            val previous = dataSignatures[sig] ?: 0L
            if (now - previous < 700L) return@forEach
            dataSignatures[sig] = now
            eventDb.addEvent(
                ts = now,
                roomKey = roomKey,
                roomName = currentRoom,
                roomId = currentRoomId,
                sessionId = dbSessionId,
                type = if (gift.isAfortunado) "GIFT_AFORTUNADO" else "GIFT_NORMAL",
                value = gift.quantity.toLong(),
                gift = gift.name,
                giftCount = gift.burstTotal ?: gift.quantity,
                peopleCount = strategy.peopleCount,
                signature = sig
            )
        }
    }

    private fun persistPkTransition(roomKey: String, reading: PkReading, now: Long) {
        val status = if (reading.active) "ATIVO" else "DESLIGADO"
        if (status == lastPkPersisted) return
        lastPkPersisted = status
        if (::eventDb.isInitialized) {
            eventDb.addEvent(
                ts = now,
                roomKey = roomKey,
                roomName = currentRoom,
                roomId = currentRoomId,
                sessionId = dbSessionId,
                type = if (reading.active) "PK_ON" else "PK_OFF",
                signature = "PK:$roomKey:$status:${now / 1000L}"
            )
        }
        getSharedPreferences("radar", MODE_PRIVATE).edit()
            .putString("room_pk_status", status)
            .putString("room_pk_confidence", reading.confidence)
            .putLong("room_pk_updated_at", now)
            .apply()
    }

    private fun isClearlyOutsideRoom(items: List<OcrItem>, width: Int, height: Int): Boolean {
        val all = items.joinToString(" ") { it.text }.lowercase()
        val roomMarkers = listOf(
            "conversar", "presente", "todos", "rocket", "top diário", "top diario",
            "ranking", "diga algo", "afortunados", "pk", "microfone"
        ).count { all.contains(it) }
        if (roomMarkers >= 2) return false

        val outsideMarkers = listOf(
            "explorar", "descobrir", "recomendados", "seguindo", "mensagens",
            "perfil", "salas populares", "buscar salas", "criar sala"
        ).count { all.contains(it) }
        return outsideMarkers >= 2
    }

    private fun endCurrentRoomSession(phase: String) {
        if (::eventDb.isInitialized) {
            eventDb.endSession(dbSessionId)
            dbSessionId = null
        }
        activeRoomKey = null
        roomSessionLatched = false
        roomMissStreak = 0
        initialBurstRemaining = 0
        currentRoom = "Detectando sala..."
        currentRoomId = null
        liveGiftVision.reset()
        winVision.reset()
        majorPopupVision.reset()
        luckyPopupAccumulator.reset()
        chairVision.reset()
        payoutVision.reset()
        jackpotVision.resetTransient()
        frameGate.reset()
        recentAfortunado = null
        recentAfortunadoAt = 0L
        recentAfortunadoQty = 0
        setRoomPhase(phase)
        persistCurrentRoom()
    }

    private fun persistMajorPopupEvents(
        roomKey: String,
        hits: List<MajorPopupHit>,
        strategy: StrategyRead,
        now: Long
    ) {
        if (!::eventDb.isInitialized || hits.isEmpty()) return
        val prefs = getSharedPreferences("radar", MODE_PRIVATE)
        val associatedGift = recentAfortunado?.takeIf {
            now - recentAfortunadoAt <= 12_000L && GiftCatalog.isAfortunado(it)
        }

        hits.forEach { hit ->
            val sig = "POPUP:${hit.signature}"
            val previous = dataSignatures[sig] ?: 0L
            if (now - previous < 3_000L) return@forEach
            dataSignatures[sig] = now

            eventDb.addEvent(
                ts = now,
                roomKey = roomKey,
                roomName = currentRoom,
                roomId = currentRoomId,
                sessionId = dbSessionId,
                type = "WIN_POPUP_MAJOR",
                multiplier = hit.multiplier,
                gift = associatedGift,
                giftCount = if (associatedGift != null && recentAfortunadoQty > 0) recentAfortunadoQty else strategy.giftCount,
                peopleCount = strategy.peopleCount,
                signature = sig
            )

            if (hit.yellow) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = roomKey,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "LUCKY_SELF_MAJOR",
                    multiplier = hit.multiplier,
                    gift = associatedGift,
                    signature = "LUCKY_SELF:$sig"
                )
            }
        }

        val luckyStats = luckyPopupAccumulator.snapshot(now)
        prefs.edit()
            .putInt("lucky_major_hits_1m", luckyStats.hits1m)
            .putInt("lucky_major_sum_1m", luckyStats.sumX1m)
            .putInt("lucky_major_max_1m", luckyStats.maxX1m)
            .putInt("lucky_session_total_x", luckyStats.sessionTotalX)
            .apply()
    }

    private fun persistDataEngine(read: ScreenRead, state: RadarState, strategy: StrategyRead) {
        if (!::eventDb.isInitialized || currentRoom == "Detectando sala...") return

        val now = System.currentTimeMillis()
        val roomKey = RoomHistoryStore.key(currentRoom, currentRoomId)
        val associatedGift = when {
            recentAfortunado != null && now - recentAfortunadoAt <= 12_000L && GiftCatalog.isAfortunado(recentAfortunado) -> recentAfortunado
            GiftCatalog.isAfortunado(state.currentGift) -> state.currentGift
            else -> null
        }
        val associatedGiftCount = if (associatedGift == recentAfortunado && recentAfortunadoQty > 0) recentAfortunadoQty else strategy.giftCount
        eventDb.incrementCapture(dbSessionId)

        fun once(signature: String, cooldown: Long, action: () -> Unit) {
            val previous = dataSignatures[signature] ?: 0L
            if (now - previous >= cooldown) {
                dataSignatures[signature] = now
                action()
            }
        }

        read.wins.forEach { hit ->
            val sig = "WIN:$roomKey:${hit.positionKey}:${hit.multiplier}"
            once(sig, 8_000L) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = roomKey,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "WIN",
                    multiplier = hit.multiplier,
                    gift = associatedGift,
                    giftCount = associatedGiftCount,
                    peopleCount = strategy.peopleCount,
                    signature = sig
                )
                if (hit.multiplier >= 50.0) {
                    eventDb.addEvent(
                        ts = now, roomKey = roomKey, roomName = currentRoom, roomId = currentRoomId,
                        sessionId = dbSessionId, type = "WIN_MAJOR", multiplier = hit.multiplier,
                        gift = associatedGift, giftCount = associatedGiftCount, peopleCount = strategy.peopleCount,
                        signature = "MAJOR:$sig"
                    )
                    if (hit.multiplier >= 500.0) {
                        eventDb.addEvent(
                            ts = now, roomKey = roomKey, roomName = currentRoom, roomId = currentRoomId,
                            sessionId = dbSessionId, type = "WIN_ULTRA", multiplier = hit.multiplier,
                            gift = associatedGift, giftCount = associatedGiftCount, peopleCount = strategy.peopleCount,
                            signature = "ULTRA:$sig"
                        )
                    }
                    getSharedPreferences("radar", MODE_PRIVATE).edit()
                        .putFloat("last_major_win_x", hit.multiplier.toFloat())
                        .putLong("last_major_win_at", now)
                        .apply()
                }
                if (associatedGift != null) {
                    eventDb.addConfigResult(
                        ts = now,
                        roomKey = roomKey,
                        roomName = currentRoom,
                        roomId = currentRoomId,
                        sessionId = dbSessionId,
                        gift = associatedGift,
                        giftCount = associatedGiftCount,
                        peopleCount = strategy.peopleCount,
                        multiplier = hit.multiplier,
                        payout = read.payout ?: 0L
                    )
                }
            }
        }

        read.payout?.let { value ->
            val sig = "PAYOUT:$roomKey:$value"
            once(sig, 20_000L) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = roomKey,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "PAYOUT",
                    value = value,
                    gift = associatedGift,
                    giftCount = associatedGiftCount,
                    peopleCount = strategy.peopleCount,
                    signature = sig
                )
                getSharedPreferences("radar", MODE_PRIVATE).edit()
                    .putLong("last_confirmed_payout", value)
                    .putLong("last_confirmed_payout_at", now)
                    .putString("last_confirmed_payout_type", "PAYOUT")
                    .apply()
            }
        }

        read.previousPayout?.let { value ->
            val sig = "PREVIOUS:$roomKey:$value"
            once(sig, 120_000L) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = roomKey,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "PREVIOUS_PAYOUT",
                    value = value,
                    signature = sig
                )
            }
        }

        state.newLightPulses.forEach { m ->
            val sig = "LUCKY:$roomKey:$m:${now / 2500L}"
            once(sig, 2_000L) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = roomKey,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "LUCKY",
                    multiplier = m.toDouble(),
                    signature = sig
                )
            }
        }

        // JACKPOT: evento GLOBAL. roomKey = null intencionalmente.
        if (read.jackpotBanner) {
            val sig = "JACKPOT_BANNER_GLOBAL"
            once(sig, 25_000L) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = null,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "JACKPOT_GLOBAL",
                    value = read.jackpotValue ?: 0L,
                    signature = sig
                )
            }
        }

        read.jackpotValue?.let { value ->
            getSharedPreferences("radar", MODE_PRIVATE).edit()
                .putLong("jackpot_value", value)
                .putLong("global_jackpot_confirmed", value)
                .putLong("global_jackpot_seen_at", now)
                .apply()
            if (kotlin.math.abs(value - lastGlobalJackpotStored) >= 5_000L || lastGlobalJackpotStored == 0L) {
                lastGlobalJackpotStored = value
                eventDb.addEvent(
                    ts = now,
                    roomKey = null,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "JACKPOT_SAMPLE_GLOBAL",
                    value = value,
                    signature = "JACKPOT_SAMPLE:$value"
                )
            }
        }

        state.jackpotHitValue?.let { hit ->
            val sig = "JACKPOT_HIT_GLOBAL:$hit"
            once(sig, 45_000L) {
                eventDb.addEvent(
                    ts = now,
                    roomKey = null,
                    roomName = currentRoom,
                    roomId = currentRoomId,
                    sessionId = dbSessionId,
                    type = "JACKPOT_HIT_GLOBAL",
                    value = hit,
                    signature = sig
                )
                getSharedPreferences("radar", MODE_PRIVATE).edit()
                    .putLong("last_confirmed_payout", hit)
                    .putLong("last_confirmed_payout_at", now)
                    .putString("last_confirmed_payout_type", "JACKPOT")
                    .putLong("last_jackpot_hit", hit)
                    .apply()
            }
        }

        val maturity = eventDb.maturity(roomKey)
        val strategyText = eventDb.strategyRecommendation(roomKey, state.currentGift)
        val giftPerformance = eventDb.giftPerformance(roomKey)
        val bestGift = eventDb.bestGiftObserved(roomKey)
        val bestOther = giftPerformance.firstOrNull { it.gift !in setOf("TREVO", "ROSA", "OVO") }

        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putString("data_maturity_level", maturity.level)
            .putInt("data_maturity_confidence", maturity.confidence)
            .putLong("data_maturity_seconds", maturity.observedSeconds)
            .putLong("data_maturity_events", maturity.validEvents)
            .putString("data_maturity_note", maturity.note)
            .putString("data_windows", eventDb.windowSummary(roomKey))
            .putString("data_ranking", eventDb.roomRanking24h(6))
            .putString("data_strategy", strategyText)
            .putString("data_config_history", eventDb.configHistory(roomKey))
            .putString("data_global_bank", eventDb.globalSummary())
            .putString("data_global_jackpot", globalJackpotHistory.summary())
            .putString("data_gift_performance", eventDb.giftPerformanceSummary(roomKey))
            .putString("data_best_gift", bestGift?.gift ?: "")
            .putInt("data_best_gift_score", bestGift?.score ?: 0)
            .putInt("data_best_gift_samples", bestGift?.samples ?: 0)
            .putInt("data_trevo_score", giftPerformance.firstOrNull { it.gift == "TREVO" }?.score ?: 0)
            .putInt("data_rosa_score", giftPerformance.firstOrNull { it.gift == "ROSA" }?.score ?: 0)
            .putInt("data_ovo_score", giftPerformance.firstOrNull { it.gift == "OVO" }?.score ?: 0)
            .putInt("data_trevo_samples", giftPerformance.firstOrNull { it.gift == "TREVO" }?.samples ?: 0)
            .putInt("data_rosa_samples", giftPerformance.firstOrNull { it.gift == "ROSA" }?.samples ?: 0)
            .putInt("data_ovo_samples", giftPerformance.firstOrNull { it.gift == "OVO" }?.samples ?: 0)
            .putString("data_other_best_name", bestOther?.gift ?: "Outros")
            .putInt("data_other_best_score", bestOther?.score ?: 0)
            .putInt("data_other_best_samples", bestOther?.samples ?: 0)
            .putInt("strategy_gift_count", strategy.giftCount ?: 0)
            .putInt("strategy_people_count", strategy.peopleCount ?: 0)
            .apply()

        val cutoff = now - 15L * 60L * 1000L
        val it = dataSignatures.entries.iterator()
        while (it.hasNext()) {
            if (it.next().value < cutoff) it.remove()
        }
    }

    private fun update(state: RadarState, read: ScreenRead, remembered: RoomStats?, roomSignals: RoomSignalSnapshot) {
        val now = System.currentTimeMillis()
        val signals = if (read.rawSignals.isEmpty()) {
            "nenhum sinal nesta captura"
        } else {
            read.rawSignals.joinToString(" • ")
        }

        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putBoolean("service_active", true)
            .putLong("capture_count", captureCount)
            .putLong("last_read_at", now)
            .putString("last_signals", signals)
            .putInt("heat_score", state.heatScore)
            .putString("heat_state", state.state)
            .putString("trend", state.trend)
            .putInt("room_activity_score", roomSignals.activityScore)
            .putInt("room_emojis_1m", roomSignals.emojiCount1m)
            .putString("room_emojis_level", roomSignals.emojiLevel)
            .putInt("room_gifts_1m", roomSignals.giftEvents1m)
            .putString("room_gifts_level", roomSignals.giftLevel)
            .putInt("room_normal_gifts_1m", roomSignals.normalGiftUnits1m)
            .putInt("room_afortunados_1m", roomSignals.afortunadoUnits1m)
            .putInt("room_scroll_1m", roomSignals.scrollEvents1m)
            .putString("room_scroll_level", roomSignals.scrollLevel)
            .putInt("room_rocket_progress", roomSignals.rocketProgress ?: -1)
            .putString("room_rocket_trend", roomSignals.rocketTrend)
            .putLong("room_rocket_current", roomSignals.rocketCurrent ?: 0L)
            .putLong("room_rocket_target", roomSignals.rocketTarget ?: 0L)
            .putString("room_rocket_label", roomSignals.rocketLabel)
            .putString("room_pk_status", roomSignals.pkStatus)
            .putInt("room_people_count", roomSignals.peopleCount ?: 0)
            .putInt("room_chairs_total", roomSignals.chairsTotal ?: 0)
            .putInt("room_chairs_occupied", roomSignals.chairsOccupied ?: 0)
            .putInt("room_user_seat", roomSignals.userSeat ?: 0)
            .putInt("room_trevo_sent_1m", roomSignals.trevoSent1m)
            .putInt("room_rosa_sent_1m", roomSignals.rosaSent1m)
            .putInt("room_ovo_sent_1m", roomSignals.ovoSent1m)
            .putLong("room_snapshot_at", roomSignals.snapshotAt)
            .putInt("room_snapshot_heat", roomSignals.snapshotHeat)
            .putInt("room_snapshot_interval_sec", getSharedPreferences("radar", MODE_PRIVATE).getInt("snapshot_interval_sec", 60))
            .putString("activity_window", state.activityWindow)
            .putString("confidence", state.confidence)
            .putLong("sample_seconds", state.sampleSeconds)
            .putLong("jackpot_value", state.jackpotValue ?: 0L)
            .putString("jackpot_band", state.jackpotBand)
            .putInt("jackpot_reference_score", state.jackpotReferenceScore)
            .putInt("historical_pattern_score", state.historicalPatternScore)
            .putString("historical_pattern_status", state.historicalPatternStatus)
            .putLong("last_jackpot_hit", state.jackpotHitValue ?: 0L)
            .putInt("light_1m", state.lightPulses1m)
            .putInt("light_5m", state.lightPulses5m)
            .putInt("lucky_major_hits_1m", luckyPopupAccumulator.snapshot(now).hits1m)
            .putInt("lucky_major_sum_1m", luckyPopupAccumulator.snapshot(now).sumX1m)
            .putInt("lucky_major_max_1m", luckyPopupAccumulator.snapshot(now).maxX1m)
            .putInt("lucky_session_total_x", luckyPopupAccumulator.snapshot(now).sessionTotalX)
            .putInt("light_prev_1m", state.lightPulsesPrev1m)
            .putInt("light_trend_pct", state.lightTrendPercent)
            .putInt("light_high_1m", state.highLightPulses1m)
            .putInt("light_x20", state.lightX20_5m)
            .putInt("light_x50", state.lightX50_5m)
            .putInt("light_x200", state.lightX200_5m)
            .putInt("light_x300", state.lightX300_5m)
            .putInt("light_x500", state.lightX500_5m)
            .putInt("light_x1000", state.lightX1000_5m)
            .putInt("light_sensor_count", read.luckyLights.size)
            .putString("gift_current", state.currentGift ?: "")
            .putString("gift_action", state.giftAction)
            .putString("gift_recommendation", state.giftRecommendation)
            .putString("gift_confidence", state.giftConfidence)
            .putInt("gift_low_streak", state.lowMultiplierStreak)
            .putInt("gift_trevo_score", state.giftTrevoScore)
            .putInt("gift_rosa_score", state.giftRosaScore)
            .putInt("gift_ovo_score", state.giftOvoScore)
            .putLong("gift_trevo_samples", state.giftTrevoSamples)
            .putLong("gift_rosa_samples", state.giftRosaSamples)
            .putLong("gift_ovo_samples", state.giftOvoSamples)
            .putLong("history_jackpot_hits", globalJackpotHistory.mergeIntoRoomHistory(remembered).jackpotHitCount)
            .putLong("history_ref1_hits", globalJackpotHistory.mergeIntoRoomHistory(remembered).ref1Hits)
            .putLong("history_ref2_hits", globalJackpotHistory.mergeIntoRoomHistory(remembered).ref2Hits)
            .putLong("history_avg_jackpot_hit", globalJackpotHistory.mergeIntoRoomHistory(remembered).averageJackpotHit)
            .putLong("history_lucky_pulses", remembered?.luckyLightPulses ?: 0L)
            .putLong("last_payout", getSharedPreferences("radar", MODE_PRIVATE).getLong("last_confirmed_payout", 0L))
            .putLong("previous_payout", read.previousPayout ?: 0L)
            .putFloat("max_multiplier_v14", state.maxMultiplier1m?.toFloat() ?: 0f)
            .putInt("wins_1m", state.wins1m)
            .putInt("wins_5m", state.wins5m)
            .putInt("wins_10m", state.wins10m)
            .putLong("payouts_5m", state.payouts5m)
            .putInt("band_2_4", state.wins2to4_5m)
            .putInt("band_5_9", state.wins5to9_5m)
            .putInt("band_10_24", state.wins10to24_5m)
            .putInt("band_25_49", state.wins25to49_5m)
            .putInt("band_50_99", state.wins50to99_5m)
            .putInt("band_100_249", state.wins100to249_5m)
            .putInt("band_250_499", state.wins250to499_5m)
            .putInt("band_500_1000", state.wins500to1000_5m)
            .putLong("error_count", errorCount)
            .putString("current_room", currentRoom)
            .putString("current_room_id", currentRoomId)
            .putString("monitor_context", "SALA")
            .putString("heartbeat", "🔄 ${lastTargetPackage?.let { friendlyTargetName(it) } ?: "SIYA"} • $currentRoom • atualização automática")
            .putString(
                "room_history_summary",
                if (::roomHistory.isInitialized) roomHistory.summary(8)
                else "Aguardando histórico"
            )
            .apply()

        main.post {
            val color = when {
                state.activityWindow.contains("MUITO ELEVADA") -> Color.rgb(255, 90, 95)
                state.activityWindow.contains("ELEVADA") -> Color.rgb(255, 190, 70)
                state.activityWindow == "OBSERVAÇÃO" -> Color.rgb(120, 205, 255)
                else -> Color.rgb(170, 190, 215)
            }

            headline?.setTextColor(color)
            val jackpot = state.jackpotValue?.let { format(it) } ?: "—"
            headline?.text = "🎯 ${state.activityWindow} • ${state.heatScore}/100 • ${state.trend}"

            val pulses = state.newLightPulses.joinToString(", ") { "x$it" }.ifBlank { "—" }
            val giftIcon = when (state.giftRecommendation) { "TREVO" -> "🍀"; "ROSA" -> "🌹"; "OVO" -> "🥚"; else -> "🎁" }
            val currentGiftLabel = state.currentGift ?: "—"
            details?.text =
                "🏠 $currentRoom • 🎰 $jackpot • 💡 ${state.lightPulses1m}/1m • 200x+ ${state.highLightPulses1m}\n" +
                "😀 ${roomSignals.emojiLevel} • 🎁 ${roomSignals.giftLevel} • 🚀 ${roomSignals.rocketProgress?.let { "$it%" } ?: "—"} ${roomSignals.rocketTrend} • ⚔️ PK ${roomSignals.pkStatus}\n" +
                "🎁 atual $currentGiftLabel • ${state.giftAction} • $giftIcon ${state.giftRecommendation} (${state.giftConfidence})\n" +
                "📉 baixos seguidos ${state.lowMultiplierStreak} • Lucky novo: $pulses"
        }
    }

    private fun updateGlobalScroll(state: RadarState, read: ScreenRead) {
        val now = System.currentTimeMillis()
        val signals = if (read.rawSignals.isEmpty()) {
            "nenhum sinal nesta captura"
        } else {
            read.rawSignals.joinToString(" • ")
        }

        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putBoolean("service_active", true)
            .putLong("capture_count", captureCount)
            .putLong("last_read_at", now)
            .putString("last_signals", signals)
            .putString("monitor_context", "ROLAGEM / GLOBAL")
            .putString("current_room", "ROLAGEM / GLOBAL")
            .putString("current_room_id", "—")
            .putInt("heat_score", state.heatScore)
            .putString("heat_state", state.state)
            .putString("trend", state.trend)
            .putString("activity_window", state.activityWindow)
            .putString("confidence", state.confidence)
            .putLong("sample_seconds", state.sampleSeconds)
            .putLong("jackpot_value", state.jackpotValue ?: 0L)
            .putString("jackpot_band", state.jackpotBand)
            .putInt("light_1m", state.lightPulses1m)
            .putInt("light_5m", state.lightPulses5m)
            .putInt("lucky_major_hits_1m", luckyPopupAccumulator.snapshot(now).hits1m)
            .putInt("lucky_major_sum_1m", luckyPopupAccumulator.snapshot(now).sumX1m)
            .putInt("lucky_major_max_1m", luckyPopupAccumulator.snapshot(now).maxX1m)
            .putInt("lucky_session_total_x", luckyPopupAccumulator.snapshot(now).sessionTotalX)
            .putInt("light_high_1m", state.highLightPulses1m)
            .putInt("light_sensor_count", read.luckyLights.size)
            .putString("gift_current", state.currentGift ?: "")
            .putString("gift_action", state.giftAction)
            .putString("gift_recommendation", state.giftRecommendation)
            .putString("gift_confidence", state.giftConfidence)
            .putInt("gift_trevo_score", state.giftTrevoScore)
            .putInt("gift_rosa_score", state.giftRosaScore)
            .putInt("gift_ovo_score", state.giftOvoScore)
            .putLong("gift_trevo_samples", state.giftTrevoSamples)
            .putLong("gift_rosa_samples", state.giftRosaSamples)
            .putLong("gift_ovo_samples", state.giftOvoSamples)
            .putLong("last_payout", getSharedPreferences("radar", MODE_PRIVATE).getLong("last_confirmed_payout", 0L))
            .putLong("previous_payout", read.previousPayout ?: 0L)
            .putFloat("max_multiplier_v14", state.maxMultiplier1m?.toFloat() ?: 0f)
            .putInt("wins_1m", state.wins1m)
            .putInt("wins_5m", state.wins5m)
            .putLong("payouts_5m", state.payouts5m)
            .putString("room_emojis_level", "GLOBAL")
            .putString("room_gifts_level", "GLOBAL")
            .putString("room_scroll_level", "ATIVA")
            .putInt("room_rocket_progress", -1)
            .putString("room_rocket_trend", "NÃO LIDO")
            .putString("room_pk_status", "NÃO DETECTADO")
            .putInt("room_people_count", 0)
            .putString("heartbeat", "📜 SIYA • ROLAGEM/GLOBAL • leitura automática")
            .apply()

        main.post {
            headline?.text = "📜 ROLAGEM/GLOBAL • ${state.heatScore}/100 • ${state.trend}"
            val jackpot = state.jackpotValue?.let { format(it) } ?: "—"
            details?.text =
                "🎰 JACKPOT $jackpot • 🎯 ${state.wins1m}/1m • 💡 Lucky ${state.lightPulses1m}/1m\n" +
                "✅ leitura automática ativa mesmo fora da poltrona"
        }
    }


    private fun beginRoomDetectionBurst() {
        val now = System.currentTimeMillis()
        if (now >= roomDetectionBurstUntil) roomDetectionStartedAt = now
        roomDetectionBurstUntil = maxOf(roomDetectionBurstUntil, now + 5_000L)
        getSharedPreferences("radar", MODE_PRIVATE).edit()
            .putLong("room_detection_started_at", roomDetectionStartedAt)
            .putLong("room_detection_deadline_at", roomDetectionBurstUntil)
            .apply()
    }

    private fun updateDragonTigerAnalysis(visible: String) {
        val prefs = getSharedPreferences("radar", MODE_PRIVATE)
        val oldVisible = prefs.getString("dt_visible_sequence", "").orEmpty()
        val stored = prefs.getString("dt_history", "").orEmpty()
        var history = stored
        if (visible != oldVisible) {
            if (oldVisible.isBlank()) {
                history = (history + visible).takeLast(1000)
            } else {
                // When the strip scrolls one position, append only the newly appearing bead.
                var overlap = minOf(oldVisible.length, visible.length)
                while (overlap > 0 && !oldVisible.endsWith(visible.substring(0, overlap))) overlap--
                val additions = if (overlap > 0) visible.substring(overlap) else visible.takeLast(1)
                if (additions.isNotBlank()) history = (history + additions).takeLast(1000)
            }
            prefs.edit().putString("dt_visible_sequence", visible).putString("dt_history", history).apply()
        }
        if (history.isBlank()) history = visible
        val d = history.count { it == 'D' }
        val t = history.count { it == 'T' }
        val e = history.count { it == 'E' }
        val total = d + t + e
        if (total < 3) return
        val last = history.last()
        val transitions = history.zipWithNext().filter { it.first == last }.map { it.second }
        val td = transitions.count { it == 'D' }
        val tt = transitions.count { it == 'T' }
        val te = transitions.count { it == 'E' }
        val transTotal = td + tt + te
        // Blend long-run frequency with transitions after the latest outcome; this is descriptive only.
        val dPct = if (transTotal >= 3) (d * 0.35 / total + td * 0.65 / transTotal) * 100 else d * 100.0 / total
        val tPct = if (transTotal >= 3) (t * 0.35 / total + tt * 0.65 / transTotal) * 100 else t * 100.0 / total
        val ePct = if (transTotal >= 3) (e * 0.35 / total + te * 0.65 / transTotal) * 100 else e * 100.0 / total
        val sum = dPct + tPct + ePct
        val dn = dPct * 100 / sum; val tn = tPct * 100 / sum; val en = ePct * 100 / sum
        val now = System.currentTimeMillis()
        if (now - lastDragonTigerOverlayAt < 900 && visible == lastDragonTigerVisibleSequence) return
        lastDragonTigerVisibleSequence = visible
        lastDragonTigerOverlayAt = now
        prefs.edit()
            .putString("dt_latest_prediction", when (maxOf(dn, tn, en)) { dn -> "🔵 Dragon"; tn -> "🔴 Tiger"; else -> "🟢 Empate" })
            .putInt("dt_count", total)
            .putString("dt_last", when(last) { 'D' -> "🔵 Dragon"; 'T' -> "🔴 Tiger"; else -> "🟢 Empate" })
            .putString("dt_percentages", "🔵 ${"%.1f".format(java.util.Locale.US, dn)}% • 🔴 ${"%.1f".format(java.util.Locale.US, tn)}% • 🟢 ${"%.1f".format(java.util.Locale.US, en)}%")
            .putString("dt_sequence_text", history.takeLast(24).map { when(it) { 'D' -> "🔵"; 'T' -> "🔴"; else -> "🟢" } }.joinToString(" "))
            .putLong("dt_updated_at", now)
            .apply()
        main.post {
            headline?.text = "🐉 DRAGON TIGER • ${total} resultados"
            details?.text = "Último: ${prefs.getString("dt_last", "—")} • Estimativa: ${prefs.getString("dt_latest_prediction", "—")}\n" +
                prefs.getString("dt_percentages", "—") + "\n" +
                "Sequência: ${prefs.getString("dt_sequence_text", "—")}\n" +
                "Frequências observadas; estimativa não garante o próximo resultado."
        }
    }

    private fun mergeItems(primary: List<OcrItem>, extra: List<OcrItem>): List<OcrItem> {
        if (extra.isEmpty()) return primary
        val out = ArrayList<OcrItem>(primary.size + extra.size)
        val seen = HashSet<String>()
        fun add(item: OcrItem) {
            val clean = item.text.trim()
            if (clean.isBlank()) return
            val key = clean.lowercase() + ":" + (item.cx / 8) + ":" + (item.cy / 8)
            if (seen.add(key)) out += item
        }
        primary.forEach(::add)
        extra.forEach(::add)
        return out
    }

    private fun collectAccessibilityItems(): List<OcrItem> {
        val out = ArrayList<OcrItem>()
        val visited = HashSet<Int>()
        var count = 0

        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 20 || count >= 320) return
            val id = System.identityHashCode(node)
            if (!visited.add(id)) return
            count++

            val rect = Rect()
            try { node.getBoundsInScreen(rect) } catch (_: Throwable) { }
            if (rect.width() > 1 && rect.height() > 1) {
                val values = linkedSetOf<String>()
                node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(values::add)
                node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(values::add)
                values.forEach { value -> out += OcrItem(value.take(160), Rect(rect)) }
            }

            val childCount = try { node.childCount } catch (_: Throwable) { 0 }
            for (i in 0 until childCount) {
                val child = try { node.getChild(i) } catch (_: Throwable) { null }
                walk(child, depth + 1)
            }
        }

        try { walk(rootInActiveWindow, 0) } catch (_: Throwable) { }
        if (out.size < 8) {
            try {
                windows.forEach { window ->
                    if (isTargetPackage(window.root?.packageName?.toString())) walk(window.root, 0)
                }
            } catch (_: Throwable) { }
        }
        return out
    }

    private fun improveRoomRead(read: ScreenRead, items: List<OcrItem>, width: Int, height: Int): ScreenRead {
        val fastName = read.roomName ?: fastRoomName(items, width, height)
        val fastId = read.roomId ?: fastRoomId(items, width, height)
        val all = items.joinToString(" ") { it.text }.lowercase()
        val roomMarkers = listOf("top diário", "top diario", "conversar", "presente", "todos", "ranking", "rocket")
            .count { all.contains(it) }
        val confirmed = read.roomUiConfirmed || fastName != null || fastId != null || roomMarkers >= 2

        if (confirmed && (fastName != null || fastId != null)) {
            val started = roomDetectionStartedAt
            val now = System.currentTimeMillis()
            getSharedPreferences("radar", MODE_PRIVATE).edit()
                .putLong("room_identity_seen_at", now)
                .putLong("room_detection_latency_ms", if (started > 0L) (now - started).coerceAtLeast(0L) else 0L)
                .apply()
        }

        return read.copy(roomName = fastName, roomId = fastId, roomUiConfirmed = confirmed)
    }

    private fun fastRoomId(items: List<OcrItem>, width: Int, height: Int): String? {
        if (items.isEmpty() || width <= 0 || height <= 0) return null

        // 1) ID explícito em qualquer elemento do cabeçalho.
        items.forEach { item ->
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            if (y !in 0.025..0.20 || x !in 0.01..0.82) return@forEach
            Regex("(?i)\\bID\\s*[:#-]?\\s*(\\d{5,10})\\b").find(item.text)
                ?.groupValues?.getOrNull(1)?.let { return it }
        }

        // 2) Âncora Ouro/Prata: o chip verde de ID fica ao lado dessa linha no SIYA.
        val tierLabels = items.filter {
            val low = GiftCatalog.normalizeText(it.text)
            val y = it.cy.toDouble() / height
            y in 0.035..0.18 && listOf("ouro", "prata", "bronze", "diamante").any { tier -> low.contains(tier) }
        }
        for (tier in tierLabels) {
            val near = items.mapNotNull { item ->
                val yDiff = kotlin.math.abs(item.cy - tier.cy).toDouble() / height
                val dx = item.cx - tier.cx
                if (yDiff > 0.055 || dx !in -40..(width * 0.55).toInt()) return@mapNotNull null
                val n = Regex("(?<!\\d)(\\d{5,9})(?!\\d)").find(item.text)?.groupValues?.getOrNull(1) ?: return@mapNotNull null
                if (n.all { it == '0' }) return@mapNotNull null
                Triple(n, kotlin.math.abs(dx).toDouble(), yDiff)
            }
            near.minByOrNull { it.second + it.third * width }?.first?.let { return it }
        }

        // 3) Fallback: número puro de 5–9 dígitos no topo. Exclui textos com K/M, barra e "Anterior".
        data class Candidate(val n: String, val score: Double)
        return items.mapNotNull { item ->
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            if (y !in 0.025..0.18 || x !in 0.05..0.72) return@mapNotNull null
            val raw = item.text.trim()
            if (raw.contains("K", true) || raw.contains("M", true) || raw.contains("/") || raw.contains("anterior", true)) return@mapNotNull null
            val n = Regex("(?<!\\d)(\\d{5,9})(?!\\d)").find(raw)?.groupValues?.getOrNull(1) ?: return@mapNotNull null
            var score = 0.0
            if (x in 0.24..0.55) score += 3.0
            if (y in 0.05..0.12) score += 3.0
            score += item.h.toDouble() / height * 12.0
            Candidate(n, score)
        }.maxByOrNull { it.score }?.n
    }

    private fun fastRoomName(items: List<OcrItem>, width: Int, height: Int): String? {
        if (items.isEmpty() || width <= 0 || height <= 0) return null
        val blocked = listOf(
            "ouro", "prata", "bronze", "diamante", "ranking", "top", "top diario",
            "conversar", "presente", "todos", "rocket", "go", "jackpot", "lucky", "afortunados",
            "token", "celebridade", "recargar", "nobreza", "id", "visitantes", "explorar",
            "anterior", "nova mensagem", "enviou", "ganhou", "win"
        )

        fun cleanName(raw: String): String {
            return raw
                .replace(Regex("[^\\p{L}\\p{N} _'\\-]+"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        data class C(val text: String, val score: Double)
        val candidates = mutableListOf<C>()

        // Nomes diretamente visíveis no topo.
        items.forEach { item ->
            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            if (y !in 0.02..0.18 || x !in 0.01..0.72) return@forEach
            val clean = cleanName(item.text)
            if (clean.length !in 3..48 || clean.count { it.isLetter() } < 3) return@forEach
            val low = GiftCatalog.normalizeText(clean)
            if (blocked.any { low == it || low.startsWith("$it ") }) return@forEach
            if (Regex("^\\d+(?:[.,]\\d+)?[kKmM]?$" ).matches(clean)) return@forEach
            var score = clean.count { it.isLetter() } * 1.4
            score += (item.h.toDouble() / height * 650.0).coerceAtMost(30.0)
            if (x in 0.05..0.46) score += 11.0
            if (y in 0.045..0.13) score += 13.0
            if (clean.contains(' ')) score += 3.0
            candidates += C(clean, score)
        }

        // A linha do nome costuma ficar imediatamente acima/próxima de Ouro/Prata.
        val tierLabels = items.filter {
            val low = GiftCatalog.normalizeText(it.text)
            listOf("ouro", "prata", "bronze", "diamante").any { tier -> low.contains(tier) }
        }
        tierLabels.forEach { tier ->
            items.forEach { item ->
                if (item === tier) return@forEach
                val dy = (tier.cy - item.cy).toDouble() / height
                val dx = kotlin.math.abs(item.cx - tier.cx).toDouble() / width
                if (dy !in -0.025..0.10 || dx > 0.38) return@forEach
                val clean = cleanName(item.text)
                if (clean.length !in 3..48 || clean.count { it.isLetter() } < 3) return@forEach
                val low = GiftCatalog.normalizeText(clean)
                if (blocked.any { low == it || low.startsWith("$it ") }) return@forEach
                candidates += C(clean, clean.count { it.isLetter() } * 1.5 + 18.0 - dx * 10.0)
            }
        }

        return candidates.maxByOrNull { it.score }?.text
    }

    private fun persistSeatStatus(items: List<OcrItem>, width: Int, height: Int, roomConfirmed: Boolean) {
        if (!roomConfirmed) return
        val all = items.joinToString(" ") { it.text }.lowercase()
        val controls = listOf("todos", "conversar", "presente", "top diário", "top diario", "ranking", "rocket")
            .count { all.contains(it) }
        val participantTexts = items.count { item ->
            val y = item.cy.toDouble() / height
            y in 0.12..0.65 && item.text.count { it.isLetter() } >= 2 && item.text.length in 2..28
        }
        val seatStatus = when {
            all.contains("poltrona") -> "NA POLTRONA"
            controls >= 2 && participantTexts >= 3 -> "NA POLTRONA"
            all.contains("presente") && participantTexts >= 2 -> "NA POLTRONA"
            else -> "SALA DETECTADA"
        }
        getSharedPreferences("radar", MODE_PRIVATE).edit()
            .putString("room_seat_status", seatStatus)
            .putInt("room_participant_texts", participantTexts)
            .apply()
    }

    private fun saveRoomBanner(bitmap: Bitmap, roomName: String?, roomId: String?) {
        val now = System.currentTimeMillis()
        val key = "${roomId.orEmpty()}|${roomName.orEmpty()}"
        if (key == lastRoomBannerKey && now - lastRoomBannerSavedAt < 15_000L) return
        if (bitmap.width < 100 || bitmap.height < 200) return

        try {
            // Região onde o SIYA mostra o avatar/banner da sala nas telas reais.
            val left = (bitmap.width * 0.015).roundToInt().coerceAtLeast(0)
            val top = (bitmap.height * 0.055).roundToInt().coerceAtLeast(0)
            val side = (bitmap.width * 0.105).roundToInt().coerceAtLeast(64)
            val safeSide = minOf(side, bitmap.width - left, bitmap.height - top)
            if (safeSide <= 40) return

            val crop = Bitmap.createBitmap(bitmap, left, top, safeSide, safeSide)
            val file = java.io.File(filesDir, "room_banner.jpg")
            FileOutputStream(file).use { out ->
                crop.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            crop.recycle()
            lastRoomBannerKey = key
            lastRoomBannerSavedAt = now
            getSharedPreferences("radar", MODE_PRIVATE).edit()
                .putLong("room_banner_updated_at", now)
                .putString("room_banner_key", key)
                .apply()
        } catch (_: Throwable) {
        }
    }

    private fun saveHeartbeat(message: String) {
        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putBoolean("service_active", true)
            .putLong("service_heartbeat_at", System.currentTimeMillis())
            .putString("heartbeat", message)
            .apply()
    }

    private fun registerError(message: String) {
        errorCount++

        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putLong("error_count", errorCount)
            .putString("last_error", message)
            .apply()

        main.post {
            details?.text =
                "⚠️ AUTO ativo • erro: $message • nova tentativa automática"
        }
    }

    private fun setOverlayVisible(visible: Boolean) {
        main.post {
            overlay?.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun showOverlay() {
        if (overlay != null) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayWindowManager = wm
        fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(10))
            visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(Color.argb(246, 5, 14, 32))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(69, 177, 255))
            }
        }
        overlayPanel = panel

        val dragHandle = TextView(this).apply {
            text = "↕  InfinityAppPro • AUTO"
            setTextColor(Color.rgb(145, 235, 255))
            textSize = 10f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(4))
        }

        headline = TextView(this).apply {
            text = "📡 AUTO SIYA • aguardando sala"
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        details = TextView(this).apply {
            text = "Leitura automática • sala • poltrona • Lucky • presentes"
            setTextColor(Color.LTGRAY)
            textSize = 10f
            setPadding(0, dp(4), 0, 0)
        }
        panel.addView(dragHandle)
        panel.addView(headline)
        panel.addView(details)

        val handle = TextView(this).apply {
            text = "‹\nABRIR"
            setTextColor(Color.WHITE)
            textSize = 9.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(245, 55, 19, 105))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(2), Color.rgb(100, 189, 255))
            }
        }
        overlayHandle = handle

        root.addView(panel, LinearLayout.LayoutParams(dp(292), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = dp(4)
        })
        root.addView(handle, LinearLayout.LayoutParams(dp(43), dp(126)))

        val prefs = getSharedPreferences("radar", MODE_PRIVATE)
        val savedY = prefs.getInt("overlay_y", dp(180))
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.RIGHT
            y = savedY
        }
        overlayParams = params

        fun setExpanded(expanded: Boolean) {
            overlayExpanded = expanded
            panel.visibility = if (expanded) View.VISIBLE else View.GONE
            handle.text = if (expanded) "›\nFECHAR" else "‹\nABRIR"
            try { overlayWindowManager?.updateViewLayout(root, overlayParams) } catch (_: Throwable) { }
        }

        var downX = 0f
        var downY = 0f
        var startWindowY = savedY
        var movedVertical = false
        val touch = View.OnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startWindowY = overlayParams?.y ?: 0
                    movedVertical = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dy) > dp(8)) {
                        movedVertical = true
                        val p = overlayParams ?: return@OnTouchListener true
                        val maxY = (resources.displayMetrics.heightPixels - root.height.coerceAtLeast(dp(80))).coerceAtLeast(0)
                        p.y = (startWindowY + dy.roundToInt()).coerceIn(0, maxY)
                        try { overlayWindowManager?.updateViewLayout(root, p) } catch (_: Throwable) { }
                    } else if (kotlin.math.abs(dx) > dp(28)) {
                        setExpanded(dx < 0)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!movedVertical && kotlin.math.abs(dx) < dp(22) && kotlin.math.abs(dy) < dp(12)) {
                        setExpanded(!overlayExpanded)
                    } else if (kotlin.math.abs(dx) > dp(28)) {
                        setExpanded(dx < 0)
                    }
                    prefs.edit().putInt("overlay_y", overlayParams?.y ?: savedY).apply()
                    true
                }
                else -> false
            }
        }
        handle.setOnTouchListener(touch)
        dragHandle.setOnTouchListener(touch)

        overlay = root
        wm.addView(root, params)
        setExpanded(false)
    }

    private fun toBitmap(result: ScreenshotResult): Bitmap? {
        return try {
            val hardwareBuffer = result.hardwareBuffer
            val wrapped = Bitmap.wrapHardwareBuffer(
                hardwareBuffer,
                result.colorSpace
            ) ?: run {
                hardwareBuffer.close()
                return null
            }

            val copy = wrapped.copy(Bitmap.Config.ARGB_8888, false)
            wrapped.recycle()
            hardwareBuffer.close()
            copy
        } catch (_: Throwable) {
            null
        }
    }

    private fun format(v: Long): String = when {
        v >= 1_000_000L -> String.format("%.2fM", v / 1_000_000.0)
        v >= 1_000L -> String.format("%.1fK", v / 1_000.0)
        else -> v.toString()
    }

    override fun onDestroy() {
        getSharedPreferences("radar", MODE_PRIVATE)
            .edit()
            .putBoolean("service_active", false)
            .apply()

        main.removeCallbacks(ticker)

        overlay?.let {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager)
                    .removeView(it)
            } catch (_: Throwable) {
            }
        }

        if (::eventDb.isInitialized) {
            eventDb.endSession(dbSessionId)
            eventDb.close()
        }

        recognizer.close()
        executor.shutdownNow()

        super.onDestroy()
    }
}
