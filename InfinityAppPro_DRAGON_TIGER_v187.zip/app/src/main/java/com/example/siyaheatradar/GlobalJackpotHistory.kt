package com.example.siyaheatradar

import android.content.Context

class GlobalJackpotHistory(context: Context) {

    private val prefs = context.getSharedPreferences("global_jackpot_v16", Context.MODE_PRIVATE)

    fun mergeIntoRoomHistory(room: RoomStats?): RoomStats {
        val base = room ?: RoomStats(name = "GLOBAL")
        val hits = prefs.getLong("hit_count", 0L)

        return base.copy(
            jackpotEvents = prefs.getLong("banner_events", 0L),
            jackpotSamples = prefs.getLong("sample_count", 0L),
            lastJackpotValue = prefs.getLong("last_value", 0L),
            maxJackpotValue = prefs.getLong("max_value", 0L),
            jackpotHitCount = hits,
            jackpotHitValueSum = prefs.getLong("hit_sum", 0L),
            lastJackpotHitValue = prefs.getLong("last_hit", 0L),
            lastJackpotHitAt = prefs.getLong("last_hit_at", 0L),
            minJackpotHitValue = prefs.getLong("min_hit", 0L),
            maxJackpotHitValue = prefs.getLong("max_hit", 0L),
            preHitLight1mSum = prefs.getLong("pre_light_sum", 0L),
            preHitHighLight1mSum = prefs.getLong("pre_high_sum", 0L),
            preHitWins1mSum = prefs.getLong("pre_win_sum", 0L),
            ref1Hits = prefs.getLong("ref1", 0L),
            ref2Hits = prefs.getLong("ref2", 0L)
        )
    }

    fun record(read: ScreenRead, state: RadarState, now: Long = System.currentTimeMillis()) {
        val e = prefs.edit()

        val wasVisible = prefs.getBoolean("visible", false)
        if (read.jackpotBanner && !wasVisible) {
            e.putLong("banner_events", prefs.getLong("banner_events", 0L) + 1L)
        }
        e.putBoolean("visible", read.jackpotBanner)

        read.jackpotValue?.let { v ->
            e.putLong("sample_count", prefs.getLong("sample_count", 0L) + 1L)
            e.putLong("last_value", v)
            e.putLong("max_value", maxOf(prefs.getLong("max_value", 0L), v))
        }

        state.jackpotHitValue?.let { hit ->
            val count = prefs.getLong("hit_count", 0L)
            val oldMin = prefs.getLong("min_hit", 0L)

            e.putLong("hit_count", count + 1L)
            e.putLong("hit_sum", prefs.getLong("hit_sum", 0L) + hit)
            e.putLong("last_hit", hit)
            e.putLong("last_hit_at", now)
            e.putLong("min_hit", if (count == 0L || oldMin == 0L) hit else minOf(oldMin, hit))
            e.putLong("max_hit", maxOf(prefs.getLong("max_hit", 0L), hit))
            e.putLong("pre_light_sum", prefs.getLong("pre_light_sum", 0L) + state.lightPulses1m)
            e.putLong("pre_high_sum", prefs.getLong("pre_high_sum", 0L) + state.highLightPulses1m)
            e.putLong("pre_win_sum", prefs.getLong("pre_win_sum", 0L) + state.wins1m)

            if (hit in 1_275_000L..1_500_000L) {
                e.putLong("ref1", prefs.getLong("ref1", 0L) + 1L)
            }
            if (hit in 1_600_000L..2_000_000L) {
                e.putLong("ref2", prefs.getLong("ref2", 0L) + 1L)
            }
        }

        e.apply()
    }

    fun summary(): String {
        val hits = prefs.getLong("hit_count", 0L)
        val last = prefs.getLong("last_value", 0L)
        val lastHit = prefs.getLong("last_hit", 0L)
        val sum = prefs.getLong("hit_sum", 0L)
        val avg = if (hits > 0) sum / hits else 0L
        val ref1 = prefs.getLong("ref1", 0L)
        val ref2 = prefs.getLong("ref2", 0L)
        val lastAt = prefs.getLong("last_hit_at", 0L)
        val ago = if (lastAt > 0) ((System.currentTimeMillis() - lastAt) / 1000L).coerceAtLeast(0L) else -1L

        return buildString {
            append("🌐 JACKPOT GLOBAL DO SIYA\n")
            append("🎰 contador atual: ${format(last)}\n")
            append("💥 resets/hits observados: $hits")
            if (avg > 0) append(" • média ${format(avg)}")
            append("\n🎯 faixa 1: $ref1 • faixa 2: $ref2")
            if (lastHit > 0) append("\n🕘 último hit: ${format(lastHit)} • ${formatAge(ago)}")
            append("\nℹ️ O evento é global; a sala em que foi visto não recebe o jackpot no ranking.")
        }
    }

    private fun formatAge(sec: Long): String = when {
        sec < 0 -> "sem histórico"
        sec < 60 -> "${sec}s atrás"
        sec < 3600 -> "${sec / 60}m atrás"
        else -> "${sec / 3600}h ${(sec % 3600) / 60}m atrás"
    }

    private fun format(v: Long): String = when {
        v >= 1_000_000L -> String.format("%.2fM", v / 1_000_000.0)
        v >= 1_000L -> String.format("%.1fK", v / 1_000.0)
        else -> if (v > 0) v.toString() else "—"
    }
}
