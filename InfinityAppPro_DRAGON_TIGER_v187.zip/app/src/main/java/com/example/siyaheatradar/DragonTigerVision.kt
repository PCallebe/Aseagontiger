package com.example.siyaheatradar

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max

/** Reads the colored Dragon/Tiger/Draw history dots from the visible Siya game screen.
 * It deliberately reports only visually detected colors; it cannot know future outcomes. */
object DragonTigerVision {
    data class Read(val sequence: String, val dots: Int)

    fun detect(bitmap: Bitmap): Read? {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 250 || h < 500) return null
        // On the supplied Siya screen the bead-history strip is around 70-75% of screen height.
        // Restrict scanning to that band to avoid confusing the table/cards with outcomes.
        val y0 = (h * 0.695f).toInt().coerceIn(0, h - 1)
        val y1 = (h * 0.752f).toInt().coerceIn(y0 + 1, h)
        val x0 = (w * 0.14f).toInt()
        val x1 = (w * 0.86f).toInt()
        val scores = Array(x1 - x0) { IntArray(3) }
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                val hi = max(r, max(g, b)); val lo = minOf(r, g, b)
                if (hi < 95 || hi - lo < 35) continue
                val idx = when {
                    b > r * 1.18 && b > g * 1.05 && b - r > 28 -> 0 // Dragon blue
                    g > r * 1.08 && g > b * 0.85 && g - r > 18 -> 2 // Draw green
                    r > b * 1.12 && r >= g * 0.90 && r - b > 25 -> 1 // Tiger red/orange
                    else -> -1
                }
                if (idx >= 0) scores[x - x0][idx]++
            }
        }
        // Group adjacent colored columns into individual beads.
        val groups = mutableListOf<Pair<Int, Int>>()
        var start = -1
        for (i in scores.indices) {
            val total = scores[i].sum()
            val active = total >= 2
            if (active && start < 0) start = i
            if (!active && start >= 0) {
                if (i - start >= max(5, w / 100)) groups.add(start to i - 1)
                start = -1
            }
        }
        if (start >= 0 && scores.size - start >= max(5, w / 100)) groups.add(start to scores.size - 1)
        val result = groups.mapNotNull { (a, b) ->
            val sums = IntArray(3)
            for (i in a..b) for (k in 0..2) sums[k] += scores[i][k]
            val maxIdx = sums.indices.maxByOrNull { sums[it] } ?: return@mapNotNull null
            if (sums[maxIdx] < 12) null else when (maxIdx) { 0 -> 'D'; 1 -> 'T'; else -> 'E' }
        }.takeLast(12).joinToString("")
        return if (result.length >= 3) Read(result, result.length) else null
    }
}
