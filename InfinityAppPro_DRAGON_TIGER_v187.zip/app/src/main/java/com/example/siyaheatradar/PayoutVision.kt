package com.example.siyaheatradar

import kotlin.math.abs

/**
 * Detector conservador de pagamento REAL.
 * Não aceita "Anterior", saldo, ranking, foguete, IDs ou números soltos.
 * Só devolve valor quando existe linguagem explícita de prêmio/pagamento próxima.
 */
class PayoutVision {
    private val seen = LinkedHashMap<String, Long>()

    fun reset() = seen.clear()

    fun detect(items: List<OcrItem>, width: Int, height: Int, now: Long): Long? {
        if (items.isEmpty() || width <= 0 || height <= 0) return null
        prune(now)

        data class Candidate(val value: Long, val score: Double, val key: String)
        val candidates = mutableListOf<Candidate>()

        items.forEach { item ->
            val text = item.text.trim()
            val value = parseMoney(text) ?: return@forEach
            if (value !in 100L..100_000_000L) return@forEach

            val near = nearbyText(items, item, width, height)
            val merged = GiftCatalog.normalizeText("$text $near")

            if (merged.contains("anterior") || merged.contains("saldo") || merged.contains("ranking") ||
                merged.contains("rocket") || merged.contains("foguete") || merged.contains("recarregar") ||
                merged.contains("id ") || merged.contains("svip") || merged.contains("visitantes") ||
                merged.contains("online") || merged.contains("/")) return@forEach

            // Multiplicador não é valor pago.
            if (Regex("(?i)(?:x|×)\\s*\\d+").containsMatchIn(text)) return@forEach

            val explicitPrize = listOf(
                "ganhou", "ganho", "recebeu", "premio", "prêmio", "pagou", "pago",
                "moedas de ouro", "moedas de presente", "recompensa", "reward"
            ).any { merged.contains(GiftCatalog.normalizeText(it)) }

            // "WIN x50" sem valor monetário continua sendo multiplicador, não pagamento.
            if (!explicitPrize) return@forEach

            val x = item.cx.toDouble() / width
            val y = item.cy.toDouble() / height
            if (y !in 0.12..0.90 || x !in 0.03..0.97) return@forEach

            var score = 2.0
            if (merged.contains("ganhou") || merged.contains("recebeu")) score += 2.0
            if (merged.contains("premio") || merged.contains("prêmio")) score += 1.5
            score += (item.h.toDouble() / height * 20.0).coerceAtMost(1.5)
            val key = "PAY:$value:${item.cx / 80}:${item.cy / 80}"
            candidates += Candidate(value, score, key)
        }

        val best = candidates.maxByOrNull { it.score } ?: return null
        val previous = seen[best.key] ?: 0L
        if (now - previous < 8_000L) return null
        seen[best.key] = now
        return best.value
    }

    private fun parseMoney(raw: String): Long? {
        val text = raw.replace(',', '.').trim()
        Regex("(?i)(?<![x×\\d])(\\d+(?:\\.\\d+)?)\\s*([KM])\\b").find(text)?.let { m ->
            val n = m.groupValues[1].toDoubleOrNull() ?: return@let
            val mult = if (m.groupValues[2].equals("M", true)) 1_000_000.0 else 1_000.0
            return (n * mult).toLong()
        }
        Regex("(?<!\\d)(\\d{1,3}(?:[.\\s]\\d{3}){1,2}|\\d{4,8})(?!\\d)").find(text)?.let { m ->
            return m.groupValues[1].replace(".", "").replace(" ", "").toLongOrNull()
        }
        return null
    }

    private fun nearbyText(items: List<OcrItem>, target: OcrItem, width: Int, height: Int): String {
        val maxDx = width * 0.38
        val maxDy = height * 0.08
        return items.asSequence()
            .filter { it !== target }
            .filter { abs(it.cx - target.cx) <= maxDx && abs(it.cy - target.cy) <= maxDy }
            .sortedBy { abs(it.cx - target.cx) + abs(it.cy - target.cy) }
            .take(12)
            .joinToString(" ") { it.text }
    }

    private fun prune(now: Long) {
        val cutoff = now - 90_000L
        val it = seen.entries.iterator()
        while (it.hasNext()) if (it.next().value < cutoff) it.remove()
    }
}
