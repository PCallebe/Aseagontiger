package com.example.siyaheatradar

import kotlin.math.abs

/** Detector dedicado aos banners WIN/resultados que o parser genérico podia descartar. */
class WinVision {
    private val seen = LinkedHashMap<String, Long>()

    fun reset() = seen.clear()

    fun detect(items: List<OcrItem>, width: Int, height: Int, now: Long): List<WinHit> {
        if (items.isEmpty()) return emptyList()
        prune(now)
        val out = mutableListOf<WinHit>()

        items.forEach { item ->
            val own = item.text
            val near = nearbyText(items, item, width, height)
            val merged = "$own $near"
            val low = merged.lowercase()

            val values = mutableListOf<Double>()
            Regex("(?i)\\bWIN\\s*(?:x|×)?\\s*(\\d{1,4}(?:[.,]\\d+)?)").findAll(merged).forEach {
                it.groupValues[1].replace(',', '.').toDoubleOrNull()?.let(values::add)
            }
            Regex("(?i)(?:ganhou|won)\\b.{0,60}?(?:x|×)\\s*(\\d{1,4}(?:[.,]\\d+)?)").findAll(merged).forEach {
                it.groupValues[1].replace(',', '.').toDoubleOrNull()?.let(values::add)
            }

            // Se o próprio item é xN e há WIN muito perto, captura também.
            if (low.contains("win")) {
                Regex("(?i)(?:x|×)\\s*(\\d{1,4}(?:[.,]\\d+)?)").findAll(own).forEach {
                    it.groupValues[1].replace(',', '.').toDoubleOrNull()?.let(values::add)
                }
            }

            values.distinct().forEach { value ->
                if (value < 2.0 || value > 1000.0) return@forEach
                val key = "WIN:$value:${item.cx / 70}:${item.cy / 70}"
                val prev = seen[key] ?: 0L
                if (now - prev >= 2_000L) {
                    seen[key] = now
                    out += WinHit(value, "WV:${item.cx / 55}:${item.cy / 55}")
                }
            }
        }
        return out
    }

    private fun nearbyText(items: List<OcrItem>, target: OcrItem, width: Int, height: Int): String {
        val maxDx = width * 0.22
        val maxDy = height * 0.075
        return items.asSequence()
            .filter { it !== target }
            .filter { abs(it.cx - target.cx) <= maxDx && abs(it.cy - target.cy) <= maxDy }
            .sortedBy { abs(it.cx - target.cx) + abs(it.cy - target.cy) }
            .take(8)
            .joinToString(" ") { it.text }
    }

    private fun prune(now: Long) {
        val cutoff = now - 30_000L
        val it = seen.entries.iterator()
        while (it.hasNext()) if (it.next().value < cutoff) it.remove()
    }
}
