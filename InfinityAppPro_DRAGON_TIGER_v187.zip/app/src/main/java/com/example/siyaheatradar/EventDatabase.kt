package com.example.siyaheatradar

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Locale
import java.util.UUID
import kotlin.math.ln

data class DataMaturity(
    val level: String,
    val confidence: Int,
    val observedSeconds: Long,
    val validEvents: Long,
    val note: String
)

data class ConfigPerformance(
    val gift: String,
    val giftCount: Int?,
    val peopleCount: Int?,
    val samples: Int,
    val avgMultiplier: Double,
    val maxMultiplier: Double,
    val hits50: Int,
    val hits200: Int,
    val payoutVolume: Long,
    val score: Double
)



data class GiftOverall(
    val gift: String,
    val samples: Int,
    val avgMultiplier: Double,
    val maxMultiplier: Double,
    val hits50: Int,
    val hits200: Int,
    val payoutVolume: Long,
    val score: Int
)

class EventDatabase(context: Context) :
    SQLiteOpenHelper(context, "infinity_apppro_v16.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                room_key TEXT,
                room_name TEXT,
                room_id TEXT,
                session_id TEXT,
                type TEXT NOT NULL,
                value INTEGER DEFAULT 0,
                multiplier REAL DEFAULT 0,
                gift TEXT,
                gift_count INTEGER,
                people_count INTEGER,
                signature TEXT
            )
        """.trimIndent())

        db.execSQL("""
            CREATE INDEX idx_event_room_time ON events(room_key, ts)
        """.trimIndent())

        db.execSQL("""
            CREATE INDEX idx_event_type_time ON events(type, ts)
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE sessions (
                session_id TEXT PRIMARY KEY,
                room_key TEXT NOT NULL,
                room_name TEXT,
                room_id TEXT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                captures INTEGER DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE INDEX idx_session_room_time ON sessions(room_key, started_at)
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE config_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                room_key TEXT NOT NULL,
                room_name TEXT,
                room_id TEXT,
                session_id TEXT,
                gift TEXT NOT NULL,
                gift_count INTEGER,
                people_count INTEGER,
                multiplier REAL DEFAULT 0,
                payout INTEGER DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE INDEX idx_config_room ON config_results(room_key, gift, gift_count, people_count)
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun startSession(roomKey: String, roomName: String, roomId: String?): String {
        val id = UUID.randomUUID().toString()
        writableDatabase.execSQL(
            """
            INSERT INTO sessions(session_id,room_key,room_name,room_id,started_at)
            VALUES(?,?,?,?,?)
            """.trimIndent(),
            arrayOf(id, roomKey, roomName, roomId, System.currentTimeMillis())
        )
        return id
    }

    fun endSession(sessionId: String?) {
        if (sessionId.isNullOrBlank()) return
        writableDatabase.execSQL(
            "UPDATE sessions SET ended_at=? WHERE session_id=? AND ended_at IS NULL",
            arrayOf(System.currentTimeMillis(), sessionId)
        )
    }

    fun incrementCapture(sessionId: String?) {
        if (sessionId.isNullOrBlank()) return
        writableDatabase.execSQL(
            "UPDATE sessions SET captures=captures+1 WHERE session_id=?",
            arrayOf(sessionId)
        )
    }

    fun addEvent(
        ts: Long,
        roomKey: String?,
        roomName: String?,
        roomId: String?,
        sessionId: String?,
        type: String,
        value: Long = 0L,
        multiplier: Double = 0.0,
        gift: String? = null,
        giftCount: Int? = null,
        peopleCount: Int? = null,
        signature: String? = null
    ) {
        writableDatabase.execSQL(
            """
            INSERT INTO events(
                ts,room_key,room_name,room_id,session_id,type,value,multiplier,
                gift,gift_count,people_count,signature
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """.trimIndent(),
            arrayOf(
                ts, roomKey, roomName, roomId, sessionId, type, value, multiplier,
                gift, giftCount, peopleCount, signature
            )
        )
    }

    fun addConfigResult(
        ts: Long,
        roomKey: String,
        roomName: String,
        roomId: String?,
        sessionId: String?,
        gift: String,
        giftCount: Int?,
        peopleCount: Int?,
        multiplier: Double,
        payout: Long
    ) {
        writableDatabase.execSQL(
            """
            INSERT INTO config_results(
                ts,room_key,room_name,room_id,session_id,gift,gift_count,
                people_count,multiplier,payout
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
            """.trimIndent(),
            arrayOf(
                ts, roomKey, roomName, roomId, sessionId, gift,
                giftCount, peopleCount, multiplier, payout
            )
        )
    }

    fun totalEvents(): Long =
        scalarLong("SELECT COUNT(*) FROM events", emptyArray())

    fun maturity(roomKey: String): DataMaturity {
        val seconds = observedSeconds(roomKey, 0L)
        val events = scalarLong(
            """
            SELECT COUNT(*) FROM events
            WHERE room_key=? AND type IN ('WIN','PAYOUT','LUCKY','WIN_MAJOR','JACKPOT_HIT_GLOBAL')
            """.trimIndent(),
            arrayOf(roomKey)
        )

        return when {
            seconds < 300L || events < 20L -> DataMaturity(
                level = "⚡ PROVISÓRIA",
                confidence = ((seconds / 15L + events).coerceIn(5L, 35L)).toInt(),
                observedSeconds = seconds,
                validEvents = events,
                note = "Sala nova/evento: o MOMENTO ATUAL continua visível mesmo sem histórico."
            )
            seconds < 1800L || events < 100L -> DataMaturity(
                level = "🧪 EM FORMAÇÃO",
                confidence = ((35L + seconds / 90L + events / 4L).coerceIn(36L, 70L)).toInt(),
                observedSeconds = seconds,
                validEvents = events,
                note = "Já existe base útil; histórico ainda está amadurecendo."
            )
            else -> DataMaturity(
                level = "🧠 HISTÓRICO FORTE",
                confidence = ((70L + seconds / 900L + events / 80L).coerceIn(71L, 98L)).toInt(),
                observedSeconds = seconds,
                validEvents = events,
                note = "Base suficiente para comparar momento atual x comportamento observado."
            )
        }
    }

    fun windowSummary(roomKey: String): String {
        val windows = listOf(1, 3, 5, 10, 15, 30, 60)
        val now = System.currentTimeMillis()

        return buildString {
            append("⏱️ JANELAS DE TEMPO\n")
            for (m in windows) {
                val since = now - m * 60_000L
                val wins = scalarLong(
                    "SELECT COUNT(*) FROM events WHERE room_key=? AND type='WIN' AND ts>=?",
                    arrayOf(roomKey, since.toString())
                )
                val high = scalarLong(
                    "SELECT COUNT(*) FROM events WHERE room_key=? AND type='WIN' AND multiplier>=50 AND ts>=?",
                    arrayOf(roomKey, since.toString())
                )
                val pays = scalarLong(
                    "SELECT COUNT(*) FROM events WHERE room_key=? AND type='PAYOUT' AND ts>=?",
                    arrayOf(roomKey, since.toString())
                )
                val volume = scalarLong(
                    "SELECT COALESCE(SUM(value),0) FROM events WHERE room_key=? AND type='PAYOUT' AND ts>=?",
                    arrayOf(roomKey, since.toString())
                )
                append("${m}m: 🎯 $wins resultados • 💎 $high de 50x+ • 💰 $pays pagamentos / ${format(volume)}\n")
            }
        }.trimEnd()
    }

    fun roomRanking24h(limit: Int = 6): String {
        val since = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        val keys = mutableListOf<String>()

        readableDatabase.rawQuery(
            """
            SELECT DISTINCT room_key FROM events
            WHERE room_key IS NOT NULL AND ts>=?
            """.trimIndent(),
            arrayOf(since.toString())
        ).use { c ->
            while (c.moveToNext()) c.getString(0)?.let { keys += it }
        }

        data class Rank(
            val key: String,
            val name: String,
            val id: String,
            val seconds: Long,
            val events: Long,
            val wins: Long,
            val high: Long,
            val pays: Long,
            val volume: Long,
            val score: Int
        )

        val rows = keys.mapNotNull { key ->
            val identity = readableDatabase.rawQuery(
                """
                SELECT COALESCE(room_name,'Sala'), COALESCE(room_id,'')
                FROM events WHERE room_key=? ORDER BY ts DESC LIMIT 1
                """.trimIndent(),
                arrayOf(key)
            ).use { c ->
                if (c.moveToFirst()) c.getString(0) to c.getString(1) else null
            } ?: return@mapNotNull null

            val seconds = observedSeconds(key, since).coerceAtLeast(1L)
            val minutes = (seconds / 60.0).coerceAtLeast(0.5)
            val wins = scalarLong(
                "SELECT COUNT(*) FROM events WHERE room_key=? AND type='WIN' AND ts>=?",
                arrayOf(key, since.toString())
            )
            val high = scalarLong(
                "SELECT COUNT(*) FROM events WHERE room_key=? AND type='WIN' AND multiplier>=50 AND ts>=?",
                arrayOf(key, since.toString())
            )
            val pays = scalarLong(
                "SELECT COUNT(*) FROM events WHERE room_key=? AND type='PAYOUT' AND ts>=?",
                arrayOf(key, since.toString())
            )
            val volume = scalarLong(
                "SELECT COALESCE(SUM(value),0) FROM events WHERE room_key=? AND type='PAYOUT' AND ts>=?",
                arrayOf(key, since.toString())
            )
            val valid = wins + pays

            val winRate = wins / minutes
            val highRate = if (wins > 0) high.toDouble() / wins else 0.0
            val payRate = pays / minutes
            val volumeRate = volume / minutes

            val score = (
                (winRate / 6.0).coerceIn(0.0, 1.0) * 35.0 +
                (highRate / 0.20).coerceIn(0.0, 1.0) * 20.0 +
                (payRate / 0.50).coerceIn(0.0, 1.0) * 20.0 +
                (volumeRate / 200_000.0).coerceIn(0.0, 1.0) * 25.0
            ).toInt().coerceIn(0, 100)

            Rank(key, identity.first, identity.second, seconds, valid, wins, high, pays, volume, score)
        }

        if (rows.isEmpty()) return "🏆 RANKING 24H\nAinda não há salas suficientes."

        val hot = rows.sortedByDescending { it.score }.take(limit)
        val cold = rows.sortedBy { it.score }.take(minOf(3, rows.size))

        return buildString {
            append("🏆 RANKING DAS SALAS • últimas 24h\n\n🔥 MAIS ATIVAS\n")
            hot.forEachIndexed { index, r ->
                val maturity = maturity(r.key)
                val id = if (r.id.isNotBlank()) " • ID ${r.id}" else ""
                append("${index + 1}. ${r.name}$id • ${r.score}/100\n")
                append("   ⏱️ ${formatDuration(r.seconds)} • 🎯 ${r.wins} • 💎50x+ ${r.high} • 💰 ${r.pays} / ${format(r.volume)}\n")
                append("   ${maturity.level} • confiança ${maturity.confidence}%\n")
            }
            append("\n❄️ MENOR ATIVIDADE OBSERVADA\n")
            cold.forEach { r ->
                append("• ${r.name} • ${r.score}/100 • ${formatDuration(r.seconds)} observados\n")
            }
            append("\nℹ️ Ranking mede atividade observada; não promete o próximo pagamento.")
        }.trimEnd()
    }

    fun strategyRecommendation(roomKey: String, currentGift: String?): String {
        val roomRows = configRows("room_key=?", arrayOf(roomKey))
        val usableRoom = roomRows.filter { it.samples >= 5 }

        val source: String
        val rows: List<ConfigPerformance>

        if (usableRoom.isNotEmpty()) {
            source = "🏠 BASE DESTA SALA"
            rows = usableRoom
        } else {
            val global = configRows("1=1", emptyArray()).filter { it.samples >= 5 }
            source = if (global.isNotEmpty()) "🌐 BASE GLOBAL • sala ainda sem amostra" else "⚡ COLETANDO CONFIGURAÇÕES"
            rows = global
        }

        if (rows.isEmpty()) {
            return buildString {
                append("🎯 CONFIGURAÇÃO • $source\n")
                append("Ainda não há amostra suficiente de PRESENTE + QUANTIDADE + PESSOAS.\n")
                append("O app continua registrando automaticamente quando esses dados aparecem na tela.\n")
                append("📌 Menos de 5 amostras não gera sugestão.")
            }
        }

        val filtered = currentGift?.takeIf { it.isNotBlank() }?.let { gift ->
            rows.filter { it.gift == gift }.ifEmpty { rows }
        } ?: rows

        val best = filtered.maxByOrNull { it.score } ?: rows.maxByOrNull { it.score }!!
        val conf = when {
            best.samples >= 50 -> "ALTA"
            best.samples >= 20 -> "MÉDIA/ALTA"
            best.samples >= 10 -> "MÉDIA"
            else -> "BAIXA • PROVISÓRIA"
        }

        val icon = when (best.gift) {
            "TREVO" -> "🍀"
            "ROSA" -> "🌹"
            "OVO" -> "🥚"
            else -> "🎁"
        }

        return buildString {
            append("🎯 CONFIGURAÇÃO OBSERVADA • $source\n")
            append("$icon ${best.gift}")
            append(" • quantidade ${best.giftCount?.let { "x$it" } ?: "não lida"}")
            append(" • ${best.peopleCount?.let { "$it pessoas" } ?: "nº pessoas não lido"}\n")
            append("📊 ${best.samples} amostras • média x${String.format(Locale.US, "%.1f", best.avgMultiplier)}")
            append(" • máx x${formatMultiplier(best.maxMultiplier)}\n")
            append("💎 50x+ ${best.hits50} • 200x+ ${best.hits200} • volume associado ${format(best.payoutVolume)}\n")
            append("🧠 confiança $conf\n")
            if (best.gift == "TREVO") {
                append("🍀 Para Trevo, esta é a combinação quantidade/pessoas com melhor desempenho observado na base disponível.\n")
            }
            append("ℹ️ É comparação histórica observada, não garantia de resultado futuro.")
        }.trimEnd()
    }

    fun configHistory(roomKey: String): String {
        val rows = configRows("room_key=?", arrayOf(roomKey)).take(8)
        if (rows.isEmpty()) return "🎁 HISTÓRICO DE CONFIGURAÇÕES\nAinda sem amostras associadas."

        return buildString {
            append("🎁 HISTÓRICO PRESENTE × QUANTIDADE × PESSOAS\n")
            rows.forEach { r ->
                val icon = when (r.gift) {
                    "TREVO" -> "🍀"; "ROSA" -> "🌹"; "OVO" -> "🥚"; else -> "🎁"
                }
                append("$icon ${r.gift} • ${r.giftCount?.let { "x$it" } ?: "qtd ?"} • ${r.peopleCount?.let { "$it pessoas" } ?: "pessoas ?"}")
                append(" → n=${r.samples} • média x${String.format(Locale.US, "%.1f", r.avgMultiplier)} • 50x+ ${r.hits50} • 200x+ ${r.hits200}\n")
            }
        }.trimEnd()
    }

    fun globalSummary(): String {
        val total = totalEvents()
        val rooms = scalarLong("SELECT COUNT(DISTINCT room_key) FROM events WHERE room_key IS NOT NULL", emptyArray())
        val wins = scalarLong("SELECT COUNT(*) FROM events WHERE type='WIN'", emptyArray())
        val payouts = scalarLong("SELECT COUNT(*) FROM events WHERE type='PAYOUT'", emptyArray())
        val volume = scalarLong("SELECT COALESCE(SUM(value),0) FROM events WHERE type='PAYOUT'", emptyArray())

        return "🗄️ BANCO ESTATÍSTICO\n$total eventos gravados • $rooms salas\n🎯 $wins resultados xN • 💰 $payouts pagamentos • volume observado ${format(volume)}"
    }



    fun recentResults(roomKey: String, limit: Int = 20): String {
        val rows = mutableListOf<String>()
        readableDatabase.rawQuery(
            """
            SELECT ts,type,value,multiplier,COALESCE(gift,''),COALESCE(gift_count,0),COALESCE(people_count,0)
            FROM events
            WHERE room_key=? AND type IN ('WIN','WIN_MAJOR','WIN_ULTRA','WIN_POPUP_MAJOR','PAYOUT')
            ORDER BY ts DESC LIMIT ?
            """.trimIndent(), arrayOf(roomKey, limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val ts = c.getLong(0)
                val type = c.getString(1)
                val value = c.getLong(2)
                val mx = c.getDouble(3)
                val gift = c.getString(4)
                val qty = c.getInt(5)
                val ppl = c.getInt(6)
                val line = when (type) {
                    "PAYOUT" -> "💰 ${time(ts)} • pagamento confirmado ${format(value)}"
                    "WIN_ULTRA" -> "💎 ${time(ts)} • WIN x${formatMultiplier(mx)} • 500x+${if (gift.isNotBlank()) " • ${GiftCatalog.displayName(gift)}" else ""}"
                    "WIN_POPUP_MAJOR" -> "🏃 ${time(ts)} • popup x${formatMultiplier(mx)}${if (gift.isNotBlank()) " • ${GiftCatalog.displayName(gift)}" else ""}"
                    "WIN_MAJOR" -> "🏆 ${time(ts)} • WIN x${formatMultiplier(mx)}${if (gift.isNotBlank()) " • ${GiftCatalog.displayName(gift)}" else ""}"
                    else -> "🎯 ${time(ts)} • WIN x${formatMultiplier(mx)}${if (gift.isNotBlank()) " • ${GiftCatalog.displayName(gift)}" else ""}"
                }
                rows += line + buildString {
                    if (qty > 0) append(" • x$qty")
                    if (ppl > 0) append(" • $ppl pessoas")
                }
            }
        }
        return if (rows.isEmpty()) "Ainda não há resultados confirmados nesta sala." else rows.joinToString("\n")
    }

    fun normalGiftActivity(roomKey: String, limit: Int = 12): String {
        val rows = mutableListOf<String>()
        readableDatabase.rawQuery(
            """
            SELECT COALESCE(gift,'PRESENTE'), SUM(value) AS units, COUNT(*) AS events, MAX(ts)
            FROM events
            WHERE room_key=? AND type='GIFT_NORMAL'
            GROUP BY gift
            ORDER BY units DESC, events DESC
            LIMIT ?
            """.trimIndent(), arrayOf(roomKey, limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                rows += "🎁 ${GiftCatalog.displayName(c.getString(0))} • ${c.getLong(1)} unidades • ${c.getInt(2)} eventos"
            }
        }
        return if (rows.isEmpty()) "Ainda não há presentes normais identificados nesta sala." else rows.joinToString("\n")
    }

    fun giftDetail(roomKey: String, gift: String): String {
        val key = gift.uppercase(Locale.ROOT)
        val perf = giftPerformance(roomKey).firstOrNull { it.gift == key }
        val sentUnits = scalarLong(
            "SELECT COALESCE(SUM(value),0) FROM events WHERE room_key=? AND type='GIFT_AFORTUNADO' AND gift=?",
            arrayOf(roomKey, key)
        )
        val sentEvents = scalarLong(
            "SELECT COUNT(*) FROM events WHERE room_key=? AND type='GIFT_AFORTUNADO' AND gift=?",
            arrayOf(roomKey, key)
        )
        return buildString {
            append("${GiftCatalog.displayName(key)}\n")
            append("Enviado observado: $sentUnits unidades em $sentEvents eventos\n")
            if (perf == null || perf.samples <= 0) {
                append("Resultados associados: sem amostra confirmada.")
            } else {
                append("Resultados associados: ${perf.samples} amostras\n")
                append("Score observado: ${perf.score}/100\n")
                append("Média x${String.format(Locale.US, "%.1f", perf.avgMultiplier)} • máximo x${formatMultiplier(perf.maxMultiplier)}\n")
                append("50x+ ${perf.hits50} • 200x+ ${perf.hits200} • volume confirmado ${format(perf.payoutVolume)}")
            }
        }
    }

    fun jackpotHistory(limit: Int = 12): String {
        val rows = mutableListOf<String>()
        readableDatabase.rawQuery(
            """
            SELECT ts,type,value,COALESCE(room_name,'')
            FROM events
            WHERE type IN ('JACKPOT_SAMPLE_GLOBAL','JACKPOT_HIT_GLOBAL')
            ORDER BY ts DESC LIMIT ?
            """.trimIndent(), arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val type = c.getString(1)
                val icon = if (type == "JACKPOT_HIT_GLOBAL") "💥" else "👑"
                rows += "$icon ${time(c.getLong(0))} • ${format(c.getLong(2))}${c.getString(3).takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}"
            }
        }
        return if (rows.isEmpty()) "Ainda não há leituras confirmadas do Jackpot Global." else rows.joinToString("\n")
    }

    fun pkHistory(roomKey: String, limit: Int = 12): String {
        val rows = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT ts,type FROM events WHERE room_key=? AND type IN ('PK_ON','PK_OFF') ORDER BY ts DESC LIMIT ?",
            arrayOf(roomKey, limit.toString())
        ).use { c ->
            while (c.moveToNext()) rows += "${if (c.getString(1) == "PK_ON") "⚔️ ATIVO" else "⚪ DESLIGADO"} • ${time(c.getLong(0))}"
        }
        return if (rows.isEmpty()) "Nenhuma mudança de PK registrada nesta sala." else rows.joinToString("\n")
    }

    fun roomAfortunados(roomKey: String, limit: Int = 12): String {
        val rows = giftPerformance(roomKey)
        return if (rows.isEmpty()) "Ainda não há Afortunados associados a resultados nesta sala." else buildString {
            rows.take(limit).forEachIndexed { i, r ->
                append("${i + 1}. ${GiftCatalog.displayName(r.gift)} • ${r.score}/100 • ${r.samples} resultados • máx x${formatMultiplier(r.maxMultiplier)}\n")
            }
        }.trimEnd()
    }

    private fun time(ts: Long): String = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date(ts))

    fun clearAll() {
        writableDatabase.execSQL("DELETE FROM events")
        writableDatabase.execSQL("DELETE FROM sessions")
        writableDatabase.execSQL("DELETE FROM config_results")
    }

    fun giftPerformance(roomKey: String): List<GiftOverall> {
        val rows = configRows("room_key=?", arrayOf(roomKey))
        if (rows.isEmpty()) return emptyList()

        return rows.filter {
            val g = it.gift.trim()
            g.isNotBlank() &&
                g != "PRESENTE_NORMAL" &&
                g != "PRESENTE_RAJADA"
        }.groupBy { it.gift }.map { (gift, group) ->
            val samples = group.sumOf { it.samples }.coerceAtLeast(1)
            val avg = group.sumOf { it.avgMultiplier * it.samples } / samples
            val max = group.maxOfOrNull { it.maxMultiplier } ?: 0.0
            val h50 = group.sumOf { it.hits50 }
            val h200 = group.sumOf { it.hits200 }
            val volume = group.sumOf { it.payoutVolume }
            val sampleStrength = (kotlin.math.ln(1.0 + samples) / kotlin.math.ln(31.0)).coerceIn(0.0, 1.0)
            val score = (
                avg.coerceAtMost(100.0) * 0.40 +
                (h50.toDouble() / samples) * 100.0 * 0.25 +
                (h200.toDouble() / samples) * 100.0 * 0.25 +
                sampleStrength * 10.0
            ).toInt().coerceIn(0, 100)
            GiftOverall(gift, samples, avg, max, h50, h200, volume, score)
        }.sortedWith(
            compareByDescending<GiftOverall> { it.score }
                .thenByDescending { it.samples }
        )
    }

    fun bestGiftObserved(roomKey: String): GiftOverall? {
        val rows = giftPerformance(roomKey)
        return rows.firstOrNull { it.samples >= 3 } ?: rows.firstOrNull()
    }

    fun giftPerformanceSummary(roomKey: String, limit: Int = 8): String {
        val rows = giftPerformance(roomKey)
        if (rows.isEmpty()) {
            return "🎯 DESEMPENHO DOS AFORTUNADOS\nAinda não há amostras de Afortunados associadas a resultados nesta sala."
        }

        return buildString {
            append("🎯 DESEMPENHO OBSERVADO DOS AFORTUNADOS • ESTA SALA\n")
            rows.take(limit).forEachIndexed { index, r ->
                val confidence = when {
                    r.samples >= 20 -> "base forte"
                    r.samples >= 10 -> "média"
                    r.samples >= 5 -> "provisória"
                    else -> "amostra insuficiente"
                }
                val icon = when (r.gift) {
                    "TREVO" -> "🍀"
                    "ROSA" -> "🌹"
                    "OVO" -> "🥚"
                    else -> "🎁"
                }
                append("${index + 1}. $icon ${r.gift} • ${r.score}/100 • n=${r.samples} • $confidence\n")
                append("   média x${String.format(Locale.US, "%.1f", r.avgMultiplier)} • máx x${formatMultiplier(r.maxMultiplier)} • 50x+ ${r.hits50} • 200x+ ${r.hits200}\n")
            }
            append("\nℹ️ Compara resultados observados associados ao presente; não prova causalidade nem garante pagamento.")
        }.trimEnd()
    }

    private fun configRows(where: String, args: Array<String>): List<ConfigPerformance> {
        val rows = mutableListOf<ConfigPerformance>()
        val sql = """
            SELECT
                gift,
                gift_count,
                people_count,
                COUNT(*) AS samples,
                COALESCE(AVG(multiplier),0),
                COALESCE(MAX(multiplier),0),
                SUM(CASE WHEN multiplier>=50 THEN 1 ELSE 0 END),
                SUM(CASE WHEN multiplier>=200 THEN 1 ELSE 0 END),
                COALESCE(SUM(payout),0)
            FROM config_results
            WHERE $where
            GROUP BY gift,gift_count,people_count
        """.trimIndent()

        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) {
                val samples = c.getInt(3)
                val avg = c.getDouble(4)
                val max = c.getDouble(5)
                val h50 = c.getInt(6)
                val h200 = c.getInt(7)
                val volume = c.getLong(8)

                val sampleStrength = (ln(1.0 + samples) / ln(51.0)).coerceIn(0.0, 1.0)
                val score =
                    avg.coerceAtMost(100.0) * 0.45 +
                    (h50.toDouble() / samples.coerceAtLeast(1)) * 100.0 * 0.25 +
                    (h200.toDouble() / samples.coerceAtLeast(1)) * 100.0 * 0.20 +
                    sampleStrength * 10.0

                rows += ConfigPerformance(
                    gift = c.getString(0) ?: "?",
                    giftCount = if (c.isNull(1)) null else c.getInt(1),
                    peopleCount = if (c.isNull(2)) null else c.getInt(2),
                    samples = samples,
                    avgMultiplier = avg,
                    maxMultiplier = max,
                    hits50 = h50,
                    hits200 = h200,
                    payoutVolume = volume,
                    score = score
                )
            }
        }
        return rows.sortedWith(
            compareByDescending<ConfigPerformance> { it.score }
                .thenByDescending { it.samples }
        )
    }

    private fun observedSeconds(roomKey: String, since: Long): Long {
        val now = System.currentTimeMillis()
        val sql = """
            SELECT COALESCE(SUM(
                CASE
                    WHEN COALESCE(ended_at, ?) <= ? THEN 0
                    ELSE (
                        COALESCE(ended_at, ?) -
                        CASE WHEN started_at < ? THEN ? ELSE started_at END
                    ) / 1000
                END
            ),0)
            FROM sessions
            WHERE room_key=?
        """.trimIndent()

        return scalarLong(
            sql,
            arrayOf(
                now.toString(), since.toString(), now.toString(),
                since.toString(), since.toString(), roomKey
            )
        )
    }

    private fun scalarLong(sql: String, args: Array<String>): Long {
        readableDatabase.rawQuery(sql, args).use { c ->
            return if (c.moveToFirst()) c.getLong(0) else 0L
        }
    }

    private fun formatMultiplier(v: Double): String {
        val rounded = kotlin.math.round(v * 10.0) / 10.0
        return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.0001) rounded.toInt().toString()
        else String.format(Locale.US, "%.1f", rounded)
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600L
        val m = (seconds % 3600L) / 60L
        return if (h > 0) "${h}h${m}m" else "${m}m"
    }

    private fun format(v: Long): String = when {
        v >= 1_000_000L -> String.format(Locale.US, "%.2fM", v / 1_000_000.0)
        v >= 1_000L -> String.format(Locale.US, "%.1fK", v / 1_000.0)
        else -> v.toString()
    }
}
