# Como gerar o APK — Infinity Pro V15 Complete

## Opção A — repositório já descompactado
1. Coloque todo o conteúdo deste projeto em um repositório GitHub.
2. Confirme que existe `.github/workflows/build-apk.yml`.
3. Abra **Actions**.
4. Abra **Gerar APK Infinity Pro V15 Complete**.
5. Toque em **Run workflow**.
6. Ao terminar, baixe o artefato **Infinity-Pro-V15-Complete-APK**.
7. Dentro dele estará `Infinity-Pro-V15-Complete.apk`.

## Opção B — usando o ZIP completo
Use o arquivo externo `build-apk-infinity-v15-complete.yml` junto com `Infinity_Pro_V15_COMPLETE.zip` no repositório. O workflow externo descompacta o projeto e gera o APK.

Depois de instalar, ative **Infinity Pro** em Configurações > Acessibilidade. A leitura passa a ser automática no SIYA.
