# DesfonTiger — PROTÓTICO V 0.1 OFFLINE

Aplicativo Android independente, offline e alimentado manualmente.

## Identidade
- Nome do aplicativo: **DesfonTiger**
- Versão: **PROTÓTICO V 0.1 OFFLINE**
- Banco local SQLite; sem conta, servidor ou conexão obrigatória.

## Recursos incluídos nesta base
- Painel Full vertical com tema escuro/neon.
- Cadastro manual de Dragão, Empate e Tigre.
- Histórico local e desfazer último resultado.
- Resumo das últimas 20 entradas.
- Seletor de famílias de padrões e estratégia.
- Catálogo inicial: Onda, Xadrez, Dupla, Trinca, Ponto de Virada, Colchão, Pulso Final, Prenúncio, Confluência e Descoberta.
- Registro de sinais e painel de eficiência.
- Janela flutuante Android básica com entrada rápida.
- Workflow GitHub Actions para gerar APK Debug.

## Importante sobre os dados
O banco começa vazio. O vídeo fornecido não foi convertido aqui em uma transcrição validada de todas as rodadas; por isso este projeto não inventa 180/280 resultados nem estatísticas. Os resultados devem ser inseridos manualmente. A lógica de reconhecimento nesta versão é inicial/experimental: inclui detecção heurística de famílias e comparação de cauda de três resultados, não um modelo estatístico validado nem garantia de previsão.

## Como compilar no GitHub
1. Envie o conteúdo desta pasta para a raiz de um repositório GitHub.
2. Abra **Actions**.
3. Selecione **DesfonTiger - PROTÓTICO Android APK**.
4. Clique em **Run workflow**.
5. Ao terminar, baixe o artefato `DesfonTiger-PROTOTICO-0.1-APK`.

Também compila automaticamente em push para `main` ou `master`.

## Permissão da janela flutuante
Na primeira utilização, toque em **Janela flutuante** e conceda a permissão de sobreposição nas configurações Android. Depois volte ao aplicativo e toque novamente.

## Limitações conhecidas desta entrega
- A janela flutuante é funcional em versão básica; ainda não reproduz todos os indicadores do painel Full.
- A seleção de estratégias e padrões já aparece na interface, mas os modelos financeiros são parâmetros iniciais, não um sistema de staking comprovado.
- A central de aprendizado registra o histórico local, mas a descoberta automática ainda é heurística e precisa ser aprofundada com a base de operações validada.
- O app não faz apostas, não lê carteira e não controla outro jogo.
