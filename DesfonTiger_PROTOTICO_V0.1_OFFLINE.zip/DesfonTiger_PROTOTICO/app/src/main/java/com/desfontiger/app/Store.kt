package com.desfontiger.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Outcome(val id: Long, val value: String, val created: Long)
data class Signal(val id: Long, val prediction: String, val pattern: String, val confidence: Double, val outcome: String?)

class Store(context: Context) : SQLiteOpenHelper(context, "desfontiger.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE outcomes(id INTEGER PRIMARY KEY AUTOINCREMENT, value TEXT NOT NULL, created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE signals(id INTEGER PRIMARY KEY AUTOINCREMENT, prediction TEXT NOT NULL, pattern TEXT NOT NULL, confidence REAL NOT NULL, outcome TEXT, created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE pattern_stats(pattern TEXT PRIMARY KEY, occurrences INTEGER NOT NULL DEFAULT 0, dragon INTEGER NOT NULL DEFAULT 0, tiger INTEGER NOT NULL DEFAULT 0, tie INTEGER NOT NULL DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    @Synchronized fun addOutcome(value: String) {
        writableDatabase.execSQL("INSERT INTO outcomes(value,created) VALUES(?,?)", arrayOf(value, System.currentTimeMillis()))
        updatePending(value)
        rebuildStats()
    }
    private fun updatePending(value: String) {
        writableDatabase.execSQL("UPDATE signals SET outcome=? WHERE id=(SELECT id FROM signals WHERE outcome IS NULL ORDER BY id DESC LIMIT 1)", arrayOf(value))
    }
    @Synchronized fun addSignal(prediction: String, pattern: String, confidence: Double) {
        writableDatabase.execSQL("INSERT INTO signals(prediction,pattern,confidence,created) VALUES(?,?,?,?)",
            arrayOf(prediction, pattern, confidence, System.currentTimeMillis()))
    }
    fun outcomes(limit: Int = 5000): List<Outcome> {
        val out = mutableListOf<Outcome>()
        readableDatabase.rawQuery("SELECT id,value,created FROM outcomes ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out.add(Outcome(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out.reversed()
    }
    fun signals(): List<Signal> {
        val out = mutableListOf<Signal>()
        readableDatabase.rawQuery("SELECT id,prediction,pattern,confidence,outcome FROM signals ORDER BY id DESC LIMIT 500", null).use { c ->
            while (c.moveToNext()) out.add(Signal(c.getLong(0), c.getString(1), c.getString(2), c.getDouble(3), if(c.isNull(4)) null else c.getString(4)))
        }
        return out
    }
    fun clearAll() { writableDatabase.execSQL("DELETE FROM outcomes"); writableDatabase.execSQL("DELETE FROM signals"); writableDatabase.execSQL("DELETE FROM pattern_stats") }
    private fun rebuildStats() {
        // Statistics are reconstructed from chronological outcomes; signal records remain immutable.
        val data = outcomes(10000).map { it.value }
        val db = writableDatabase
        db.execSQL("DELETE FROM pattern_stats")
        for (i in 0 until data.size - 1) {
            val prefix = data.subList(maxOf(0, i - 9), i + 1)
            val key = PatternEngine.describe(prefix)
            val next = data[i + 1]
            db.execSQL("""INSERT INTO pattern_stats(pattern,occurrences,dragon,tiger,tie)
                VALUES(?,1,?,?,?) ON CONFLICT(pattern) DO UPDATE SET
                occurrences=occurrences+1, dragon=dragon+excluded.dragon,
                tiger=tiger+excluded.tiger, tie=tie+excluded.tie""",
                arrayOf(key, if(next=="D")1 else 0, if(next=="T")1 else 0, if(next=="E")1 else 0))
        }
    }
}
