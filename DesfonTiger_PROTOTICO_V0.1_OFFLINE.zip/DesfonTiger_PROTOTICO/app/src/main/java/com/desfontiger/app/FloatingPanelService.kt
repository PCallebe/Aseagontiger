package com.desfontiger.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService: Service() {
    private var window: WindowManager?=null
    private var view: LinearLayout?=null
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onStartCommand(intent: Intent?,flags:Int,startId:Int):Int {
        if(view!=null)return START_STICKY
        window=getSystemService(WINDOW_SERVICE) as WindowManager
        val store=Store(this)
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(18,14,18,14)
            setBackgroundColor(0xEE061632.toInt())
        }
        val title=TextView(this).apply { text="DESFONTIGER • PROTÓTICO";setTextColor(-1);textSize=16f }
        val info=TextView(this).apply {
            val a=PatternEngine.analyze(store.outcomes().map{it.value})
            text="Próximo sinal: ${a.best?.let{PatternEngine.label(it.prediction)}?:"SEM SINAL"}\\n${a.trend}"
            setTextColor(-1);textSize=15f
        }
        box.addView(title);box.addView(info)
        val row=LinearLayout(this)
        listOf("D","E","T").forEach { v ->
            row.addView(Button(this).apply { text=v;setOnClickListener { store.addOutcome(v); val a=PatternEngine.analyze(store.outcomes().map{it.value}); a.best?.let { store.addSignal(it.prediction,it.name,it.confidence) }; info.text="Próximo sinal: ${a.best?.let{PatternEngine.label(it.prediction)}?:"SEM SINAL"}\\n${a.trend}" } },
                LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f))
        }
        box.addView(row)
        box.addView(Button(this).apply { text="FECHAR";setOnClickListener{stopSelf()} })
        val params=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL;x=0;y=45 }
        window?.addView(box,params);view=box
        return START_STICKY
    }
    override fun onDestroy(){if(view!=null)window?.removeView(view);view=null;super.onDestroy()}
}
