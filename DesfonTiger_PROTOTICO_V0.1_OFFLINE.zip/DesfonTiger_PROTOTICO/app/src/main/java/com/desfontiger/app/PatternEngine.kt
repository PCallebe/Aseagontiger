package com.desfontiger.app

import kotlin.math.roundToInt

data class PatternHit(val name: String, val detail: String, val prediction: String, val confidence: Double, val samples: Int)
data class Analysis(val dragon: Double, val tiger: Double, val tie: Double, val trend: String, val best: PatternHit?, val hits: List<PatternHit>)

object PatternEngine {
    private fun isColor(s: String) = s == "D" || s == "T"
    fun describe(seq: List<String>): String {
        val s = seq.takeLast(10)
        if (s.isEmpty()) return "SEM_HISTORICO"
        val d=s.count{it=="D"}; val t=s.count{it=="T"}
        val tail=s.takeLast(3).joinToString("")
        val run=s.takeLastWhile{it==s.last()}.size
        val alt=s.size>=4 && s.takeLast(4).zipWithNext().all{it.first!=it.second} && s.takeLast(4).all{isColor(it)}
        return when {
            alt -> "XADREZ:${s.takeLast(4).joinToString("")}"
            run>=3 -> "ONDA:$run:${s.last()}"
            d>=3 && t>=3 -> "COLCHAO:$d-$t"
            s.size>=4 && s.takeLast(4).chunked(2).all{it.size==2 && it[0]==it[1]} -> "DUPLA:${s.takeLast(4).joinToString("")}"
            else -> "CAUDA:$tail"
        }
    }
    fun analyze(history: List<String>, mode: String = "Automático — todos os padrões"): Analysis {
        if (history.size < 4) return Analysis(33.3,33.3,33.4,"DADOS INSUFICIENTES",null, emptyList())
        val last=history.takeLast(10)
        val hits= mutableListOf<PatternHit>()
        val candidates= mutableListOf<String>()
        val run=last.takeLastWhile{it==last.last()}.size
        if(run>=3) candidates.add("ONDA")
        if(last.size>=6 && last.takeLast(6).all{it=="D"}) candidates.add("ONDA")
        if(last.size>=6 && last.takeLast(6).all{it=="T"}) candidates.add("ONDA")
        if(last.size>=4 && last.takeLast(4).zipWithNext().all{it.first!=it.second}) candidates.add("XADREZ")
        if(last.size>=4 && last.takeLast(4).chunked(2).all{it.size==2&&it[0]==it[1]}) candidates.add("DUPLA")
        if(last.count{it=="D"}>=3 && last.count{it=="T"}>=3) candidates.add("COLCHÃO")
        if(last.takeLast(3).distinct().size>=2) candidates.add("PULSO FINAL")
        if(last.contains("E")) candidates.add("PRENÚNCIO")
        if(candidates.isEmpty()) candidates.add("DESCOBERTA")
        val allowed = when {
            mode.startsWith("Somente Empates") -> setOf("PRENÚNCIO")
            mode.startsWith("Somente Onda") -> setOf("ONDA")
            mode.startsWith("Somente Xadrez") -> setOf("XADREZ")
            mode.startsWith("Somente Dupla") -> setOf("DUPLA")
            mode.startsWith("Somente Colchão") -> setOf("COLCHÃO")
            mode.startsWith("Somente Pulso") -> setOf("PULSO FINAL")
            else -> candidates.toSet()
        }
        // Search historical windows with the same last 3 symbols; score only observed next outcomes.
        val counts=mutableMapOf("D" to 0,"T" to 0,"E" to 0)
        val key=last.takeLast(3)
        for(i in 3 until history.size-1) if(history.subList(i-2,i+1)==key) counts[history[i+1]]=(counts[history[i+1]]?:0)+1
        val total=counts.values.sum()
        val d=if(total>0)100.0*counts["D"]!!/total else 33.3
        val t=if(total>0)100.0*counts["T"]!!/total else 33.3
        val e=if(total>0)100.0*counts["E"]!!/total else 33.4
        val ranked=listOf("D" to d,"T" to t,"E" to e).sortedByDescending{it.second}
        if(total>=3 && allowed.isNotEmpty()) {
            val name=allowed.first()
            hits.add(PatternHit(name,"Correspondência pela cauda de 3 resultados",ranked.first().first,ranked.first().second,total))
        }
        val trend=if(last.takeLast(5).count{it=="D"}>last.takeLast(5).count{it=="T"})"MAIS AZUL" else if(last.takeLast(5).count{it=="T"}>last.takeLast(5).count{it=="D"})"MAIS VERMELHO" else "EQUILIBRADA"
        return Analysis(d,t,e,trend,hits.firstOrNull(),hits)
    }
    fun label(s: String)=when(s){"D"->"DRAGÃO";"T"->"TIGRE";"E"->"EMPATE";else->"—"}
    fun patternCatalog(history: List<String>): List<String> {
        val set=linkedSetOf("ONDA","XADREZ","DUPLA","TRINCA","PONTO DE VIRADA","COLCHÃO","PULSO FINAL","PRENÚNCIO","CONFLUÊNCIA","DESCOBERTA")
        if(history.size>=10) {
            for(n in 3..8) if(history.takeLast(10).takeLast(n).distinct().size==1) set.add("ONDA $n")
            if(history.takeLast(6).all{it=="D"}||history.takeLast(6).all{it=="T"})set.add("ONDA 6")
            if(history.takeLast(6).all{it=="D"||it=="T"}&&history.takeLast(6).zipWithNext().all{it.first!=it.second})set.add("XADREZ 6")
            if(history.takeLast(10).count{it=="D"}>=3&&history.takeLast(10).count{it=="T"}>=3)set.add("COLCHÃO 3×3+")
        }
        return set.toList()
    }
}
