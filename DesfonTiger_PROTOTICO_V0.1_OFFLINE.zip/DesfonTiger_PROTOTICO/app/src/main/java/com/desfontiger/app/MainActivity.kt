package com.desfontiger.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val navy=Color(0xFF020B20)
private val panel=Color(0xFF071A39)
private val blue=Color(0xFF087BFF)
private val red=Color(0xFFEF303B)
private val green=Color(0xFF00C878)
private val gold=Color(0xFFFFD43B)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        val store=Store(this)
        setContent { MaterialTheme(colorScheme=darkColorScheme(primary=blue,background=navy,surface=panel)) { Dashboard(store) } }
    }
}
@Composable private fun Tile(title:String, modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.background(panel,RoundedCornerShape(14.dp)).padding(10.dp), verticalArrangement=Arrangement.spacedBy(7.dp), content=content) {
        Text(title,fontWeight=FontWeight.Bold,color=Color.White,fontSize=14.sp)
    }
}
@OptIn(ExperimentalMaterial3Api::class)\n@Composable private fun Dashboard(store:Store) {
    val context= LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var mode by remember { mutableStateOf("Automático — todos os padrões") }
    var strategy by remember { mutableStateOf("Padrão") }
    var bankroll by remember { mutableStateOf("1000") }
    var stopLoss by remember { mutableStateOf("20") }
    var tab by remember { mutableStateOf("INÍCIO") }
    val history=remember(refresh){store.outcomes().map{it.value}}
    val recent=history.takeLast(20)
    val analysis=remember(history,mode){PatternEngine.analyze(history,mode)}
    val catalog=remember(history){PatternEngine.patternCatalog(history)}
    val signal=analysis.best
    val modes=listOf("Automático — todos os padrões","Somente Empates","Somente Onda","Somente Xadrez","Somente Dupla","Somente Trinca","Somente Colchão","Somente Ponto de Virada","Somente Pulso Final","Somente Prenúncio","Somente Confluência")
    val strategies=listOf("Padrão","Conservadora","Alavancagem","Somente Empates")
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF031332),navy))).verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
            Text("🐉 DESFONTIGER",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black)
            Text("PROTÓTICO V 0.1 OFFLINE",color=green,fontWeight=FontWeight.Bold,fontSize=12.sp)
        }
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp),modifier=Modifier.horizontalScroll(rememberScrollState())) {
            listOf("INÍCIO","ANÁLISE","EFICIÊNCIA","HISTÓRICO","CONFIG.").forEach { label ->
                FilterChip(selected=tab==label,onClick={tab=label},label={Text(label)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=blue,selectedLabelColor=Color.White))
            }
        }
        if(tab=="INÍCIO"||tab=="ANÁLISE") {
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Tile("DRAGÃO",Modifier.weight(1f)){Text("${"%.1f".format(analysis.dragon)}%",color=blue,fontSize=23.sp,fontWeight=FontWeight.Bold)}
                Tile("TIGRE",Modifier.weight(1f)){Text("${"%.1f".format(analysis.tiger)}%",color=red,fontSize=23.sp,fontWeight=FontWeight.Bold)}
                Tile("EMPATE",Modifier.weight(1f)){Text("${"%.1f".format(analysis.tie)}%",color=green,fontSize=23.sp,fontWeight=FontWeight.Bold)}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Tile("TENDÊNCIA",Modifier.weight(1f)){Text(analysis.trend,color=Color.Cyan,fontWeight=FontWeight.Bold)}
                Tile("PRÓXIMO SINAL",Modifier.weight(1f)){Text(signal?.let{PatternEngine.label(it.prediction)}?:"SEM SINAL",color=gold,fontWeight=FontWeight.Bold)}
                Tile("AMOSTRA",Modifier.weight(1f)){Text("${signal?.samples?:0}",color=Color.White,fontWeight=FontWeight.Bold)}
            }
        }
        if(tab=="INÍCIO"||tab=="ANÁLISE") {
            Tile("MESA ATUAL — CADASTRO MANUAL") {
                Text("Toque nas cores da mesa, da esquerda para a direita. Cada toque preenche a próxima posição.",color=Color.LightGray,fontSize=12.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(4.dp),modifier=Modifier.fillMaxWidth()) {
                    val current=recent.takeLast(10)
                    repeat(10) { i ->
                        val v=current.getOrNull(i)
                        Box(Modifier.weight(1f).aspectRatio(1f).background(if(v=="D")blue else if(v=="T")red else if(v=="E")green else Color(0xFF14284B),RoundedCornerShape(50)),contentAlignment=Alignment.Center) {
                            Text(v?: "${i+1}",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold)
                        }
                    }
                }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    Button(onClick={enter("D")},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=blue)){Text("DRAGÃO")}
                    Button(onClick={enter("E")},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=green)){Text("EMPATE")}
                    Button(onClick={enter("T")},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=red)){Text("TIGRE")}
                }
                OutlinedButton(onClick={if(history.isNotEmpty()){store.writableDatabase.delete("outcomes","id=(SELECT MAX(id) FROM outcomes)",null);refresh++}},modifier=Modifier.fillMaxWidth()){Text("Desfazer último resultado")}
            }
            Tile("MODO DE ANÁLISE") {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
                    OutlinedTextField(value=mode,onValueChange={},readOnly=true,label={Text("Padrões utilizados")},modifier=Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { modes.forEach { DropdownMenuItem(text={Text(it)},onClick={mode=it;expanded=false}) } }
                }
            }
            Tile("ESTRATÉGIA DE OPERAÇÃO") {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
                    OutlinedTextField(value=strategy,onValueChange={},readOnly=true,label={Text("Gestão")},modifier=Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { strategies.forEach { DropdownMenuItem(text={Text(it)},onClick={strategy=it;expanded=false}) } }
                }
            }
            Tile("CENTRAL DE APRENDIZADO") {
                Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                    Metric("Operações",history.size.toString())
                    Metric("Modelos",catalog.size.toString())
                    Metric("Variações",catalog.count{it.contains(" ")||it.contains("×")}.toString())
                }
                Text("Catálogo descoberto",color=gold,fontWeight=FontWeight.Bold)
                catalog.forEach { Text("• $it",color=Color.White,fontSize=12.sp) }
                Text("Aprendizado local: cada resultado manual atualiza as estatísticas. Os padrões são hipóteses estatísticas, não garantia de resultado.",color=Color.LightGray,fontSize=11.sp)
            }
            Tile("RESUMO DA MESA — 20 RESULTADOS") {
                Row(horizontalArrangement=Arrangement.spacedBy(4.dp),modifier=Modifier.horizontalScroll(rememberScrollState())) {
                    recent.forEach { v -> Box(Modifier.size(27.dp).background(if(v=="D")blue else if(v=="T")red else green,RoundedCornerShape(50)),contentAlignment=Alignment.Center){Text(v,color=Color.White,fontWeight=FontWeight.Bold)} }
                }
            }
            Tile("SALDO E CONTROLE") {
                OutlinedTextField(value=bankroll,onValueChange={bankroll=it.filter{c->c.isDigit()||c=='.'}},label={Text("Saldo inicial")},modifier=Modifier.fillMaxWidth())
                OutlinedTextField(value=stopLoss,onValueChange={stopLoss=it.filter(Char::isDigit)},label={Text("Stop loss (%)")},modifier=Modifier.fillMaxWidth())
                Text("Controle informativo. O app não acessa carteira nem realiza apostas.",color=Color.LightGray,fontSize=11.sp)
            }
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Button(onClick={if(!Settings.canDrawOverlays(context)) context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+context.packageName))) else context.startService(Intent(context,FloatingPanelService::class.java))},modifier=Modifier.weight(1f)){Text("Janela flutuante")}
                OutlinedButton(onClick={tab="EFICIÊNCIA"},modifier=Modifier.weight(1f)){Text("Relatórios")}
            }
        }
        if(tab=="EFICIÊNCIA"||tab=="HISTÓRICO") {
            Tile("EFICIÊNCIA DOS SINAIS") {
                val signals=store.signals()
                val settled=signals.filter{it.outcome!=null}
                val wins=settled.count{it.prediction==it.outcome}
                Text("Sinais registrados: ${signals.size}",color=Color.White)
                Text("Pendentes: ${signals.count{it.outcome==null}}",color=gold)
                Text("Acertos: $wins | Erros: ${settled.size-wins}",color=green)
                Text("Taxa histórica: ${if(settled.isEmpty())"—" else "%.1f".format(100.0*wins/settled.size)+"%"}",color=Color.White,fontWeight=FontWeight.Bold)
            }
            Tile("HISTÓRICO DE RESULTADOS") {
                history.takeLast(100).forEachIndexed { i,v -> Text("${history.size- minOf(100,history.size)+i+1}. ${PatternEngine.label(v)}",color=Color.White,fontSize=12.sp) }
            }
        }
        if(tab=="CONFIG.") {
            Tile("CONFIGURAÇÕES OFFLINE") {
                Text("Banco SQLite local • sem login • sem nuvem • sem conexão obrigatória.",color=Color.White)
                Button(onClick={store.clearAll();refresh++},colors=ButtonDefaults.buttonColors(containerColor=red)){Text("Apagar banco local")}
            }
        }
        Text("DesfonTiger • PROTÓTICO V 0.1 OFFLINE • análise estatística experimental",color=Color.LightGray,fontSize=10.sp)
    }
}
@Composable private fun Metric(label:String,value:String) {
    Column(Modifier.padding(3.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Text(value,color=gold,fontWeight=FontWeight.Bold,fontSize=20.sp)
        Text(label,color=Color.LightGray,fontSize=10.sp)
    }
}
