# DragonTigerApp v0.5.2 — pacote de compilação

- Projeto: DragonTigerApp (não InfinityAppPro)
- Namespace / applicationId: `com.infinity.dragontiger`
- Android: compileSdk 35, targetSdk 35, minSdk 26
- Java: 17
- Android Gradle Plugin: 8.7.3
- Kotlin Gradle Plugin: 2.0.21
- Gradle da automação: 8.9
- Ícone vetorial: `app/src/main/res/drawable/ic_dragon_tiger.xml`
- Manifest: `android:icon` e `android:roundIcon` apontam para o recurso vetorial acima.
- Workflow: `.github/workflows/InfinityDragonTiger.yml`

## Compilação

O workflow compila a partir da raiz do repositório, executa `:app:compileDebugKotlin` e `:app:assembleDebug` e publica `app/build/outputs/apk/debug/app-debug.apk` como artefato `DragonTigerApp-APK-v0.5.2`.

## Limite de validação desta entrega

A estrutura do ZIP e os caminhos/identidade dos arquivos foram verificados localmente. O build Android completo depende do ambiente Android SDK/Gradle do GitHub Actions e ainda precisa ser executado no repositório. Não declarar APK validado até o workflow terminar com sucesso e o APK ser instalado/testado no aparelho.
