package com.infinity.dragontiger

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class HistoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 24)
            setBackgroundColor(0xFF06101F.toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        fun addText(value: String, size: Float = 14f, color: Int = 0xFFEAF4FF.toInt()) {
            val view = TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 8, 0, 8)
            }
            content.addView(view)
        }

        addText("HISTÓRICO COMPLETO", 22f, 0xFF37D7FF.toInt())
        val results = SequenceStore.all(this)
        addText("${results.size} resultados salvos localmente", 13f)

        if (results.isEmpty()) {
            addText("Nenhuma rodada registrada.", 14f, 0xFFFFD36A.toInt())
        } else {
            results.asReversed().forEachIndexed { index, result ->
                val name: String
                val color: Int
                when (result.value) {
                    SequenceStore.D -> {
                        name = "DRAGÃO"
                        color = 0xFF42A5FF.toInt()
                    }
                    SequenceStore.T -> {
                        name = "TIGRE"
                        color = 0xFFFF6262.toInt()
                    }
                    else -> {
                        name = "EMPATE"
                        color = 0xFF54D68B.toInt()
                    }
                }
                val number = results.size - index
                val roundId = result.roundKey ?: "—"
                val timestamp = SequenceStore.time(result.time)
                addText("#$number   $name   SIYA #$roundId   $timestamp", 14f, color)

                val detail = SequenceStore.detailsFor(this, result.id)
                if (detail != null) {
                    val dragonCard = detail.dragonCard ?: "—"
                    val tigerCard = detail.tigerCard ?: "—"
                    val bankValue = detail.bankOcr?.let { SequenceStore.fmt(it) } ?: "—"
                    addText(
                        "Cartas: Dragão $dragonCard / Tigre $tigerCard • OCR banca: $bankValue",
                        12f,
                        0xFFB8C8DC.toInt()
                    )
                }
            }
        }

        content.addView(Button(this).apply {
            text = "VOLTAR"
            setOnClickListener { finish() }
        })
        content.addView(Button(this).apply {
            text = "APAGAR HISTÓRICO"
            setOnClickListener {
                SequenceStore.clear(this@HistoryActivity)
                recreate()
            }
        })

        scroll.addView(content)
        setContentView(scroll)
    }
}
