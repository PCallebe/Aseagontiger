package com.infinity.dragontiger

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** OCR restrito às regiões aproximadas da mesa SIYA da referência S20 FE. */
object ScreenOcrReader {
    data class Snapshot(val dragonCard: String?, val tigerCard: String?, val bankCandidate: Double?, val roundId: String?)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    fun close() { runCatching { recognizer.close() } }

    fun read(frame: Bitmap, callback: (Snapshot) -> Unit) {
        val w = frame.width; val h = frame.height
        if (w < 200 || h < 400) return
        val dragon = crop(frame, .25f, .60f, .32f, .66f, 4)
        val tiger = crop(frame, .60f, .60f, .67f, .66f, 4)
        val bank = crop(frame, .285f, .908f, .40f, .927f, 3)
        val round = crop(frame, .20f, .915f, .50f, .94f, 2)
        val tasks = listOf(dragon, tiger, bank, round).map { bmp -> recognizer.process(InputImage.fromBitmap(bmp, 0)) }
        Tasks.whenAllSuccess<Text>(tasks).addOnSuccessListener { results ->
            val snapshot = Snapshot(
                parseCard(results.getOrNull(0)?.text.orEmpty()),
                parseCard(results.getOrNull(1)?.text.orEmpty()),
                parseBank(results.getOrNull(2)?.text.orEmpty()),
                parseRoundId(results.getOrNull(3)?.text.orEmpty())
            )
            callback(snapshot)
        }.addOnFailureListener { callback(Snapshot(null, null, null, null)) }
            .addOnCompleteListener { dragon.recycle(); tiger.recycle(); bank.recycle(); round.recycle() }
    }

    private fun crop(src: Bitmap, left: Float, top: Float, right: Float, bottom: Float, scale: Int): Bitmap {
        val x = (src.width * left).toInt().coerceIn(0, src.width - 1)
        val y = (src.height * top).toInt().coerceIn(0, src.height - 1)
        val width = (src.width * (right - left)).toInt().coerceAtLeast(1).coerceAtMost(src.width - x)
        val height = (src.height * (bottom - top)).toInt().coerceAtLeast(1).coerceAtMost(src.height - y)
        val cropped = Bitmap.createBitmap(src, x, y, width, height)
        if (scale <= 1) return cropped
        return Bitmap.createScaledBitmap(cropped, width * scale, height * scale, true).also { cropped.recycle() }
    }
    private fun parseCard(raw: String): String? {
        val normalized = raw.uppercase()
        val match = Regex("10|[2-9]|A|K|Q|J").find(normalized) ?: return null
        return match.value
    }
    private fun parseRoundId(raw: String): String? {
        // OCR pode confundir a palavra ROUND; o número da rodada é o último token
        // numérico desta ROI (o saldo fica na linha imediatamente acima).
        val token = Regex("[0-9][0-9.,]*").findAll(raw).lastOrNull()?.value ?: return null
        val digits = token.filter { it.isDigit() }
        return digits.takeIf { it.length in 2..10 }
    }
    private fun parseBank(raw: String): Double? {
        // A leitura do saldo fica acima do texto "Round"; selecionar o primeiro
        // token numérico, inclusive zero, e ignorar o número longo da rodada abaixo.
        val token = Regex("[0-9][0-9.,]*").findAll(raw).firstOrNull()?.value ?: return null
        val digits = token.filter { it.isDigit() }
        if (digits.length !in 1..9) return null
        return digits.toDoubleOrNull()
    }
}
