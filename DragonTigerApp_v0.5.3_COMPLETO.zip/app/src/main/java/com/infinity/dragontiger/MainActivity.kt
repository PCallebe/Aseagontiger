package com.infinity.dragontiger

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val request = 4107
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var scrollContainer: ScrollView? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                if (currentFocus !is EditText) render()
                uiHandler.postDelayed(this, 1500L)
            }
        }
    }
    private var startupMode = "database"
    private var startupPromptShown = false
    private var awaitingOverlayPermission = false
    private val projectionManager by lazy { getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    private val bg = 0xFF050B18.toInt()
    private val cardBg = 0xFF101C31.toInt()
    private val cyan = 0xFF39C9FF.toInt()
    private val blue = 0xFF36A8FF.toInt()
    private val red = 0xFFFF5968.toInt()
    private val green = 0xFF35D69A.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        root.post {
            if (!CaptureOverlayServiceActive.isActive && !startupPromptShown) {
                startupPromptShown = true
                startCapture()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        uiHandler.removeCallbacks(refreshTask)
        uiHandler.postDelayed(refreshTask, 1500L)
        if (awaitingOverlayPermission && Settings.canDrawOverlays(this)) {
            awaitingOverlayPermission = false
            launchScreenCaptureConsent()
        }
    }

    override fun onPause() { uiHandler.removeCallbacks(refreshTask); super.onPause() }

    private fun render() {
        val previousScroll = scrollContainer?.scrollY ?: 0
        val stats = SequenceStore.stats(this)
        val rows = SequenceStore.all(this)
        val current = PatternEngine.current(rows)
        val latestDetails = SequenceStore.latestRoundDetails(this)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 18, 14, 28); setBackgroundColor(bg) }
        scroll.addView(root)

        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 6, 8, 12) }
        brand.addView(label("🐉  DRAGON  TIGER  🐅", 29f, cyan, true))
        brand.addView(label("ANÁLISE  •  ESTRATÉGIA  •  RESULTADO", 13f, Color.WHITE, true))
        brand.addView(label("● CAPTURA ${if (CaptureOverlayServiceActive.isActive) "ATIVA" else "DESLIGADA"}   |   SIYA ${if (CaptureOverlayServiceActive.isActive) "CONECTADA" else "DESCONECTADA"}", 13f, if (CaptureOverlayServiceActive.isActive) green else 0xFFFFC45C.toInt(), true))
        root.addView(brand)

        status = label(if (CaptureOverlayServiceActive.isActive) "● CAPTURA ATIVA" else "● PRONTO — aguardando início da leitura", 13f, green)
        card("CONTROLE DA LEITURA", "", cyan).also { box ->
            box.addView(status)
            box.addView(actionButton(if (CaptureOverlayServiceActive.isActive) "MOSTRAR POPUP" else "INICIAR ANÁLISE") {
                if (CaptureOverlayServiceActive.isActive) startService(Intent(this, CaptureOverlayService::class.java).setAction(CaptureOverlayService.ACTION_SHOW_OVERLAY))
                else startCapture()
            })
            box.addView(actionButton("CONFIGURAR EXIBIÇÃO DO POPUP") {
                val modes = arrayOf("Completo", "Compacto", "Ícone flutuante", "Oculto", "Opacidade", "Tamanho")
                AlertDialog.Builder(this).setTitle("Exibição sobre a SIYA").setItems(modes) { _, which ->
                    when (which) {
                        in 0..3 -> {
                            val mode = arrayOf("full", "compact", "icon", "hidden")[which]
                            SequenceStore.putSetting(this, "overlay_mode", mode)
                            if (CaptureOverlayServiceActive.isActive) startService(Intent(this, CaptureOverlayService::class.java).setAction(CaptureOverlayService.ACTION_SET_OVERLAY_MODE).putExtra(CaptureOverlayService.EXTRA_OVERLAY_MODE, mode))
                        }
                        4 -> {
                            val values = arrayOf("35%", "50%", "65%", "80%", "95%")
                            AlertDialog.Builder(this).setTitle("Opacidade do popup").setItems(values) { _, selected ->
                                SequenceStore.putSetting(this, "overlay_opacity", arrayOf("89","128","166","204","242")[selected])
                                if (CaptureOverlayServiceActive.isActive) startService(Intent(this, CaptureOverlayService::class.java).setAction(CaptureOverlayService.ACTION_SET_OVERLAY_MODE).putExtra(CaptureOverlayService.EXTRA_OVERLAY_MODE, SequenceStore.setting(this, "overlay_mode", "full")))
                            }.show()
                        }
                        5 -> {
                            val values = arrayOf("Pequeno", "Médio", "Grande")
                            AlertDialog.Builder(this).setTitle("Tamanho do popup").setItems(values) { _, selected ->
                                SequenceStore.putSetting(this, "overlay_size", arrayOf("small","medium","large")[selected])
                                if (CaptureOverlayServiceActive.isActive) startService(Intent(this, CaptureOverlayService::class.java).setAction(CaptureOverlayService.ACTION_SET_OVERLAY_MODE).putExtra(CaptureOverlayService.EXTRA_OVERLAY_MODE, SequenceStore.setting(this, "overlay_mode", "full")))
                            }.show()
                        }
                    }
                    render()
                }.show()
            })
            box.addView(actionButton("DESLIGAR MONITORAMENTO", red) {
                stopService(Intent(this, CaptureOverlayService::class.java))
                CaptureOverlayServiceActive.isActive = false
                render()
            })
        }.also { root.addView(it) }

        val heat = if (CaptureOverlayServiceActive.isActive) "LEITURA ATIVA" else "AGUARDANDO SIYA"
        val trend = current?.name ?: "SEM PADRÃO CONFIRMADO"
        val decisionLabel = if (SequenceStore.setting(this, "first_calibration_done", "false") != "true") "CALIBRAÇÃO" else "OBSERVAR"
        val topGrid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topGrid.addView(metricCard("RODADAS", stats.total.toString(), cyan), LinearLayout.LayoutParams(0, -2, 1f))
        topGrid.addView(metricCard("LEITURA", heat, 0xFFFFC45C.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(topGrid)
        val secondGrid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        secondGrid.addView(metricCard("PADRÃO ATUAL", trend, 0xFFB77CFF.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
        secondGrid.addView(metricCard("PRÓXIMA AÇÃO", decisionLabel, green), LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(secondGrid)

        card("FREQUÊNCIA ATUAL", "Distribuição acumulada do histórico • não é previsão", cyan).also { c ->
            val frequency = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            frequency.addView(metricCard("DRAGÃO", "${String.format(Locale.getDefault(), "%.1f", stats.pD)}%", blue), LinearLayout.LayoutParams(0, -2, 1f))
            frequency.addView(metricCard("EMPATE", "${String.format(Locale.getDefault(), "%.1f", stats.pE)}%", green), LinearLayout.LayoutParams(0, -2, 1f))
            frequency.addView(metricCard("TIGRE", "${String.format(Locale.getDefault(), "%.1f", stats.pT)}%", red), LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(frequency)
            c.addView(resultLine("DRAGÃO", stats.d, stats.pD, blue))
            c.addView(resultLine("TIGRE", stats.t, stats.pT, red))
            c.addView(resultLine("EMPATE", stats.e, stats.pE, green))
            c.addView(label("Última rodada: ${rows.lastOrNull()?.let { name(it.value) + " • SIYA #${it.roundKey ?: "—"} • " + SequenceStore.time(it.time) } ?: "nenhuma"}", 12f, 0xFFD2DDED.toInt()))
            c.addView(label("Resultado anterior: ${rows.dropLast(1).lastOrNull()?.let { name(it.value) + " • " + SequenceStore.time(it.time) } ?: "nenhum"}", 12f, 0xFFD2DDED.toInt()))
            c.addView(label("Cartas OCR: Dragão ${latestDetails?.dragonCard ?: "—"} • Tigre ${latestDetails?.tigerCard ?: "—"} • SIYA #${latestDetails?.roundId ?: "—"}", 12f, 0xFFD2DDED.toInt()))
            c.addView(label("Qualidade da leitura: ROI de bolinhas testado em quadros de referência; OCR e precisão ainda não validados no aparelho.", 11f, 0xFFFFC45C.toInt()))
        }.also { root.addView(it) }

        card("SEQUÊNCIA RECENTE", "10 resultados visíveis • azul = Dragão • vermelho = Tigre • verde = Empate", cyan).also { c ->
            val line = rows.takeLast(10).asReversed().joinToString("   ") { when(it.value) { "D" -> "🔵"; "T" -> "🔴"; else -> "🟢" } }.ifBlank { "Aguardando captura" }
            c.addView(label(line, 22f, Color.WHITE, true))
            c.addView(label("Janela experimental 12: ${if(rows.size >= 12) rows.takeLast(12).joinToString(" ") { it.value } else "aguardando 12 resultados"}", 11f, 0xFF9FB4D0.toInt()))
        }.also { root.addView(it) }

        card("ANÁLISE DA RODADA", "Padrão prioritário e evidência histórica", green).also { c ->
            c.addView(label(current?.name ?: "OBSERVAR — NÃO FAZER NADA", 21f, if (current == null) 0xFFFFD36A.toInt() else green, true))
            c.addView(label(current?.description ?: "Nenhum padrão elegível identificado na janela atual.", 12f, Color.WHITE))
            c.addView(label(PatternEngine.drawEvidence(rows, current), 12f, green, true))
            c.addView(label("Ação operacional: OBSERVAR até que a leitura e a evidência sustentem uma conclusão.", 12f, 0xFFFFD36A.toInt()))
        }.also { root.addView(it) }

        card("PADRÕES E SIMETRIAS", "Um único padrão prioritário por vez. Sem confirmação: observar.", 0xFFB77CFF.toInt()).also { c ->
            c.addView(label(if (current == null) "OBSERVAR — NÃO FAZER NADA" else "${current.name}  •  ${current.description}", 15f, Color.WHITE, true))
            c.addView(label("Simetria principal: janela 5×5 (10 resultados). Janela 6×6: experimental.", 11f, 0xFF9FB4D0.toInt()))
            c.addView(label(PatternEngine.drawEvidence(rows, current), 12f, green, true))
            stats.patterns.forEach { p -> c.addView(label("${p.name}: ${p.hits} ocorrências históricas • ${p.total} resultados posteriores observados", 12f, 0xFFD5E2F2.toInt())) }
        }.also { root.addView(it) }

        card("DISTRIBUIÇÃO POR HORÁRIO", "Contagem de rodadas por hora. Não representa lucro nem garante melhor ganho.", cyan).also { c ->
            if (stats.hours.isEmpty()) c.addView(label("Aguardando histórico.", 12f, 0xFF9FB4D0.toInt()))
            else stats.hours.sortedByDescending { it.total }.take(8).forEach { h ->
                c.addView(label("${h.hour} • ${h.total} rodadas • D ${h.d} / T ${h.t} / E ${h.e}", 12f, 0xFFD5E2F2.toInt()))
            }
        }.also { root.addView(it) }

        card("BANCA E ESTRATÉGIA", "Banca registrada localmente. A leitura automática do saldo SIYA ainda depende de OCR calibrado.", 0xFFFFC45C.toInt()).also { c ->
            c.addView(label("BANCA: ${SequenceStore.fmt(stats.bank)}", 21f, 0xFFFFD36A.toInt(), true))
            c.addView(label("Origem: ${SequenceStore.setting(this, "bank_source", "manual")}", 11f, 0xFF9FB4D0.toInt()))
            val bankInput = EditText(this).apply { hint = "Atualizar banca em moedas"; inputType = 2; setTextColor(Color.WHITE); setHintTextColor(0xFF9FB4D0.toInt()) }
            c.addView(bankInput)
            c.addView(actionButton("SALVAR BANCA") { bankInput.text.toString().toDoubleOrNull()?.let { SequenceStore.setBank(this, it); render() } ?: toast("Informe um valor válido") })
            val mode = SequenceStore.setting(this, "entry_mode", "all")
            c.addView(label("MODO: ${if(mode=="draw") "SOMENTE EMPATE" else "DRAGÃO / TIGRE / EMPATE"}", 13f, Color.WHITE, true))
            c.addView(actionButton(if(mode=="draw") "ALTERAR PARA ANÁLISE COMPLETA" else "ANALISAR SOMENTE EMPATE") { SequenceStore.putSetting(this, "entry_mode", if(mode=="draw") "all" else "draw"); render() })
            c.addView(label("Pagamentos configurados: Dragão x2 • Tigre x2 • Empate x22", 12f, 0xFFD5E2F2.toInt()))
            c.addView(label("Gestão definida: Take 1/2/3 = 25%/50%/75%; Stop Loss = 30%; pausas de 30/39 min. Cálculo automático de entrada ainda não habilitado.", 11f, 0xFF9FB4D0.toInt()))
        }.also { root.addView(it) }

        card("GESTÃO FINANCEIRA • REGISTRO DE OPERAÇÕES", "Registre cada aposta e resultado para calcular banca, Take e Stop Loss sem alterar o histórico SIYA.", 0xFFFFC45C.toInt()).also { c ->
            val fs = SequenceStore.financeSummary(this)
            c.addView(label("OPERAÇÕES: ${fs.count} • ACERTOS: ${fs.wins} • ERROS: ${fs.losses}", 12f, Color.WHITE, true))
            c.addView(label("RESULTADO LÍQUIDO: ${SequenceStore.fmt(fs.net)} • BANCA ATUAL: ${SequenceStore.fmt(fs.bankNow)}", 14f, if (fs.net >= 0) green else red, true))
            c.addView(label("TAKE ALCANÇADO: ${fs.takeReached}/3 • STOP LOSS 30%: ${if (fs.stopLossReached) "ATINGIDO" else "NÃO ATINGIDO"}", 12f, if (fs.stopLossReached) red else 0xFFFFD36A.toInt(), true))
            val side = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Aposta: Dragão", "Aposta: Tigre", "Aposta: Empate")) }
            val outcome = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Resultado: Dragão", "Resultado: Tigre", "Resultado: Empate")) }
            val stake = EditText(this).apply { hint = "Valor apostado em moedas"; inputType = 8194; setTextColor(Color.WHITE); setHintTextColor(0xFF9FB4D0.toInt()) }
            c.addView(side); c.addView(outcome); c.addView(stake)
            c.addView(actionButton("REGISTRAR OPERAÇÃO", green) {
                val value = stake.text.toString().replace(",", ".").toDoubleOrNull()
                val sideCode = listOf("D", "T", "E")[side.selectedItemPosition]
                val outcomeCode = listOf("D", "T", "E")[outcome.selectedItemPosition]
                if (value == null || !SequenceStore.recordBet(this, sideCode, outcomeCode, value)) toast("Valor inválido ou superior à banca")
                else { toast("Operação registrada"); render() }
            })
            val pause = SequenceStore.suggestedPauseMinutes(this)
            if (pause > 0) c.addView(label(if (fs.stopLossReached) "STOP LOSS: limite de 30% atingido • pausa recomendada de 39 minutos." else "TAKE 3: meta de 75% atingida • pausa recomendada de 30 minutos.", 12f, red, true))
            else c.addView(label("Metas: Take 1 = +25% • Take 2 = +50% • Take 3 = +75% da banca inicial. Stop Loss = −30%. Pagamentos líquidos: Dragão/Tigre +1x; Empate +21x.", 11f, 0xFF9FB4D0.toInt()))
            c.addView(label("Últimas operações:", 12f, cyan, true))
            SequenceStore.financeEntries(this, 5).forEach { e ->
                c.addView(label("${SequenceStore.time(e.time)} • ${e.side} / ${e.outcome} • aposta ${SequenceStore.fmt(e.stake)} • líquido ${SequenceStore.fmt(e.net)}", 11f, if (e.net >= 0) green else red))
            }
        }.also { root.addView(it) }

        card("HISTÓRICO E DADOS", "Banco local SQLite • persistência entre sessões", cyan).also { c ->
            c.addView(actionButton("ABRIR HISTÓRICO COMPLETO") { startActivity(Intent(this, HistoryActivity::class.java)) })
            c.addView(actionButton("ATUALIZAR PAINEL") { render() })
            c.addView(label("Amostras: ${stats.total}. Frequências passadas não predizem o próximo resultado. Sem evidência validada, não sugerir entrada.", 11f, 0xFF9FB4D0.toInt()))
        }.also { root.addView(it) }

        card("NAVEGAÇÃO", "Acesso rápido às áreas do Dragon Tiger", cyan).also { nav ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(actionButton("AO VIVO") { render() }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(actionButton("PADRÕES") { toast("Padrões exibidos no painel acima") }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(actionButton("HISTÓRICO") { startActivity(Intent(this, HistoryActivity::class.java)) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(actionButton("BANCA") { toast("Gestão de banca exibida no painel acima") }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(actionButton("AJUSTES") { AlertDialog.Builder(this).setTitle("Configurações").setItems(arrayOf("Exibição do popup", "Modo somente empate", "Desligar monitoramento")) { _, which ->
                when(which) {
                    0 -> startService(Intent(this, CaptureOverlayService::class.java).setAction(CaptureOverlayService.ACTION_SET_OVERLAY_MODE).putExtra(CaptureOverlayService.EXTRA_OVERLAY_MODE, "full"))
                    1 -> { SequenceStore.putSetting(this, "entry_mode", "draw"); render() }
                    2 -> { stopService(Intent(this, CaptureOverlayService::class.java)); CaptureOverlayServiceActive.isActive = false; render() }
                }
            }.show() }, LinearLayout.LayoutParams(0, -2, 1f))
            nav.addView(row)
        }.also { root.addView(it) }

        scrollContainer = scroll
        setContentView(scroll)
        scroll.post { scroll.scrollTo(0, previousScroll) }
    }

    private fun card(title: String, subtitle: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 14); setBackgroundColor(cardBg)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 7, 0, 7); layoutParams = lp
        addView(label(title, 16f, accent, true)); if (subtitle.isNotBlank()) addView(label(subtitle, 11f, 0xFF9FB4D0.toInt()))
    }
    private fun metricCard(title: String, value: String, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(12, 14, 8, 14); setBackgroundColor(cardBg)
        val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.setMargins(3, 6, 3, 6); layoutParams = lp
        addView(label(title, 10f, 0xFF9FB4D0.toInt(), true)); addView(label(value, 16f, color, true))
    }
    private fun label(textValue: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 5, 0, 5)
    }
    private fun actionButton(textValue: String, color: Int = cyan, action: () -> Unit) = Button(this).apply {
        text = textValue; setTextColor(Color.WHITE); setBackgroundColor(0xFF203652.toInt()); textSize = 12f; setOnClickListener { action() }
    }
    private fun resultLine(name: String, count: Int, pct: Double, color: Int) = label("$name     $count     ${String.format(Locale.getDefault(), "%.1f", pct)}%", 14f, color, true)
    private fun name(v: String) = when(v) { "D" -> "DRAGÃO"; "T" -> "TIGRE"; else -> "EMPATE" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun startCapture() {
        val first = SequenceStore.setting(this, "first_calibration_done", "false") != "true"
        if (first) AlertDialog.Builder(this).setTitle("Primeira leitura Dragon Tiger")
            .setMessage("O primeiro uso exige 10 minutos de observação. O histórico será mantido no banco local.")
            .setPositiveButton("INICIAR 10 MINUTOS") { _, _ -> startupMode = "calibration"; requestCapturePermissions() }
            .setNegativeButton("Cancelar", null).show()
        else AlertDialog.Builder(this).setTitle("Como iniciar a análise?")
            .setItems(arrayOf("Nova observação de 10 minutos", "Usar banco existente e continuar registrando")) { _, which ->
                startupMode = if (which == 0) "calibration" else "database"; requestCapturePermissions()
            }.show()
    }
    private fun requestCapturePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            awaitingOverlayPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text = "Ative a sobreposição nas configurações do Android; a captura será solicitada ao retornar."; return
        }
        launchScreenCaptureConsent()
    }
    private fun launchScreenCaptureConsent() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), request)
    }
    @Deprecated("Legacy callback") override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == request && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureOverlayService::class.java).apply {
                putExtra(CaptureOverlayService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureOverlayService.EXTRA_RESULT_DATA, data)
                putExtra(CaptureOverlayService.EXTRA_MODE, startupMode)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            CaptureOverlayServiceActive.isActive = true
            status.text = if (startupMode == "calibration") "● OBSERVAÇÃO INICIAL ATIVA — 10 MIN" else "● CAPTURA ATIVA — BANCO EXISTENTE"
        }
    }
}

/** Estado apenas visual da sessão; a persistência dos resultados fica no SQLite. */
object CaptureOverlayServiceActive { @Volatile var isActive: Boolean = false }
