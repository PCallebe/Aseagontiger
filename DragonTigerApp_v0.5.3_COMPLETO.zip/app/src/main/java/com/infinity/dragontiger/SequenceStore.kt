package com.infinity.dragontiger

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Persistência transacional do histórico Dragon Tiger. */
object SequenceStore {
    const val D = "D"; const val T = "T"; const val E = "E"
    private const val DB_NAME = "dragon_tiger.db"
    private const val DB_VERSION = 5

    data class Result(val value: String, val time: Long, val id: Long = 0L, val roundKey: String? = null)
    data class PatternStat(val name: String, val hits: Int, val nextD: Int, val nextT: Int, val nextE: Int, val total: Int) {
        val best: String get() = listOf("DRAGÃO" to nextD, "TIGRE" to nextT, "EMPATE" to nextE).maxByOrNull { it.second }?.first ?: "SEM DADOS"
        val pct: Double get() = if (total == 0) 0.0 else maxOf(nextD, nextT, nextE) * 100.0 / total
    }
    data class HourStat(val hour: String, val total: Int, val d: Int, val t: Int, val e: Int)
    data class Stats(val total: Int, val d: Int, val t: Int, val e: Int, val pD: Double, val pT: Double, val pE: Double,
                     val recent: List<Result>, val bank: Double, val best: String, val bestPct: Double, val samples: Int,
                     val patterns: List<PatternStat>, val hours: List<HourStat>)

    private class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, DB_NAME, null, DB_VERSION) {
        private val appContext = c.applicationContext
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE results(id INTEGER PRIMARY KEY AUTOINCREMENT, value TEXT NOT NULL CHECK(value IN ('D','T','E')), occurred_at INTEGER NOT NULL, source TEXT NOT NULL DEFAULT 'capture', confidence REAL NOT NULL DEFAULT 0, round_key TEXT)")
            db.execSQL("CREATE INDEX idx_results_time ON results(occurred_at)")
            db.execSQL("CREATE UNIQUE INDEX idx_results_round_key ON results(round_key) WHERE round_key IS NOT NULL")
            db.execSQL("CREATE TABLE round_details(result_id INTEGER PRIMARY KEY, dragon_card TEXT, tiger_card TEXT, bank_ocr REAL, round_id TEXT, captured_at INTEGER NOT NULL, FOREIGN KEY(result_id) REFERENCES results(id) ON DELETE CASCADE)")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            db.execSQL("CREATE TABLE finance_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL, bet_side TEXT NOT NULL, outcome TEXT NOT NULL, stake REAL NOT NULL, net REAL NOT NULL, bank_after REAL NOT NULL)")
            db.execSQL("INSERT INTO settings(key,value) VALUES('bank','100000')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('visible_cursor','')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('last_round_id','')")
            // Migra histórico e banca da versão anterior baseada em SharedPreferences.
            val legacy = appContext.getSharedPreferences("dragon_tiger_history", Context.MODE_PRIVATE)
            val oldJson = runCatching { JSONArray(legacy.getString("results", "[]") ?: "[]") }.getOrNull()
            val migrated = mutableListOf<Pair<String, Long>>()
            if (oldJson != null) for (i in 0 until oldJson.length()) {
                runCatching {
                    val item = oldJson.getJSONObject(i)
                    val value = item.getString("v")
                    val time = item.getLong("t")
                    if (value in listOf(D, T, E)) migrated.add(value to time)
                }
            }
            // A implementação anterior lia a fileira da esquerda para a direita,
            // embora o SIYA marque NEW à esquerda; inverter restaura cronologia.
            migrated.asReversed().forEach { (value, time) ->
                db.execSQL("INSERT INTO results(value,occurred_at,source,confidence) VALUES(?,?,?,?)", arrayOf(value, time, "legacy_migration", 0.0))
            }
            val oldBank = legacy.getFloat("bank", 100000f).toDouble()
            db.execSQL("UPDATE settings SET value=? WHERE key='bank'", arrayOf(oldBank.toString()))
            val cursor = migrated.asReversed().takeLast(10).joinToString(",") { it.first }
            db.execSQL("UPDATE settings SET value=? WHERE key='visible_cursor'", arrayOf(cursor))
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) db.execSQL("ALTER TABLE results ADD COLUMN confidence REAL NOT NULL DEFAULT 0")
            if (oldVersion < 3) db.execSQL("CREATE TABLE IF NOT EXISTS round_details(result_id INTEGER PRIMARY KEY, dragon_card TEXT, tiger_card TEXT, bank_ocr REAL, captured_at INTEGER NOT NULL, FOREIGN KEY(result_id) REFERENCES results(id) ON DELETE CASCADE)")
            if (oldVersion < 4) {
                db.execSQL("ALTER TABLE results ADD COLUMN round_key TEXT")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_results_round_key ON results(round_key) WHERE round_key IS NOT NULL")
                db.execSQL("ALTER TABLE round_details ADD COLUMN round_id TEXT")
            }
            if (oldVersion < 5) {
                db.execSQL("CREATE TABLE IF NOT EXISTS finance_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL, bet_side TEXT NOT NULL, outcome TEXT NOT NULL, stake REAL NOT NULL, net REAL NOT NULL, bank_after REAL NOT NULL)")
            }
        }
    }
    @Volatile private var helper: Db? = null
    private fun db(c: Context): SQLiteDatabase {
        val instance = helper ?: synchronized(this) { helper ?: Db(c).also { helper = it } }
        return instance.writableDatabase
    }

    @Synchronized fun all(c: Context): List<Result> {
        val out = mutableListOf<Result>()
        db(c).rawQuery("SELECT id,value,occurred_at,round_key FROM results ORDER BY id", null).use { cur ->
            while (cur.moveToNext()) out.add(Result(cur.getString(1), cur.getLong(2), cur.getLong(0), if(cur.isNull(3)) null else cur.getString(3)))
        }
        return out
    }

    @Synchronized fun add(c: Context, value: String, time: Long = System.currentTimeMillis()) {
        if (value !in listOf(D, T, E)) return
        db(c).execSQL("INSERT INTO results(value,occurred_at,source,confidence) VALUES(?,?,?,?)", arrayOf(value, time, "manual", 1.0))
    }

    /**
     * Recebe a sequência visível (antiga -> recente). A última sequência é persistida
     * para sobreviver a reinícios. Só grava novos itens quando existe sobreposição
     * inequívoca entre o sufixo anterior e o prefixo atual.
     */
    @Synchronized fun ingestVisibleSequence(c: Context, values: List<String>, confidence: Double): Int {
        val clean = values.filter { it in listOf(D, T, E) }.takeLast(20)
        if (clean.size < 5) return 0
        val database = db(c)
        val cursor = database.rawQuery("SELECT value FROM settings WHERE key='visible_cursor'", null).use { if (it.moveToFirst()) it.getString(0) else "" }
        val old = cursor.split(',').filter { it in listOf(D, T, E) }
        val newCursor = clean.joinToString(",")
        val additions: List<String> = if (old.isEmpty()) clean else {
            val overlap = (minOf(old.size, clean.size) downTo 1).firstOrNull { n -> old.takeLast(n) == clean.take(n) } ?: 0
            if (overlap == 0) return 0 // Mudança sem correspondência: não inventar rodadas.
            clean.drop(overlap)
        }
        if (additions.isEmpty()) return 0
        database.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            additions.forEachIndexed { index, value ->
                database.execSQL("INSERT INTO results(value,occurred_at,source,confidence) VALUES(?,?,?,?)",
                    arrayOf(value, now + index, "siya_sequence", confidence.coerceIn(0.0, 1.0)))
            }
            database.execSQL("UPDATE settings SET value=? WHERE key='visible_cursor'", arrayOf(newCursor))
            database.setTransactionSuccessful()
        } finally { database.endTransaction() }
        return additions.size
    }


    data class RoundDetails(val resultId: Long, val dragonCard: String?, val tigerCard: String?, val bankOcr: Double?, val roundId: String?, val capturedAt: Long)
    @Synchronized fun recordLatestDetails(c: Context, dragon: String?, tiger: String?, bankOcr: Double?, roundId: String? = null) {
        val database = db(c)
        val latestId = database.rawQuery("SELECT id FROM results ORDER BY id DESC LIMIT 1", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        if (latestId == 0L) return
        database.execSQL("INSERT OR REPLACE INTO round_details(result_id,dragon_card,tiger_card,bank_ocr,round_id,captured_at) VALUES(?,?,?,?,?,?)",
            arrayOf(latestId, dragon, tiger, bankOcr, roundId, System.currentTimeMillis()))
    }
    fun latestRoundDetails(c: Context): RoundDetails? = db(c).rawQuery(
        "SELECT result_id,dragon_card,tiger_card,bank_ocr,round_id,captured_at FROM round_details ORDER BY result_id DESC LIMIT 1", null
    ).use { if (!it.moveToFirst()) null else RoundDetails(it.getLong(0), it.getString(1), it.getString(2), if(it.isNull(3)) null else it.getDouble(3), if(it.isNull(4)) null else it.getString(4), it.getLong(5)) }
    fun detailsFor(c: Context, resultId: Long): RoundDetails? = db(c).rawQuery(
        "SELECT result_id,dragon_card,tiger_card,bank_ocr,round_id,captured_at FROM round_details WHERE result_id=?", arrayOf(resultId.toString())
    ).use { if (!it.moveToFirst()) null else RoundDetails(it.getLong(0), it.getString(1), it.getString(2), if(it.isNull(3)) null else it.getDouble(3), if(it.isNull(4)) null else it.getString(4), it.getLong(5)) }

    /** Round ID SIYA resolve a ambiguidade de sequências repetidas (ex.: D-D-D-D...). */
    @Synchronized fun ingestByRoundId(c: Context, roundId: String, chronologicalSequence: List<String>): Boolean {
        val id = roundId.filter { it.isDigit() }
        if (id.isBlank() || chronologicalSequence.size != 10) return false
        val database = db(c)
        val previous = setting(c, "last_round_id", "")
        if (previous.isBlank()) {
            val latest = database.rawQuery("SELECT id FROM results ORDER BY id DESC LIMIT 1", null).use { if(it.moveToFirst()) it.getLong(0) else 0L }
            if (latest > 0L) database.execSQL("UPDATE results SET round_key=? WHERE id=? AND round_key IS NULL", arrayOf(id, latest))
            putSetting(c, "last_round_id", id)
            putSetting(c, "visible_cursor", chronologicalSequence.joinToString(","))
            return false // associa o ID à última rodada já visível; não cria duplicata
        }
        if (previous == id) return false
        val newest = chronologicalSequence.last()
        val exists = database.rawQuery("SELECT id FROM results WHERE round_key=? LIMIT 1", arrayOf(id)).use { it.moveToFirst() }
        if (exists) { putSetting(c, "last_round_id", id); return false }
        database.beginTransaction()
        try {
            database.execSQL("INSERT OR IGNORE INTO results(value,occurred_at,source,confidence,round_key) VALUES(?,?,?,?,?)",
                arrayOf(newest, System.currentTimeMillis(), "siya_round_id", 0.0, id))
            database.execSQL("UPDATE settings SET value=? WHERE key='last_round_id'", arrayOf(id))
            database.execSQL("UPDATE settings SET value=? WHERE key='visible_cursor'", arrayOf(chronologicalSequence.joinToString(",")))
            database.setTransactionSuccessful()
        } finally { database.endTransaction() }
        return true
    }

    data class FinanceEntry(val id: Long, val time: Long, val side: String, val outcome: String, val stake: Double, val net: Double, val bankAfter: Double)
    data class FinanceSummary(val net: Double, val wins: Int, val losses: Int, val count: Int, val bankStart: Double, val bankNow: Double, val takeReached: Int, val stopLossReached: Boolean)

    @Synchronized fun recordBet(c: Context, side: String, outcome: String, stake: Double): Boolean {
        if (side !in listOf(D, T, E) || outcome !in listOf(D, T, E) || !stake.isFinite() || stake <= 0.0) return false
        val database = db(c)
        val currentBank = bank(c)
        if (stake > currentBank) return false
        val net = when {
            side != outcome -> -stake
            side == E -> stake * 21.0
            else -> stake
        }
        val nextBank = (currentBank + net).coerceAtLeast(0.0)
        database.beginTransaction()
        try {
            database.execSQL("INSERT INTO finance_ledger(created_at,bet_side,outcome,stake,net,bank_after) VALUES(?,?,?,?,?,?)",
                arrayOf(System.currentTimeMillis(), side, outcome, stake, net, nextBank))
            database.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('bank',?)", arrayOf(nextBank.toString()))
            database.setTransactionSuccessful()
        } finally { database.endTransaction() }
        return true
    }

    fun financeEntries(c: Context, limit: Int = 30): List<FinanceEntry> {
        val out = mutableListOf<FinanceEntry>()
        db(c).rawQuery("SELECT id,created_at,bet_side,outcome,stake,net,bank_after FROM finance_ledger ORDER BY id DESC LIMIT ?", arrayOf(limit.coerceIn(1,500).toString())).use { cur ->
            while (cur.moveToNext()) out.add(FinanceEntry(cur.getLong(0),cur.getLong(1),cur.getString(2),cur.getString(3),cur.getDouble(4),cur.getDouble(5),cur.getDouble(6)))
        }
        return out
    }

    fun financeSummary(c: Context): FinanceSummary {
        val entries = financeEntries(c, 500).asReversed()
        val net = entries.sumOf { it.net }
        val start = entries.firstOrNull()?.let { it.bankAfter - it.net } ?: bank(c)
        val now = bank(c)
        val progress = if (start > 0) (now-start)/start else 0.0
        val take = when { progress >= .75 -> 3; progress >= .50 -> 2; progress >= .25 -> 1; else -> 0 }
        return FinanceSummary(net, entries.count { it.net > 0 }, entries.count { it.net < 0 }, entries.size, start, now, take, progress <= -.30)
    }

    fun suggestedPauseMinutes(c: Context): Int {
        val summary = financeSummary(c)
        return when { summary.stopLossReached -> 39; summary.takeReached >= 3 -> 30; else -> 0 }
    }

    fun bank(c: Context): Double = setting(c, "bank", "100000").toDoubleOrNull() ?: 100000.0
    @Synchronized fun setBank(c: Context, value: Double) { putSetting(c, "bank", value.coerceAtLeast(0.0).toString()) }
    fun setting(c: Context, key: String, fallback: String = ""): String = db(c).rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { if (it.moveToFirst()) it.getString(0) else fallback }
    @Synchronized fun putSetting(c: Context, key: String, value: String) {
        db(c).execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", arrayOf(key, value))
    }
    @Synchronized fun clear(c: Context) {
        db(c).beginTransaction(); try { db(c).execSQL("DELETE FROM round_details"); db(c).execSQL("DELETE FROM results"); db(c).execSQL("UPDATE settings SET value='' WHERE key IN ('visible_cursor','last_round_id')"); db(c).setTransactionSuccessful() } finally { db(c).endTransaction() }
    }

    fun stats(c: Context): Stats {
        val rows = all(c)
        val d = rows.count { it.value == D }; val t = rows.count { it.value == T }; val e = rows.count { it.value == E }
        val n = rows.size.coerceAtLeast(1)
        val patterns = PatternEngine.historicalStats(rows)
        val best = patterns.filter { it.total >= 12 }.maxByOrNull { it.pct }
        val cal = Calendar.getInstance()
        val hours = rows.groupBy { r -> cal.apply { timeInMillis = r.time }.get(Calendar.HOUR_OF_DAY) }.toSortedMap().map { (h, rs) ->
            HourStat(String.format(Locale.getDefault(), "%02d:00", h), rs.size, rs.count { it.value == D }, rs.count { it.value == T }, rs.count { it.value == E })
        }
        return Stats(rows.size, d, t, e, d * 100.0 / n, t * 100.0 / n, e * 100.0 / n, rows.takeLast(10), bank(c), best?.best ?: "SEM EVIDÊNCIA", best?.pct ?: 0.0, best?.total ?: 0, patterns, hours)
    }

    fun fmt(v: Double) = String.format(Locale.getDefault(), "%.0f moedas", v)
    fun time(v: Long) = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date(v))
}

/** Biblioteca inicial documentada. Frequências históricas são descritivas, não previsão. */
object PatternEngine {
    data class Current(val name: String, val description: String, val window: Int, val startIndex: Int, val confidence: Double)

    fun current(history: List<SequenceStore.Result>): Current? {
        val values = history.takeLast(12).map { it.value }
        val candidates = mutableListOf<Current>()
        if (values.size >= 4) {
            val tail = values.takeLast(4)
            if (tail.all { it == tail.first() }) candidates.add(Current("SURFE 4+", "Quatro ou mais resultados iguais consecutivos", 4, history.size - 4, 1.0))
            if (tail.all { it == SequenceStore.D || it == SequenceStore.T } && tail[0] == tail[2] && tail[1] == tail[3] && tail[0] != tail[1])
                candidates.add(Current("XADREZ", "Alternância perfeita Dragão/Tigre", 4, history.size - 4, 1.0))
            if (tail.count { it == SequenceStore.D } == 2 && tail.count { it == SequenceStore.T } == 2)
                candidates.add(Current("DOUBLE", "Duas ocorrências de cada lado nos últimos quatro", 4, history.size - 4, 0.75))
        }
        if (values.size >= 6) {
            val tail = values.takeLast(6)
            if ((tail.take(3).all { it == SequenceStore.D } && tail.drop(3).all { it == SequenceStore.T }) ||
                (tail.take(3).all { it == SequenceStore.T } && tail.drop(3).all { it == SequenceStore.D }))
                candidates.add(Current("TORRE GÊMEA", "Trincas opostas consecutivas", 6, history.size - 6, 1.0))
        }
        if (values.size >= 10) {
            val ten = values.takeLast(10); val left = ten.take(5); val right = ten.takeLast(5).reversed()
            val matches = left.zip(right).count { it.first == it.second }
            if (matches >= 4) candidates.add(Current(if (matches == 5) "SIMETRIA PERFEITA 5×5" else "SIMETRIA PARCIAL 5×5", "$matches de 5 pares espelhados", 10, history.size - 10, matches / 5.0))
        }
        // A janela 6×6 permanece apenas experimental e não pode substituir
        // a simetria visual principal 5×5 na seleção do padrão prioritário.
        // Um único padrão prioritário por vez. Empate é evento/result, não padrão de entrada.
        return candidates.sortedWith(compareByDescending<Current> { it.confidence }.thenByDescending { it.window }).firstOrNull()
    }

    fun drawEvidence(rows: List<SequenceStore.Result>, current: Current?): String {
        if (current == null || rows.size < 40) return "EMPATE: SEM EVIDÊNCIA SUFICIENTE"
        val baseline = rows.count { it.value == SequenceStore.E }.toDouble() / rows.size.coerceAtLeast(1)
        val stat = historicalStats(rows).firstOrNull { it.name == current.name || (current.name.startsWith("SIMETRIA") && it.name == "SIMETRIA 5×5") }
            ?: return "EMPATE: SEM EVIDÊNCIA SUFICIENTE"
        val rate = if (stat.total == 0) 0.0 else stat.nextE.toDouble() / stat.total
        if (stat.total >= 30 && rate >= maxOf(0.12, baseline * 1.5))
            return "ALERTA HISTÓRICO DE EMPATE • ${stat.total} casos observados • não é previsão"
        return "EMPATE: NÃO ENTRAR • evidência insuficiente"
    }

    fun historicalStats(rows: List<SequenceStore.Result>): List<SequenceStore.PatternStat> {
        val definitions = listOf(
            "SURFE 4+" to { v: List<String>, i: Int -> i >= 3 && (0..3).all { v[i - it] == v[i] } },
            "XADREZ" to { v: List<String>, i: Int -> i >= 3 && v[i] in listOf("D", "T") && v[i] == v[i-2] && v[i-1] == v[i-3] && v[i] != v[i-1] },
            "DOUBLE" to { v: List<String>, i: Int -> i >= 3 && v.subList(i-3, i+1).count { it == "D" } == 2 && v.subList(i-3, i+1).count { it == "T" } == 2 },
            "TORRE GÊMEA" to { v: List<String>, i: Int -> i >= 5 && ((v.subList(i-5, i-2).all { it == "D" } && v.subList(i-2, i+1).all { it == "T" }) || (v.subList(i-5, i-2).all { it == "T" } && v.subList(i-2, i+1).all { it == "D" })) },
            "SIMETRIA 5×5" to { v: List<String>, i: Int -> i >= 9 && v.subList(i-9, i-4).zip(v.subList(i-4, i+1).reversed()).count { it.first == it.second } >= 4 },
            "SIMETRIA 6×6 EXP." to { v: List<String>, i: Int -> i >= 11 && v.subList(i-11, i-5).zip(v.subList(i-5, i+1).reversed()).count { it.first == it.second } >= 5 }
        )
        val v = rows.map { it.value }
        return definitions.map { (name, match) ->
            var hits = 0; var d = 0; var t = 0; var e = 0
            for (i in 0 until v.size - 1) if (match(v, i)) { hits++; when (v[i+1]) { "D" -> d++; "T" -> t++; "E" -> e++ } }
            SequenceStore.PatternStat(name, hits, d, t, e, d+t+e)
        }
    }
}
