# DragonTigerApp — status técnico do piloto v0.2

## Implementado nesta revisão
- Persistência SQLite para resultados, horário, cursor visual, identificador SIYA da rodada e detalhes OCR por rodada.
- OCR do identificador `Round ####` para distinguir rodadas consecutivas com a mesma cor; exige duas leituras estáveis antes de inserir e associa o primeiro ID à última rodada já visível.
- Deduplicação persistente por sobreposição entre a sequência anterior e a atual; mudanças sem sobreposição são rejeitadas em vez de inventar resultados.
- Correção crítica: resultados consecutivos iguais não são mais colapsados pelo detector.
- Migração automática do histórico JSON e da banca antigos (SharedPreferences) para SQLite, mantendo os registros e normalizando a ordem com base no marcador NEW à esquerda.
- Ordem cronológica normalizada a partir da referência SIYA: marcador NEW à esquerda, portanto leitura visual da direita para a esquerda.
- ROI da fileira de bolinhas ajustado para a faixa horizontal x=24%–77% e vertical y=71,5%–73%, conforme o vídeo SIYA fornecido.
- Detector agora exige exatamente 10 bolinhas antes de registrar uma nova sequência; leituras parciais são descartadas.
- ML Kit OCR experimental para valores das cartas e saldo em regiões aproximadas; recortes dos valores A/Q e saldo 28.855 foram conferidos visualmente em um quadro do vídeo.
- Saldo OCR só atualiza após três leituras consecutivas estáveis (tolerância de 1%).
- Histórico exibe detalhes OCR associados à rodada mais recente.
- Motor inicial: Surfe 4+, Xadrez, Double, Torre Gêmea e simetria 5×5; simetria 6×6 fica apenas experimental e não substitui o padrão principal.
- Seleção de um único padrão prioritário; sem padrão, exibe OBSERVAR — NÃO FAZER NADA.
- Alerta de empate apenas como evidência histórica descritiva, com mínimo de 30 ocorrências correspondentes e comparação com a taxa-base; não é previsão.
- Primeira utilização solicita observação de 10 minutos; usos seguintes permitem recalibrar ou iniciar com banco existente.
- Popup independente do painel Full, sem repetir banca, com 10 bolinhas circulares, borda ao redor do padrão, cartas OCR, alerta de empate, arraste, minimizar, restauração e expansão para quase tela inteira.
- Painel Full com atualização automática da interface em intervalo de 1,5 s, histórico e distribuição por horário.
- Cores de resultados: Dragão azul, Tigre vermelho, Empate verde.

## Verificações de referência executadas
- Em 10 quadros extraídos do vídeo fornecido, uma implementação Python equivalente da regra de cor/ROI encontrou exatamente 10 bolinhas em 7 quadros; dois quadros eram transições sem fileira completa e um tinha 9 marcadores, portanto seria rejeitado. A leitura visual da fileira foi conferida com a ordem NEW à esquerda.
- Em um quadro com cartas abertas, os recortes normalizados enquadraram os valores A e Q; o recorte de banca enquadrou 28.855. Isso valida o posicionamento aproximado dos recortes, não a precisão do ML Kit em runtime.
- PatternEngine compilado isoladamente com Kotlin; SequenceStore compilado com stubs Android/SQLite; ScreenOcrReader compilado com stubs ML Kit; XML do Manifest validado.

## Ainda não comprovado / pendente
- Compilação Gradle/Kotlin e APK: não executados neste ambiente (não há Android SDK/Gradle instalado).
- Precisão de reconhecimento na mesa SIYA real: não testada. As regiões OCR/cores são ROIs iniciais aproximadas e precisam de calibração no S20 FE e em outros tamanhos.
- Leitura de naipes das cartas: não implementada; OCR atual tenta reconhecer somente o valor.
- Leitura de saldo pode confundir números se o layout SIYA mudar; atualização só ocorre após três leituras estáveis e continua experimental até validação visual.
- OCR de cartas e identificador de rodada exige duas leituras estáveis; se o texto não for reconhecido, a captura recorre à sobreposição da sequência visível.
- Atualização real medida em até 2–3 segundos: não comprovada em aparelho.
- Banco não é ainda um modelo de aprendizado de máquina nem descobre padrões novos automaticamente; calcula estatísticas históricas das regras cadastradas.
- Cálculo automático de valor de entrada, Take 1/2/3, Stop Loss, controle de lucro/prejuízo e pausas: ainda não implementados como motor transacional. As regras estão documentadas na interface, mas não devem ser tratadas como automação pronta.
- Popup ainda precisa de ajuste fino de posição no aparelho real para não cobrir a área de jogo.
- A fidelidade visual do painel Full ao mockup aprovado ainda precisa de revisão no aparelho; esta versão usa componentes nativos funcionais, não uma cópia pixel a pixel da arte.

## Critério de validação
1. Workflow conclui `:app:compileDebugKotlin`.
2. Workflow conclui `:app:assembleDebug`.
3. APK existe, tem tamanho maior que zero e SHA-256 registrado.
4. Instalação no Android real.
5. Captura comparada quadro a quadro com SIYA: bolinhas, ordem, cartas, saldo e horário.
6. Cronometrar latência entre fim da rodada e atualização do popup; meta <= 3 s.
7. Só então ativar recomendações financeiras automatizadas.
