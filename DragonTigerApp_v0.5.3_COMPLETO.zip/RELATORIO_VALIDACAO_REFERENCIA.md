# Relatório de validação de referência — Dragon Tiger v0.2

## Material analisado
- Vídeo SIYA fornecido: `VID-20261031-WA0175.mp4` (105,37 s).
- Captura SIYA S20 FE: `Screenshot_2026-10-31-11-34-40-807_com.zr.siya-edit.jpg` (693×1536).

## Detector da fileira de resultados
- ROI normalizada: x=24%–77%, y=71,5%–73%.
- Classificação: Dragão azul, Tigre vermelho/laranja, Empate verde-limão.
- A ordem visual no SIYA tem NEW à esquerda; o código converte para ordem cronológica da direita para a esquerda.
- A detecção exige exatamente 10 marcadores. Uma fileira parcial não é registrada.
- Em 10 quadros amostrados do vídeo (5, 15, 25, 35, 45, 55, 65, 75, 85 e 95 s), o algoritmo equivalente em Python encontrou 10 marcadores em 7 quadros; 2 eram transições sem fileira completa e 1 tinha 9 marcadores e foi rejeitado.
- Em um quadro de referência, sequência visual esquerda→direita: `T T D D T D T D T T`. Ordem cronológica armazenada: `T T D T D T D D T T`.

## OCR — posicionamento dos recortes
- Recorte de carta Dragão enquadra o valor A e o naipe visual.
- Recorte de carta Tigre enquadra o valor Q e o naipe visual.
- Recorte do saldo enquadra `28,855`.
- Recorte inferior contém o texto da rodada; o parser usa o último token numérico para tolerar erros OCR na palavra `Round`.
- Esses recortes foram inspecionados visualmente. O modelo ML Kit não foi executado neste ambiente; precisão de OCR ainda não está comprovada.

## Verificações de código executadas
- `SequenceStore.kt` e `PatternEngine` compilados com Kotlin contra stubs das APIs Android/SQLite usadas.
- `ScreenOcrReader.kt` compilado com Kotlin contra stubs das APIs ML Kit usadas.
- Smoke checks do `PatternEngine`: Surfe 4+, Xadrez e simetria 5×5.
- Manifest XML parseado.
- Workflow YAML parseado.
- Todos os blocos Bash do workflow passaram `bash -n`.

## Não executado
- Build Gradle/Android real.
- `:app:compileDebugKotlin` em Android SDK.
- `:app:assembleDebug`.
- Instalação em Android físico.
- Execução do ML Kit no aparelho.
- Medição da latência pós-rodada.
