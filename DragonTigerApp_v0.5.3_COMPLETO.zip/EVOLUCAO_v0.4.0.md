# DragonTigerApp v0.4.0 — evolução da interface operacional

## Alterações incluídas nesta revisão
- Adicionado ícone Android vetorial Dragon Tiger e referência no Manifest.
- Separado o comando de desligar monitoramento do fechamento visual do popup.
- Adicionado X no popup: remove somente a janela flutuante; o serviço de captura, OCR e histórico continuam ativos.
- Adicionada seleção de apresentação: Completo, Compacto, Ícone flutuante e Oculto.
- Adicionado comando para reabrir o popup a partir da Tela Full.
- O botão de desligamento agora interrompe o serviço sem encerrar a Activity.
- Mantida a arquitetura, namespace `com.infinity.dragontiger`, SQLite, detector e OCR existentes.
- Workflow atualizado para compilar o projeto diretamente na raiz, sem exigir `DragonTiger_PILOTO_v0.2.zip`.

## Limitações que continuam explícitas
- Esta revisão não é uma cópia pixel a pixel do mockup de referência. O dashboard ainda precisa ser redesenhado por completo para reproduzir o layout ilustrado.
- O motor de decisão ainda não valida entradas Dragon/Tiger com evidência operacional suficiente; a recomendação deve permanecer em OBSERVAR até a validação.
- OCR, leitura de cartas/naipes, regiões SIYA e latência precisam de validação no aparelho real.
- O temporizador de 10 minutos existe no serviço, mas a calibração não está validada como bloqueio integral do motor de decisão.
- A gestão financeira tem registro de operações, mas não é um executor automático de apostas.
- Não foi possível executar Gradle/Android SDK neste ambiente; o build precisa ser confirmado no GitHub Actions e instalado no telefone.

## Testes estáticos desta entrega
- YAML parseado.
- Estrutura do ZIP validada após empacotamento.
- Nenhuma alegação de APK compilado ou de teste real de SIYA.
