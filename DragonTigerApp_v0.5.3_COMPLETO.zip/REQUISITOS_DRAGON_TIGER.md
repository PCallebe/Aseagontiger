# Requisitos preservados — Dragon Tiger

## Produto e identidade
- Projeto exclusivamente DragonTigerApp; não incorporar InfinityAppPro.
- Painel Full é a interface completa de análise; popup é um resumo operacional independente.
- Cores: Dragão azul, Tigre vermelho, Empate verde.
- Popup fica na faixa superior indicada na referência SIYA, é móvel, rolável, minimizável e expansível; não deve repetir a banca nem cobrir cartas, sequência e mesa de apostas.
- Botão de desligamento encerra painel, popup e captura sem apagar banco/histórico.

## Captura e dados
- MediaProjection para leitura da tela SIYA com autorização Android.
- Resultado, timestamp, cartas reconhecidas e histórico persistidos em SQLite.
- Atualização-alvo <= 2 s; limite operacional de processamento pós-rodada <= 3 s.
- Janela de 10 s para aposta; a leitura/análise deve deixar aproximadamente 7 s para decisão.
- Primeira utilização: observação obrigatória de 10 min. Próximas inicializações: opção entre nova observação de 10 min ou banco existente.
- Histórico cumulativo e deduplicação persistente; não apagar ao minimizar ou desligar.

## Padrões
- Surfe 4+, Xadrez, Double, Torre Gêmea, Empate, simetria perfeita e parcial.
- Uma única marcação prioritária por vez; sem padrão, `OBSERVAR — NÃO FAZER NADA`.
- Simetria visual principal 5×5 em 10 resultados; 6×6 em 12 resultados apenas experimental.
- Marcar a janela identificada e nomear o padrão.
- Alerta de empate deve depender de amostra suficiente; não prometer previsão.

## Financeiro
- Pagamentos: Dragão x2, Tigre x2, Empate x22.
- Take 1: 25%; Take 2: 50%; Take 3: 75% da banca.
- Após Take 3: sugerir 30 min de pausa; após Stop Loss de 30%: sugerir 39 min.
- Registrar jogadas durante Take/Stop.
- Projeção de entrada deve depender da estratégia e evidência validada; não usar a fórmula antiga de 2%.
- Modo somente empate disponível.
