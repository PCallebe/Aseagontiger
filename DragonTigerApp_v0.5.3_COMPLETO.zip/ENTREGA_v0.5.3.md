# DragonTigerApp v0.5.3 — pacote de build revisado

## Alteração crítica no workflow
A versão anterior chamava `gradle/gradle-build-action@v3` e passava `gradle-version`, mas o projeto não continha `gradlew` nem `gradle/wrapper`. Essa combinação não garantia a instalação de uma distribuição Gradle executável. O workflow novo usa `gradle/actions/setup-gradle@v4` para instalar explicitamente Gradle 8.9 e executa `gradle` diretamente.

## Ambiente
- JDK 17 (Temurin)
- Gradle 8.9
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.7.3
- Kotlin Gradle Plugin 2.0.21
- namespace/applicationId: `com.infinity.dragontiger`
- versionCode 8 / versionName 0.5.3

## Etapas do workflow
1. Checkout do repositório.
2. Instalação explícita de JDK, Gradle e SDK Android.
3. Diagnóstico do ambiente e verificação dos arquivos obrigatórios.
4. `gradle --no-daemon --stacktrace --warning-mode all :app:compileDebugKotlin`.
5. `gradle --no-daemon --stacktrace :app:assembleDebug`.
6. Verificação de existência/tamanho do APK e geração de SHA-256.
7. Upload do APK e dos comprovantes.

## Limite de validação
O pacote e o workflow foram revisados estruturalmente. Este ambiente não dispõe de Android SDK nem de Gradle instalado para executar o build Android real. A compilação só será considerada aprovada quando o GitHub Actions concluir as etapas de Kotlin e APK e publicar o artefato.
